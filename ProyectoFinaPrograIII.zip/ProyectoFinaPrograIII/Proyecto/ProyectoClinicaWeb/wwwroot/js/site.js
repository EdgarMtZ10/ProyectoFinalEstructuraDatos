// En los campos numéricos que no admiten negativos (cantidades y precios) se
// impide escribir el signo menos, para que el usuario no llegue a enviar un
// valor que el sistema va a rechazar. La validación de verdad está en el
// servidor; esto es solo para avisar antes.
document.addEventListener("DOMContentLoaded", function () {
    var campos = document.querySelectorAll('input[type="number"][min="0"]');

    campos.forEach(function (campo) {
        // No deja teclear el menos ni la notación científica
        campo.addEventListener("keydown", function (evento) {
            if (evento.key === "-" || evento.key === "+" || evento.key === "e") {
                evento.preventDefault();
            }
        });

        // Si el valor llega negativo (pegado o con las flechas), se corrige a 0
        campo.addEventListener("input", function () {
            if (campo.value !== "" && Number(campo.value) < 0) {
                campo.value = 0;
            }
        });
    });
});
