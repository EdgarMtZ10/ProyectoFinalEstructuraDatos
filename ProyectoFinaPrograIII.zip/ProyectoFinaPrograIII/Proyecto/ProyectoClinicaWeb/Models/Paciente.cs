﻿using System.Text.Json.Serialization;

namespace ProyectoClinicaWeb.Models
{
    // Representa un documento de la colección "pacientes" en Mongo

    public class Paciente
    {
        [JsonPropertyName("identificacion")]
        public string Identificacion { get; set; } = string.Empty;

        [JsonPropertyName("nacionalidad")]
        public string Nacionalidad { get; set; } = string.Empty;

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; } = string.Empty;

        [JsonPropertyName("apellido1")]
        public string Apellido1 { get; set; } = string.Empty;

        [JsonPropertyName("apellido2")]
        public string Apellido2 { get; set; } = string.Empty;

        [JsonPropertyName("telefono")]
        public string Telefono { get; set; } = string.Empty;

        [JsonPropertyName("correo")]
        public string Correo { get; set; } = string.Empty;

        [JsonPropertyName("padecimientos")]
        public List<string> Padecimientos { get; set; } = new();

        [JsonPropertyName("tratamientos")]
        public List<string> Tratamientos { get; set; } = new();

        // Propiedad para mostrar en las vistas, por lo que no viaja por el socket
        [JsonIgnore]
        public string NombreCompleto => $"{Nombre} {Apellido1} {Apellido2}".Trim();
    }
}
