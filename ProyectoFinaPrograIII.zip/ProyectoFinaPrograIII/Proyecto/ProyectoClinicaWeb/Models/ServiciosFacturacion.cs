﻿using System.Text.Json.Serialization;

namespace ProyectoClinicaWeb.Models
{
    public class Servicio
    {
        [JsonPropertyName("id_servicio")]
        public int IdServicio { get; set; }

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; } = string.Empty;

        [JsonPropertyName("descripcion")]
        public string Descripcion { get; set; } = string.Empty;

        [JsonPropertyName("precio")]
        public decimal Precio { get; set; }

        [JsonPropertyName("activo")]
        public bool Activo { get; set; } = true;
    }

    public class Factura
    {
        [JsonPropertyName("id_factura")]
        public int? IdFactura { get; set; }

        [JsonPropertyName("id_cita")]
        public int IdCita { get; set; }

        [JsonPropertyName("identificacion_paciente")]
        public string IdentificacionPaciente { get; set; } = string.Empty;

        [JsonPropertyName("subtotal")]
        public decimal Subtotal { get; set; }

        [JsonPropertyName("impuesto")]
        public decimal Impuesto { get; set; }

        [JsonPropertyName("total")]
        public decimal Total { get; set; }

        [JsonPropertyName("estado")]
        public string Estado { get; set; } = "Pendiente";

        [JsonPropertyName("metodo_pago")]
        public string? MetodoPago { get; set; }
    }

    public class DetalleFactura
    {
        [JsonPropertyName("id_detalle")]
        public int? IdDetalle { get; set; }

        [JsonPropertyName("id_factura")]
        public int IdFactura { get; set; }

        [JsonPropertyName("id_servicio")]
        public int IdServicio { get; set; }

        [JsonPropertyName("cantidad")]
        public int Cantidad { get; set; }

        [JsonPropertyName("precio_unitario")]
        public decimal PrecioUnitario { get; set; }

        [JsonIgnore]
        public decimal SubtotalLinea => Cantidad * PrecioUnitario;
    }
}