﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace ProyectoClinicaWeb.Models
{
    public class RespuestaSocket
    {
        [JsonPropertyName("ok")]
        public bool Ok { get; set; }

        [JsonPropertyName("mensaje")]
        public string Mensaje { get; set; } = string.Empty;

        [JsonPropertyName("datos")]
        public JsonElement Datos { get; set; }

        [JsonIgnore]
        public bool FueExitoso => Ok;

        // El socket manda los nombres en minúscula, así que no se distinguen
        // mayúsculas al convertir
        private static readonly JsonSerializerOptions _opciones = new()
        {
            PropertyNameCaseInsensitive = true
        };

        // Convierte "Datos" al tipo verdadero que se espera (lista de médicos, una factura, etc.)
        public T? Leer<T>()
        {
            if (Datos.ValueKind == JsonValueKind.Undefined || Datos.ValueKind == JsonValueKind.Null)
                return default;
            return JsonSerializer.Deserialize<T>(Datos.GetRawText(), _opciones);
        }
    }
}
