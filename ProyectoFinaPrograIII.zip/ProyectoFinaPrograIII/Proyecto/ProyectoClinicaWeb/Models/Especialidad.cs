﻿using System.Text.Json.Serialization;

namespace ProyectoClinicaWeb.Models
{
    public class Especialidad
    {
        [JsonPropertyName("id_especialidad")]
        public int IdEspecialidad { get; set; }

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; } = string.Empty;
    }
}