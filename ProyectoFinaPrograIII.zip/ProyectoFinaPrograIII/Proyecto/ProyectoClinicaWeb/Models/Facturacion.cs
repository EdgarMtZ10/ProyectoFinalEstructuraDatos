﻿namespace ProyectoClinicaWeb.Models
{
    public class LineaServicio
    {
        public int IdServicio { get; set; }
        public int Cantidad { get; set; }
    }
}