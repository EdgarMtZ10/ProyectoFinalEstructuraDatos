﻿using System.Text.Json.Serialization;

namespace ProyectoClinicaWeb.Models
{
    public class Horario
    {
        [JsonPropertyName("id_horario")]
        public int IdHorario { get; set; }

        [JsonPropertyName("codigo_medico")]
        public string CodigoMedico { get; set; } = string.Empty;

        [JsonPropertyName("fecha")]
        public string Fecha { get; set; } = string.Empty;

        [JsonPropertyName("hora_inicio")]
        public string HoraInicio { get; set; } = string.Empty;

        [JsonPropertyName("hora_fin")]
        public string HoraFin { get; set; } = string.Empty;

        [JsonPropertyName("disponible")]
        public bool Disponible { get; set; }
    }
}