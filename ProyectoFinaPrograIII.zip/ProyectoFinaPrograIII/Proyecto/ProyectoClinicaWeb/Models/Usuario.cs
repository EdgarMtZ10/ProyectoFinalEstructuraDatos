﻿using System.Text.Json.Serialization;

namespace ProyectoClinicaWeb.Models
{
        // Representa un documento de "usuarios" en Mongo
        // Se usa para login y registro.
        public class Usuario
        {
            // JsonPropertyName asegura que, al serializar hacia el socket,
            // los nombres coincidan exactamente con lo que espera Python
            [JsonPropertyName("usuario")]
            public string NombreUsuario { get; set; } = string.Empty;

            [JsonPropertyName("contrasena")]
            public string Contrasena { get; set; } = string.Empty;

            // Rol del usuario: "Administrador", "Recepcionista" o "Medico"
            [JsonPropertyName("rol")]
            public string Rol { get; set; } = string.Empty;

            // Código de médico o identificación asociada
            [JsonPropertyName("referencia")]
            public string? Referencia { get; set; }

            [JsonPropertyName("activo")]
            public bool Activo { get; set; } = true;
    }
}
