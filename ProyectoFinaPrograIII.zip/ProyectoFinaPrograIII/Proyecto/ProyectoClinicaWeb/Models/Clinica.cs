﻿using System.Text.Json.Serialization;

namespace ProyectoClinicaWeb.Models
{
    public class Clinica
    {
        [JsonPropertyName("nombre")]
        public string Nombre { get; set; } = string.Empty;

        [JsonPropertyName("direccion")]
        public string Direccion { get; set; } = string.Empty;

        [JsonPropertyName("telefono")]
        public string Telefono { get; set; } = string.Empty;

        [JsonPropertyName("correo")]
        public string Correo { get; set; } = string.Empty;

        [JsonPropertyName("hora_apertura")]
        public string HoraApertura { get; set; } = string.Empty;

        [JsonPropertyName("hora_cierre")]
        public string HoraCierre { get; set; } = string.Empty;

        [JsonPropertyName("dias_laborales")]
        public List<string> DiasLaborales { get; set; } = new();
    }
}