﻿using System.ComponentModel.DataAnnotations;

namespace ProyectoClinicaWeb.Models
{
    public class RegistrarMedicoViewModel
    {
        [Required] public string Codigo { get; set; } = string.Empty;
        [Required] public string Identificacion { get; set; } = string.Empty;
        [Required] public string Nombre { get; set; } = string.Empty;
        [Required] public string Apellido1 { get; set; } = string.Empty;
        public string Apellido2 { get; set; } = string.Empty;
        [Required] public string TelefonoPersonal { get; set; } = string.Empty;
        [Required][EmailAddress] public string CorreoPersonal { get; set; } = string.Empty;
        [Required] public string TelefonoClinica { get; set; } = string.Empty;
        [Required][EmailAddress] public string CorreoClinica { get; set; } = string.Empty;
        public List<int> Especialidades { get; set; } = new();
    }

    public class RegistrarEspecialidadViewModel
    {
        [Required(ErrorMessage = "El nombre es obligatorio.")]
        public string Nombre { get; set; } = string.Empty;
    }

    public class GenerarHorariosViewModel
    {
        [Required] public string CodigoMedico { get; set; } = string.Empty;
        [Required] public string Fecha { get; set; } = string.Empty;
        [Required] public string HoraInicio { get; set; } = "08:00";
        [Required] public string HoraFin { get; set; } = "16:00";
    }
}