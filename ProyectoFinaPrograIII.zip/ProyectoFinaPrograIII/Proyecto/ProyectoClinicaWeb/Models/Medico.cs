﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace ProyectoClinicaWeb.Models
{
    public class Medico
    {
        [JsonPropertyName("codigo")]
        public string Codigo { get; set; } = string.Empty;

        [JsonPropertyName("identificacion")]
        public string Identificacion { get; set; } = string.Empty;

        [JsonPropertyName("nombre")]
        public string Nombre { get; set; } = string.Empty;

        [JsonPropertyName("apellido1")]
        public string Apellido1 { get; set; } = string.Empty;

        [JsonPropertyName("apellido2")]
        public string Apellido2 { get; set; } = string.Empty;

        [JsonPropertyName("telefono_personal")]
        public string TelefonoPersonal { get; set; } = string.Empty;

        [JsonPropertyName("correo_personal")]
        public string CorreoPersonal { get; set; } = string.Empty;

        [JsonPropertyName("telefono_clinica")]
        public string TelefonoClinica { get; set; } = string.Empty;

        [JsonPropertyName("correo_clinica")]
        public string CorreoClinica { get; set; } = string.Empty;

        [JsonPropertyName("especialidades")]
        public JsonElement EspecialidadesJson { get; set; }

        // Las búsquedas devuelven el nombre ya armado, en vez de los campos
        // por separado
        [JsonPropertyName("nombre_completo")]
        public string? NombreCompletoSocket { get; set; }

        [JsonIgnore]
        public string NombreCompleto =>
            !string.IsNullOrWhiteSpace(NombreCompletoSocket)
                ? NombreCompletoSocket!
                : $"{Nombre} {Apellido1} {Apellido2}".Trim();

        [JsonIgnore]
        public string EspecialidadesNombres { get; set; } = "Sin especialidades";

        // Obtener los IDs de especialidades sin importar el formato
        [JsonIgnore]
        public List<int> EspecialidadesIds
        {
            get
            {
                var ids = new List<int>();
                try
                {
                    if (EspecialidadesJson.ValueKind == JsonValueKind.Array)
                    {
                        foreach (var item in EspecialidadesJson.EnumerateArray())
                        {
                            if (item.ValueKind == JsonValueKind.Number)
                            {
                                ids.Add(item.GetInt32());
                            }
                            else if (item.ValueKind == JsonValueKind.String)
                            {
                                if (int.TryParse(item.GetString(), out int id))
                                    ids.Add(id);
                            }
                            else if (item.ValueKind == JsonValueKind.Object)
                            {
                                if (item.TryGetProperty("id_especialidad", out var idProp) && idProp.ValueKind == JsonValueKind.Number)
                                    ids.Add(idProp.GetInt32());
                                else if (item.TryGetProperty("id", out idProp) && idProp.ValueKind == JsonValueKind.Number)
                                    ids.Add(idProp.GetInt32());
                            }
                        }
                    }
                }
                catch { }
                return ids;
            }
        }

        // Obtener los nombres directamente si vienen como strings
        [JsonIgnore]
        public List<string> EspecialidadesStrings
        {
            get
            {
                var nombres = new List<string>();
                try
                {
                    if (EspecialidadesJson.ValueKind == JsonValueKind.Array)
                    {
                        foreach (var item in EspecialidadesJson.EnumerateArray())
                        {
                            if (item.ValueKind == JsonValueKind.String)
                            {
                                nombres.Add(item.GetString() ?? "");
                            }
                            else if (item.ValueKind == JsonValueKind.Object)
                            {
                                if (item.TryGetProperty("nombre", out var nombreProp) && nombreProp.ValueKind == JsonValueKind.String)
                                    nombres.Add(nombreProp.GetString() ?? "");
                            }
                        }
                    }
                }
                catch { }
                return nombres;
            }
        }
    }
}