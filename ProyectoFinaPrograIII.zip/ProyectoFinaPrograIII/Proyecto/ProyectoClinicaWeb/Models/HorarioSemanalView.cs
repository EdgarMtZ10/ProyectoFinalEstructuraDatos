﻿namespace ProyectoClinicaWeb.Models
{
    // Filtros de búsqueda del médico (por especialidad, nombre o identificación)
    public class BuscarMedicoViewModel
    {
        public string? Nombre { get; set; }
        public string? Identificacion { get; set; }
        public int? IdEspecialidad { get; set; }
    }

    // Une un campo de horario con la cita que lo ocupa (si la tiene) y los
    // datos básicos del paciente
    public class FilaHorarioSemanal
    {
        public Horario Horario { get; set; } = new();
        public Cita? Cita { get; set; }
        public string? NombrePaciente { get; set; }
        public string? TelefonoPaciente { get; set; }
        public string? CorreoPaciente { get; set; }
    }
}