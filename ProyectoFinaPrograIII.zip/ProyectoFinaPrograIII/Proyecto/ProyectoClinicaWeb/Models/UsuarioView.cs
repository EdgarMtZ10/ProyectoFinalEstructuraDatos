﻿using System.ComponentModel.DataAnnotations;

namespace ProyectoClinicaWeb.Models
{
    public class RegistrarEmpleadoViewModel
    {
        [Required(ErrorMessage = "El nombre de usuario es obligatorio.")]
        public string Usuario { get; set; } = string.Empty;

        [Required(ErrorMessage = "La contraseña es obligatoria.")]
        [DataType(DataType.Password)]
        public string Contrasena { get; set; } = string.Empty;

        [Required(ErrorMessage = "Debe elegir un rol.")]
        public string Rol { get; set; } = "Recepcionista";

        // Código de médico si el rol es "Medico" puede ir vacío en otros casos
        public string? Referencia { get; set; }
    }
}