﻿using System.Text.Json.Serialization;

namespace ProyectoClinicaWeb.Models
{
    public class Cita
    {
        [JsonPropertyName("id_cita")]
        public int? IdCita { get; set; }

        [JsonPropertyName("identificacion_paciente")]
        public string IdentificacionPaciente { get; set; } = string.Empty;

        [JsonPropertyName("codigo_medico")]
        public string CodigoMedico { get; set; } = string.Empty;

        [JsonPropertyName("id_horario")]
        public int IdHorario { get; set; }

        [JsonPropertyName("fecha")]
        public string Fecha { get; set; } = string.Empty;

        [JsonPropertyName("hora")]
        public string Hora { get; set; } = string.Empty;

        //Reservada, Confirmada, Cancelada o cancelada
        [JsonPropertyName("estado")]
        public string Estado { get; set; } = "Reservada";
    }
}