﻿using System.ComponentModel.DataAnnotations;

namespace ProyectoClinicaWeb.Models
{
    public class ReservarCitaView
    {
        [Required]
        public string CodigoMedico { get; set; } = string.Empty;

        [Required]
        public int IdHorario { get; set; }
    }

    public class ReprogramarCitaView
    {
        [Required]
        public int IdCita { get; set; }

        [Required]
        public int IdHorario { get; set; }
    }
}