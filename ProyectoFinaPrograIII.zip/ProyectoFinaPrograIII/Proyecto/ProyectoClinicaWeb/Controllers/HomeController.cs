using Microsoft.AspNetCore.Mvc;
using ProyectoClinicaWeb.Models;
using ProyectoClinicaWeb.Servicios;

namespace ProyectoClinicaWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly IServicioClinica _servicioClinica;

        public HomeController(IServicioClinica servicioClinica)
        {
            _servicioClinica = servicioClinica;
        }

        public async Task<IActionResult> Index()
        {
            // Obtener datos de la clínica para mostrar en la página principal
            try
            {
                var respuesta = await _servicioClinica.ObtenerClinicaAsync();
                var clinica = respuesta.Leer<Clinica>();
                ViewBag.Clinica = clinica;
            }
            catch
            {
                ViewBag.Clinica = null;
            }

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}