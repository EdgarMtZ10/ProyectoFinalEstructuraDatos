﻿using Microsoft.AspNetCore.Mvc;
using ProyectoClinicaWeb.Models;
using ProyectoClinicaWeb.Servicios;

namespace ProyectoClinicaWeb.Controllers
{
    public class MedicoController : Controller
    {
        private readonly IServicioClinica _servicioClinica;

        public MedicoController(IServicioClinica servicioClinica)
        {
            _servicioClinica = servicioClinica;
        }

        // /Medico   lista de especialidades, para elegir una
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var respuesta = await _servicioClinica.ListarEspecialidadesAsync();
            var especialidades = respuesta.Leer<List<Especialidad>>() ?? new();
            return View(especialidades);
        }

        // Medico/PorEspecialidad/3   médicos de esa especialidad
        [HttpGet]
        public async Task<IActionResult> PorEspecialidad(int id)
        {
            var filtros = new { ids_especialidad = new[] { id } };
            var respuesta = await _servicioClinica.BuscarMedicosAsync(filtros);

            if (!respuesta.FueExitoso)
            {
                TempData["MensajeError"] = respuesta.Mensaje;
                return RedirectToAction("Index");
            }

            var medicos = respuesta.Leer<List<Medico>>() ?? new();
            ViewBag.IdEspecialidad = id;
            return View(medicos);
        }

        // Disponibilidad del médico, una semana a la vez
        [HttpGet]
        public async Task<IActionResult> Horarios(string codigo, string? fecha)
        {
            // Se piden todos los espacios libres y después se recorta la semana
            var respuesta = await _servicioClinica.HorariosDisponiblesAsync(codigo, null);

            if (!respuesta.FueExitoso)
            {
                TempData["MensajeError"] = respuesta.Mensaje;
                return RedirectToAction("Index");
            }

            var horarios = respuesta.Leer<List<Horario>>() ?? new();

            // Fecha de referencia: la que venga por parámetro o hoy
            var fechaReferencia = DateTime.Today;
            if (!string.IsNullOrEmpty(fecha) && DateTime.TryParse(fecha, out var parseada))
            {
                fechaReferencia = parseada;
            }

            // Lunes de la semana que contiene esa fecha
            var lunes = fechaReferencia.AddDays(-(((int)fechaReferencia.DayOfWeek + 6) % 7));
            var domingo = lunes.AddDays(6);

            var deLaSemana = horarios
                .Where(h => DateTime.TryParse(h.Fecha, out var f) && f >= lunes && f <= domingo)
                .OrderBy(h => h.Fecha).ThenBy(h => h.HoraInicio)
                .ToList();

            // No se ofrecen semanas pasadas ni más allá del mes de anticipación
            var lunesDeHoy = DateTime.Today.AddDays(-(((int)DateTime.Today.DayOfWeek + 6) % 7));
            ViewBag.PuedeRetroceder = lunes > lunesDeHoy;
            ViewBag.PuedeAvanzar = lunes.AddDays(7) <= DateTime.Today.AddDays(30);

            ViewBag.CodigoMedico = codigo;
            ViewBag.Lunes = lunes;
            ViewBag.SemanaAnterior = lunes.AddDays(-7);
            ViewBag.SemanaSiguiente = lunes.AddDays(7);
            ViewBag.TotalLibres = horarios.Count;

            return View(deLaSemana);
        }
    }
}