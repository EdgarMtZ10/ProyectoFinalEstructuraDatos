﻿using Microsoft.AspNetCore.Mvc;
using ProyectoClinicaWeb.Models;
using ProyectoClinicaWeb.Servicios;
using System.Text.Json;

namespace ProyectoClinicaWeb.Controllers
{
    public class AccountController : Controller
    {
        // Se inyecta la interfaz,
        // si por dentro habla con el socket de verdad o con la versión falsa
        private readonly IServicioClinica _servicioClinica;

        public AccountController(IServicioClinica servicioClinica)
        {
            _servicioClinica = servicioClinica;
        }

        // GET: /Account/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View(new LoginViewModel());
        }

        // POST: /Account/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel modelo)
        {
            if (!ModelState.IsValid)
            {
                return View(modelo);
            }

            // Según el radio button elegido, se llama el método correspondiente
            var respuesta = modelo.TipoUsuario == "Empleado"
                ? await _servicioClinica.IniciarSesionEmpleadoAsync(modelo.Identificacion, modelo.Contrasena)
                : await _servicioClinica.IniciarSesionClienteAsync(modelo.Identificacion, modelo.Contrasena);

            if (!respuesta.FueExitoso)
            {
                // mostrarle al usuario un mensaje claro de error
                ModelState.AddModelError(string.Empty, respuesta.Mensaje);
                return View(modelo);
            }
            var referencia = respuesta.Datos.TryGetProperty("referencia", out var propReferencia)
            && propReferencia.ValueKind == JsonValueKind.String
            ? propReferencia.GetString()
            : null;

            HttpContext.Session.SetString("Referencia", referencia ?? string.Empty);

            // Login exitoso: se guarda en sesión quién entró y con qué rol
            HttpContext.Session.SetString("Identificacion", modelo.Identificacion);
            HttpContext.Session.SetString("TipoUsuario", modelo.TipoUsuario);

            // Para saludar por el nombre y no por la cédula: si es cliente se
            // busca el paciente al que apunta la cuenta. Si no se encuentra,
            // se sigue mostrando el usuario con el que entró.
            var nombreMostrar = modelo.Identificacion;
            if (modelo.TipoUsuario == "Cliente" && !string.IsNullOrEmpty(referencia))
            {
                var respPaciente = await _servicioClinica.ObtenerPacienteAsync(referencia);
                var paciente = respPaciente.Leer<Paciente>();
                if (paciente != null && !string.IsNullOrEmpty(paciente.NombreCompleto))
                {
                    nombreMostrar = paciente.NombreCompleto;
                }
            }
            HttpContext.Session.SetString("NombreMostrar", nombreMostrar);

            return modelo.TipoUsuario == "Empleado"
                ? RedirectToAction("Index", "Empleado")
                : RedirectToAction("Index", "Cliente");
        }

        // GET: /Account/Registro
        [HttpGet]
        public IActionResult Registro()
        {
            return View(new RegistroClienteViewModel());
        }

        // POST: /Account/Registro
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Registro(RegistroClienteViewModel modelo)
        {
            if (!ModelState.IsValid)
            {
                return View(modelo);
            }

            // Se arma el objeto que espera el socket 
            var datosCliente = new
            {
                identificacion = modelo.Identificacion,
                nacionalidad = modelo.Nacionalidad,
                nombre = modelo.Nombre,
                apellido1 = modelo.Apellido1,
                apellido2 = modelo.Apellido2,
                telefono = modelo.Telefono,
                correo = modelo.Correo,
                contrasena = modelo.Contrasena
            };

            var respuesta = await _servicioClinica.RegistrarClienteAsync(datosCliente);

            if (!respuesta.FueExitoso)
            {
                // Por ejemplo: identificación duplicada
                ModelState.AddModelError(string.Empty, respuesta.Mensaje);
                return View(modelo);
            }

            TempData["MensajeExito"] = "Cuenta creada correctamente. Ahora puede iniciar sesión.";
            return RedirectToAction("Login");
        }

        // Cierra la sesión y regresa al login
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}