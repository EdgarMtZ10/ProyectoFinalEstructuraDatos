﻿using Microsoft.AspNetCore.Mvc;
using ProyectoClinicaWeb.Models;
using ProyectoClinicaWeb.Servicios;
using System.Text.Json.Serialization;

namespace ProyectoClinicaWeb.Controllers
{
    public class FacturacionController : Controller
    {
        private readonly IServicioClinica _servicioClinica;

        public FacturacionController(IServicioClinica servicioClinica)
        {
            _servicioClinica = servicioClinica;
        }

        private bool EsEmpleado() => HttpContext.Session.GetString("TipoUsuario") == "Empleado";

        // Una cita solo se cobra el día en que se atiende
        private async Task<(bool puede, string motivo)> SePuedeCobrarAsync(int idCita)
        {
            var respuesta = await _servicioClinica.ObtenerCitaAsync(idCita);
            var cita = respuesta.Leer<Cita>();

            if (cita is null)
            {
                return (false, "No se encontró la cita indicada.");
            }

            if (cita.Estado == "Cancelada")
            {
                return (false, "No se puede cobrar una cita cancelada.");
            }

            if (!DateTime.TryParse(cita.Fecha, out var fechaCita))
            {
                return (false, "La fecha de la cita no es válida.");
            }

            if (fechaCita.Date != DateTime.Today)
            {
                return (false, $"Solo se pueden cobrar las citas del día de hoy. " +
                               $"Esta cita es del {fechaCita:dd/MM/yyyy}.");
            }

            return (true, "");
        }

        // Facturacion -> el empleado busca la cita que va a cobrar
        [HttpGet]
        public async Task<IActionResult> Index(string? identificacion, string? fecha)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var citas = new List<Cita>();
            var seBusco = !string.IsNullOrWhiteSpace(identificacion) || !string.IsNullOrWhiteSpace(fecha);

            if (seBusco)
            {
                // El socket filtra por identificación del paciente o por fecha
                var filtros = !string.IsNullOrWhiteSpace(identificacion)
                    ? (object)new { identificacion_paciente = identificacion }
                    : new { fecha };

                var respuesta = await _servicioClinica.ListarCitasAsync(filtros);

                if (!respuesta.FueExitoso)
                {
                    TempData["MensajeError"] = respuesta.Mensaje;
                }
                else
                {
                    citas = respuesta.Leer<List<Cita>>() ?? new();
                }
            }

            // Se averigua cuáles de esas citas ya tienen factura, para no dejar
            // cobrar dos veces ni abrir una factura que no existe.
            // Las consultas van en paralelo: el servidor de Python atiende cada
            // petición en su propio hilo.
            var consultas = citas
                .Where(c => c.IdCita.HasValue)
                .Select(async c => new
                {
                    IdCita = c.IdCita!.Value,
                    TieneFactura = (await _servicioClinica.ObtenerFacturaAsync(c.IdCita.Value)).FueExitoso
                })
                .ToList();

            var resultados = await Task.WhenAll(consultas);

            ViewBag.CitasFacturadas = resultados
                .Where(r => r.TieneFactura)
                .Select(r => r.IdCita)
                .ToHashSet();

            ViewBag.Identificacion = identificacion;
            ViewBag.Fecha = fecha;
            ViewBag.SeBusco = seBusco;
            return View(citas);
        }

        // 
        // Sin restricción de rol: tanto el cliente como
        // el empleado  necesitan poder ver esta pantalla
        [HttpGet]
        public async Task<IActionResult> VerFactura(int idCita)
        {
            var respuesta = await _servicioClinica.ObtenerFacturaAsync(idCita);

            if (!respuesta.FueExitoso)
            {
                TempData["MensajeError"] = respuesta.Mensaje;

                // El empleado vuelve a la pantalla de cobro; el cliente, a sus citas
                if (EsEmpleado())
                {
                    return RedirectToAction("Index");
                }
                return RedirectToAction("Index", "Cita");
            }

            var datos = respuesta.Leer<FacturaConDetalle>();

            // El detalle solo trae el id del servicio, así que se carga el
            // catálogo para poder mostrar el nombre en la factura
            var respServicios = await _servicioClinica.ListarServiciosAsync();
            var servicios = respServicios.Leer<List<Servicio>>() ?? new();
            ViewBag.NombresServicios = servicios.ToDictionary(s => s.IdServicio, s => s.Nombre);

            return View(datos);
        }

        // catálogo de servicios para armar la factura
        [HttpGet]
        public async Task<IActionResult> Cobrar(int idCita)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var (puede, motivo) = await SePuedeCobrarAsync(idCita);
            if (!puede)
            {
                TempData["MensajeError"] = motivo;
                return RedirectToAction("Index");
            }

            // Solo los activos: un servicio descontinuado no se debe poder cobrar
            var respuesta = await _servicioClinica.ListarServiciosAsync(soloActivos: true);
            var servicios = respuesta.Leer<List<Servicio>>() ?? new();

            ViewBag.IdCita = idCita;
            return View(servicios);
        }

        // Facturacion/GenerarFactura
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GenerarFactura(int idCita, List<LineaServicio> lineas)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var (puede, motivo) = await SePuedeCobrarAsync(idCita);
            if (!puede)
            {
                TempData["MensajeError"] = motivo;
                return RedirectToAction("Index");
            }

            // Antes las negativas se descartaban sin avisar: el empleado creía
            // haberlas cobrado
            if (lineas.Any(l => l.Cantidad < 0))
            {
                TempData["MensajeError"] = "Las cantidades no pueden ser negativas.";
                return RedirectToAction("Cobrar", new { idCita });
            }

            var lineasSocket = lineas
                .Where(l => l.Cantidad > 0)
                .Select(l => new { id_servicio = l.IdServicio, cantidad = l.Cantidad });

            var respuesta = await _servicioClinica.GenerarFacturaAsync(idCita, lineasSocket);

            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("VerFactura", new { idCita });
        }

        //Facturacion/Pagar
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Pagar(int idCita, string metodoPago)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.RegistrarPagoAsync(idCita, metodoPago);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("VerFactura", new { idCita });
        }
    }

    // Forma exacta en la que responde: { "factura": {...}, "detalles": [...] }
    public class FacturaConDetalle
    {
        [JsonPropertyName("factura")]
        public Factura Factura { get; set; } = new();

        [JsonPropertyName("detalles")]
        public List<DetalleFactura> Detalles { get; set; } = new();
    }
}