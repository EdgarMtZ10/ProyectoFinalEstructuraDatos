﻿using Microsoft.AspNetCore.Mvc;
using ProyectoClinicaWeb.Models;
using ProyectoClinicaWeb.Servicios;

namespace ProyectoClinicaWeb.Controllers
{
    public class ClienteController : Controller
    {
        private readonly IServicioClinica _servicioClinica;

        public ClienteController(IServicioClinica servicioClinica)
        {
            _servicioClinica = servicioClinica;
        }

        // GET: /Cliente
        [HttpGet]
        public IActionResult Index()
        {
            // si no hay sesión activa o el usuario
            // no es de tipo "Cliente" se manda de vuelta al login
            var tipoUsuario = HttpContext.Session.GetString("TipoUsuario");
            if (string.IsNullOrEmpty(tipoUsuario) || tipoUsuario != "Cliente")
            {
                return RedirectToAction("Login", "Account");
            }

            // Se le pasa el nombre a la vista para el saludo de bienvenida
            ViewBag.NombreMostrar = HttpContext.Session.GetString("NombreMostrar");
            ViewBag.Identificacion = HttpContext.Session.GetString("Identificacion");

            return View();
        }

        //Cliente/EditarPerfil
        [HttpGet]
        public async Task<IActionResult> EditarPerfil()
        {
            var identificacion = HttpContext.Session.GetString("Referencia");
            if (string.IsNullOrEmpty(identificacion)) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ObtenerPacienteAsync(identificacion);
            if (!respuesta.FueExitoso)
            {
                TempData["MensajeError"] = respuesta.Mensaje;
                return RedirectToAction("Index");
            }

            var paciente = respuesta.Leer<Paciente>();
            var modelo = new EditarPerfilView
            {
                Identificacion = paciente!.Identificacion,
                Nacionalidad = paciente.Nacionalidad,
                Nombre = paciente.Nombre,
                Apellido1 = paciente.Apellido1,
                Apellido2 = paciente.Apellido2,
                Telefono = paciente.Telefono,
                Correo = paciente.Correo
            };
            return View(modelo);
        }

        ///Cliente/EditarPerfil
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarPerfil(EditarPerfilView modelo)
        {
            var identificacion = HttpContext.Session.GetString("Referencia");
            if (string.IsNullOrEmpty(identificacion)) return RedirectToAction("Login", "Account");

            if (!ModelState.IsValid)
            {
                modelo.Identificacion = identificacion;
                return View(modelo);
            }

            var cambios = new
            {
                nacionalidad = modelo.Nacionalidad,
                nombre = modelo.Nombre,
                apellido1 = modelo.Apellido1,
                apellido2 = modelo.Apellido2,
                telefono = modelo.Telefono,
                correo = modelo.Correo
            };

            var respuesta = await _servicioClinica.ModificarPacienteAsync(identificacion, cambios);

            if (!respuesta.FueExitoso)
            {
                ModelState.AddModelError(string.Empty, respuesta.Mensaje);
                modelo.Identificacion = identificacion;
                return View(modelo);
            }

            TempData["MensajeExito"] = "Datos actualizados correctamente.";
            return RedirectToAction("Index");
        }
    }
}