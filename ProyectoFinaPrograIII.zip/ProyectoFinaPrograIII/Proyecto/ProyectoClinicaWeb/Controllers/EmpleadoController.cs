﻿using Microsoft.AspNetCore.Mvc;
using ProyectoClinicaWeb.Models;
using ProyectoClinicaWeb.Servicios;

namespace ProyectoClinicaWeb.Controllers
{
    public class EmpleadoController : Controller
    {
        private readonly IServicioClinica _servicioClinica;

        public EmpleadoController(IServicioClinica servicioClinica)
        {
            _servicioClinica = servicioClinica;
        }

        private bool EsEmpleado() => HttpContext.Session.GetString("TipoUsuario") == "Empleado";

        private async Task<Dictionary<int, string>> ObtenerNombresEspecialidades()
        {
            var respuesta = await _servicioClinica.ListarEspecialidadesAsync();
            var especialidades = respuesta.Leer<List<Especialidad>>() ?? new();
            return especialidades.ToDictionary(e => e.IdEspecialidad, e => e.Nombre);
        }

        [HttpGet]
        public IActionResult Index()
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");
            ViewBag.Identificacion = HttpContext.Session.GetString("Identificacion");
            return View();
        }

        //mantenimiento de clientes y empleados
        [HttpGet]
        public async Task<IActionResult> Usuarios(bool incluirInactivos = false)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ListarUsuariosAsync(incluirInactivos);
            var usuarios = respuesta.Leer<List<Usuario>>() ?? new();

            ViewBag.IncluirInactivos = incluirInactivos;
            return View(usuarios);
        }

        // GET: /Empleado/EditarCliente -> formulario para editar datos del cliente
        [HttpGet]
        [HttpGet]
        public async Task<IActionResult> EditarCliente(string identificacion)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ObtenerPacienteAsync(identificacion);
            var paciente = respuesta.Leer<Paciente>();

            if (paciente == null)
            {
                TempData["MensajeError"] = "No se encontró el cliente indicado.";
                return RedirectToAction("Usuarios");
            }

            return View(paciente);
        }

        // POST: /Empleado/EditarCliente -> guardar cambios
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarCliente(string identificacion, Paciente modelo)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var cambios = new
            {
                nombre = modelo.Nombre,
                apellido1 = modelo.Apellido1,
                apellido2 = modelo.Apellido2,
                telefono = modelo.Telefono,
                correo = modelo.Correo,
                nacionalidad = modelo.Nacionalidad
            };

            var respuesta = await _servicioClinica.ModificarPacienteAsync(identificacion, cambios);

            if (!respuesta.FueExitoso)
            {
                TempData["MensajeError"] = respuesta.Mensaje;
                return View(modelo);
            }

            TempData["MensajeExito"] = "Cliente actualizado correctamente.";
            return RedirectToAction("Usuarios");
        }

        // RegistrarEmpleado
        [HttpGet]
        public IActionResult RegistrarEmpleado()
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");
            return View(new RegistrarEmpleadoViewModel());
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegistrarEmpleado(RegistrarEmpleadoViewModel modelo)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");
            if (!ModelState.IsValid) return View(modelo);

            var datosUsuario = new
            {
                usuario = modelo.Usuario,
                contrasena = modelo.Contrasena,
                rol = modelo.Rol,
                referencia = modelo.Referencia,
                activo = true
            };

            var respuesta = await _servicioClinica.RegistrarUsuarioAsync(datosUsuario);

            if (!respuesta.FueExitoso)
            {
                ModelState.AddModelError(string.Empty, respuesta.Mensaje);
                return View(modelo);
            }

            TempData["MensajeExito"] = "Empleado registrado correctamente.";
            return RedirectToAction("Usuarios");
        }

        // Empleado/Desactivar
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Desactivar(string usuario)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.EliminarUsuarioAsync(usuario);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("Usuarios");
        }

        // Empleado/Reactivar
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Reactivar(string usuario)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ReactivarUsuarioAsync(usuario);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("Usuarios");
        }

        // GET: /Empleado/EditarEmpleado -> formulario para editar empleado
        [HttpGet]
        public async Task<IActionResult> EditarEmpleado(string usuario)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ListarUsuariosAsync(true);
            var usuarios = respuesta.Leer<List<Usuario>>() ?? new();
            var empleado = usuarios.FirstOrDefault(u => u.NombreUsuario == usuario);

            if (empleado == null)
            {
                TempData["MensajeError"] = "No se encontró el empleado indicado.";
                return RedirectToAction("Usuarios");
            }

            return View(empleado);
        }

        // POST: /Empleado/EditarEmpleado -> guardar cambios
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarEmpleado(string usuario, string rol, string referencia)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var cambios = new
            {
                rol = rol,
                referencia = referencia
            };

            var respuesta = await _servicioClinica.ModificarUsuarioAsync(usuario, cambios);

            if (!respuesta.FueExitoso)
            {
                TempData["MensajeError"] = respuesta.Mensaje;
                return RedirectToAction("EditarEmpleado", new { usuario });
            }

            TempData["MensajeExito"] = "Empleado actualizado correctamente.";
            return RedirectToAction("Usuarios");
        }

        //Empleado/Medicos
        [HttpGet]
        public async Task<IActionResult> Medicos()
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ListarMedicosAsync();
            var medicos = respuesta.Leer<List<Medico>>() ?? new();
            return View(medicos);
        }

        // GET: /Empleado/RegistrarMedico
        [HttpGet]
        public async Task<IActionResult> RegistrarMedico()
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ListarEspecialidadesAsync();
            ViewBag.Especialidades = respuesta.Leer<List<Especialidad>>() ?? new();
            return View(new RegistrarMedicoViewModel());
        }

        // Empleado/RegistrarMedico
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegistrarMedico(RegistrarMedicoViewModel modelo)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");
            if (!ModelState.IsValid)
            {
                var respEsp = await _servicioClinica.ListarEspecialidadesAsync();
                ViewBag.Especialidades = respEsp.Leer<List<Especialidad>>() ?? new();
                return View(modelo);
            }

            var datosMedico = new
            {
                codigo = modelo.Codigo,
                identificacion = modelo.Identificacion,
                nombre = modelo.Nombre,
                apellido1 = modelo.Apellido1,
                apellido2 = modelo.Apellido2,
                telefono_personal = modelo.TelefonoPersonal,
                correo_personal = modelo.CorreoPersonal,
                telefono_clinica = modelo.TelefonoClinica,
                correo_clinica = modelo.CorreoClinica,
                especialidades = modelo.Especialidades
            };

            var respuesta = await _servicioClinica.RegistrarMedicoAsync(datosMedico);

            if (!respuesta.FueExitoso)
            {
                ModelState.AddModelError(string.Empty, respuesta.Mensaje);
                var respEsp = await _servicioClinica.ListarEspecialidadesAsync();
                ViewBag.Especialidades = respEsp.Leer<List<Especialidad>>() ?? new();
                return View(modelo);
            }

            TempData["MensajeExito"] = "Médico registrado correctamente.";
            return RedirectToAction("Medicos");
        }

        // Empleado/DesactivarMedico
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DesactivarMedico(string codigo)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");
            var respuesta = await _servicioClinica.EliminarMedicoAsync(codigo);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("Medicos");
        }

        // Empleado/ReactivarMedico
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ReactivarMedico(string codigo)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");
            var respuesta = await _servicioClinica.ReactivarMedicoAsync(codigo);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("Medicos");
        }

        // GET: /Empleado/EditarMedico -> formulario con datos del médico
        [HttpGet]
        public async Task<IActionResult> EditarMedico(string codigo)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ObtenerMedicoAsync(codigo);
            var medico = respuesta.Leer<Medico>();

            if (medico == null)
            {
                TempData["MensajeError"] = "No se encontró el médico indicado.";
                return RedirectToAction("Medicos");
            }

            var respEsp = await _servicioClinica.ListarEspecialidadesAsync();
            ViewBag.Especialidades = respEsp.Leer<List<Especialidad>>() ?? new();
            ViewBag.CodigoMedico = codigo;

            return View(medico);
        }

        // POST: /Empleado/EditarMedico -> guardar cambios
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarMedico(string codigo, Medico modelo, List<int> EspecialidadesSeleccionadas)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var cambios = new
            {
                identificacion = modelo.Identificacion,
                nombre = modelo.Nombre,
                apellido1 = modelo.Apellido1,
                apellido2 = modelo.Apellido2,
                telefono_personal = modelo.TelefonoPersonal,
                correo_personal = modelo.CorreoPersonal,
                telefono_clinica = modelo.TelefonoClinica,
                correo_clinica = modelo.CorreoClinica
            };

            var respuesta = await _servicioClinica.ModificarMedicoAsync(codigo, cambios);

            if (!respuesta.FueExitoso)
            {
                TempData["MensajeError"] = respuesta.Mensaje;
                return RedirectToAction("EditarMedico", new { codigo });
            }

            if (EspecialidadesSeleccionadas != null && EspecialidadesSeleccionadas.Any())
            {
                var respEsp = await _servicioClinica.AsignarEspecialidadesAsync(codigo, EspecialidadesSeleccionadas);
                if (!respEsp.FueExitoso)
                {
                    TempData["MensajeError"] = respEsp.Mensaje;
                    return RedirectToAction("EditarMedico", new { codigo });
                }
            }

            TempData["MensajeExito"] = "Médico actualizado correctamente.";
            return RedirectToAction("Medicos");
        }

        // Empleado/Especialidades
        [HttpGet]
        public async Task<IActionResult> Especialidades()
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");
            var respuesta = await _servicioClinica.ListarEspecialidadesAsync();
            var especialidades = respuesta.Leer<List<Especialidad>>() ?? new();
            return View(especialidades);
        }

        // Empleado/RegistrarEspecialidad
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegistrarEspecialidad(RegistrarEspecialidadViewModel modelo)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.RegistrarEspecialidadAsync(modelo.Nombre);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("Especialidades");
        }

        // Empleado/EliminarEspecialidad
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EliminarEspecialidad(int idEspecialidad)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");
            var respuesta = await _servicioClinica.EliminarEspecialidadAsync(idEspecialidad);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("Especialidades");
        }

        // ------------------------------------------------------------------
        // Mantenimiento del catálogo de servicios que se cobran en las citas
        // ------------------------------------------------------------------

        // GET: /Empleado/Servicios
        [HttpGet]
        public async Task<IActionResult> Servicios(bool incluirInactivos = false)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ListarServiciosAsync();
            var servicios = respuesta.Leer<List<Servicio>>() ?? new();

            // El socket devuelve todos, así que acá se dejan fuera los
            // inactivos cuando no se piden
            if (!incluirInactivos)
            {
                servicios = servicios.Where(s => s.Activo).ToList();
            }

            ViewBag.IncluirInactivos = incluirInactivos;
            return View(servicios.OrderBy(s => s.Nombre).ToList());
        }

        // POST: /Empleado/RegistrarServicio
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegistrarServicio(string nombre, decimal precio, string? descripcion)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            if (precio < 0)
            {
                TempData["MensajeError"] = "El precio no puede ser negativo.";
                return RedirectToAction("Servicios");
            }

            var datosServicio = new
            {
                nombre,
                precio,
                descripcion = descripcion ?? string.Empty
            };

            var respuesta = await _servicioClinica.RegistrarServicioAsync(datosServicio);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("Servicios");
        }

        // GET: /Empleado/EditarServicio -> formulario con los datos del servicio
        [HttpGet]
        public async Task<IActionResult> EditarServicio(int idServicio)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ListarServiciosAsync();
            var servicios = respuesta.Leer<List<Servicio>>() ?? new();
            var servicio = servicios.FirstOrDefault(s => s.IdServicio == idServicio);

            if (servicio == null)
            {
                TempData["MensajeError"] = "No se encontró el servicio indicado.";
                return RedirectToAction("Servicios");
            }

            return View(servicio);
        }

        // POST: /Empleado/EditarServicio -> guardar cambios
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarServicio(int idServicio, string nombre,
                                                        decimal precio, string? descripcion)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            if (precio < 0)
            {
                TempData["MensajeError"] = "El precio no puede ser negativo.";
                return RedirectToAction("EditarServicio", new { idServicio });
            }

            var cambios = new
            {
                nombre,
                precio,
                descripcion = descripcion ?? string.Empty
            };

            var respuesta = await _servicioClinica.ModificarServicioAsync(idServicio, cambios);

            if (!respuesta.FueExitoso)
            {
                TempData["MensajeError"] = respuesta.Mensaje;
                return RedirectToAction("EditarServicio", new { idServicio });
            }

            TempData["MensajeExito"] = respuesta.Mensaje;
            return RedirectToAction("Servicios");
        }

        // POST: /Empleado/DesactivarServicio
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DesactivarServicio(int idServicio)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.EliminarServicioAsync(idServicio);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("Servicios", new { incluirInactivos = true });
        }

        // POST: /Empleado/ReactivarServicio
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ReactivarServicio(int idServicio)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ReactivarServicioAsync(idServicio);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("Servicios", new { incluirInactivos = true });
        }

        // GenerarHorarios
        [HttpGet]
        public async Task<IActionResult> GenerarHorarios()
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ListarMedicosAsync();
            var medicos = respuesta.Leer<List<Medico>>() ?? new();

            // Obtener nombres de especialidades
            var nombresEspecialidades = await ObtenerNombresEspecialidades();

            // Llenar los nombres de especialidades para cada médico
            foreach (var medico in medicos)
            {
                var nombres = new List<string>();

                // Intentar obtener por IDs
                foreach (var id in medico.EspecialidadesIds)
                {
                    if (nombresEspecialidades.ContainsKey(id))
                    {
                        nombres.Add(nombresEspecialidades[id]);
                    }
                }

                // Si no hay nombres por ID, intentar con strings directos
                if (!nombres.Any() && medico.EspecialidadesStrings.Any())
                {
                    nombres.AddRange(medico.EspecialidadesStrings);
                }

                medico.EspecialidadesNombres = nombres.Any()
                    ? string.Join(", ", nombres)
                    : "Sin especialidades";
            }

            ViewBag.Medicos = medicos;
            return View(new GenerarHorariosViewModel());
        }

        // Empleado/GenerarHorarios
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GenerarHorarios(GenerarHorariosViewModel modelo)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            // No tiene sentido abrir espacios de atención en una fecha que ya pasó
            if (!DateTime.TryParse(modelo.Fecha, out var fecha))
            {
                TempData["MensajeError"] = "La fecha indicada no es válida.";
                return RedirectToAction("GenerarHorarios");
            }

            if (fecha.Date < DateTime.Today)
            {
                TempData["MensajeError"] =
                    $"No se pueden generar horarios en una fecha pasada. " +
                    $"El {fecha:dd/MM/yyyy} ya pasó.";
                return RedirectToAction("GenerarHorarios");
            }

            var respuesta = await _servicioClinica.GenerarHorariosAsync(
                modelo.CodigoMedico, modelo.Fecha, modelo.HoraInicio, modelo.HoraFin);

            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return RedirectToAction("GenerarHorarios");
        }

        // GET: /Empleado/HorarioSemanal -> formulario de búsqueda del médico
        [HttpGet]
        public async Task<IActionResult> HorarioSemanal()
        {
            if (!EsEmpleado())
                return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ListarEspecialidadesAsync();

            ViewBag.Especialidades =
                respuesta.Leer<List<Especialidad>>() ?? new List<Especialidad>();

            var respMedicos = await _servicioClinica.ListarMedicosAsync();
            ViewBag.Medicos = respMedicos.Leer<List<Medico>>() ?? new List<Medico>();

            return View(new BuscarMedicoViewModel());
        }

        // POST: /Empleado/HorarioSemanal -> resultados de la búsqueda
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> HorarioSemanal(BuscarMedicoViewModel modelo)
        {
            if (!EsEmpleado())
                return RedirectToAction("Login", "Account");

            // Verificar que al menos se haya ingresado un criterio
            if (string.IsNullOrWhiteSpace(modelo.Nombre) &&
                string.IsNullOrWhiteSpace(modelo.Identificacion) &&
                !modelo.IdEspecialidad.HasValue)
            {
                TempData["MensajeError"] =
                    "Debe ingresar al menos un criterio de búsqueda.";

                var respEsp = await _servicioClinica.ListarEspecialidadesAsync();

                ViewBag.Especialidades =
                    respEsp.Leer<List<Especialidad>>() ?? new List<Especialidad>();

                return View(modelo);
            }

            var filtros = new
            {
                nombre = string.IsNullOrWhiteSpace(modelo.Nombre)
                    ? null
                    : modelo.Nombre.Trim(),

                identificacion = string.IsNullOrWhiteSpace(modelo.Identificacion)
                    ? null
                    : modelo.Identificacion.Trim(),

                ids_especialidad = modelo.IdEspecialidad.HasValue
                    ? new[] { modelo.IdEspecialidad.Value }
                    : null
            };

            var respuesta = await _servicioClinica.BuscarMedicosAsync(filtros);

            var medicos = respuesta.Leer<List<Medico>>() ?? new();

            // Obtener nombres de especialidades para mostrar
            var nombresEspecialidades = await ObtenerNombresEspecialidades();

            foreach (var medico in medicos)
            {
                var nombres = new List<string>();

                // Intentar obtener por IDs
                foreach (var id in medico.EspecialidadesIds)
                {
                    if (nombresEspecialidades.ContainsKey(id))
                    {
                        nombres.Add(nombresEspecialidades[id]);
                    }
                }

                // Si no hay nombres por ID, intentar con strings directos
                if (!nombres.Any() && medico.EspecialidadesStrings.Any())
                {
                    nombres.AddRange(medico.EspecialidadesStrings);
                }

                medico.EspecialidadesNombres = nombres.Any()
                    ? string.Join(", ", nombres)
                    : "Sin especialidades";
            }

            // Si hay un solo médico, ir directamente a su horario
            if (medicos.Count == 1)
            {
                return RedirectToAction(
                    "HorarioSemanalDetalle",
                    new { codigo = medicos[0].Codigo }
                );
            }

            // Si hay varios o ninguno, mostrar resultados
            ViewBag.CriterioNombre = modelo.Nombre;
            ViewBag.CriterioIdentificacion = modelo.Identificacion;
            ViewBag.CriterioEspecialidad = modelo.IdEspecialidad;

            return View("ResultadosBusquedaMedico", medicos);
        }

        // GET: /Empleado/HorarioSemanalDetalle
        [HttpGet]
        public async Task<IActionResult> HorarioSemanalDetalle(string codigo, string? fecha)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            // Determinar la fecha de referencia
            var fechaReferencia = DateTime.Today;
            if (!string.IsNullOrEmpty(fecha))
            {
                if (!DateTime.TryParse(fecha, out fechaReferencia))
                {
                    TempData["MensajeError"] = "La fecha proporcionada no es válida.";
                    return RedirectToAction("HorarioSemanal");
                }
            }

            // Calcular el lunes de la semana actual y de la semana seleccionada
            var lunesSemanaActual = CalcularLunes(DateTime.Today);
            var lunesSemanaSeleccionada = CalcularLunes(fechaReferencia);

            //  Calcular los límites de 1 mes
            var limiteInferior = lunesSemanaActual.AddMonths(-1);
            var limiteSuperior = lunesSemanaActual.AddMonths(1);

            // Validar que la semana seleccionada esté dentro del rango permitido
            if (lunesSemanaSeleccionada < limiteInferior || lunesSemanaSeleccionada > limiteSuperior)
            {
                TempData["MensajeError"] = "Solo se puede consultar hasta un mes atrás o un mes adelante de la semana actual.";
                lunesSemanaSeleccionada = lunesSemanaActual; // Volver a la semana actual
            }

            // Consultar horarios para la semana seleccionada
            var respHorarios = await _servicioClinica.ListarHorariosAsync(codigo, null);
            var horariosSemana = (respHorarios.Leer<List<Horario>>() ?? new())
                .Where(h => DateTime.TryParse(h.Fecha, out var f) &&
                            f.Date >= lunesSemanaSeleccionada.Date &&
                            f.Date <= lunesSemanaSeleccionada.AddDays(6).Date)
                .OrderBy(h => h.Fecha)
                .ThenBy(h => h.HoraInicio)
                .ToList();

            // Consultar citas para el médico
            var respCitas = await _servicioClinica.ListarCitasAsync(new { codigo_medico = codigo });
            var citas = respCitas.Leer<List<Cita>>() ?? new();

            // Construir las filas con horarios y citas
            var filas = new List<FilaHorarioSemanal>();
            foreach (var slot in horariosSemana)
            {
                var citaSlot = citas.FirstOrDefault(c =>
                    c.IdHorario == slot.IdHorario &&
                    c.Estado != "Cancelada");

                var fila = new FilaHorarioSemanal
                {
                    Horario = slot,
                    Cita = citaSlot
                };

                if (citaSlot != null)
                {
                    var respPaciente = await _servicioClinica.ObtenerPacienteAsync(citaSlot.IdentificacionPaciente);
                    var paciente = respPaciente.Leer<Paciente>();

                    fila.NombrePaciente = paciente?.NombreCompleto;
                    fila.TelefonoPaciente = paciente?.Telefono;
                    fila.CorreoPaciente = paciente?.Correo;
                }

                filas.Add(fila);
            }

            // 8. Calcular semanas anterior y siguiente
            var semanaAnterior = lunesSemanaSeleccionada.AddDays(-7);
            var semanaSiguiente = lunesSemanaSeleccionada.AddDays(7);

            //Obtener el nombre completo del médico para mostrarlo en pantalla
            var respMedico = await _servicioClinica.ObtenerMedicoAsync(codigo);
            var medico = respMedico.Leer<Medico>();
            ViewBag.NombreMedico = medico?.NombreCompleto ?? codigo; // si falla, muestra el código como respaldo

            // Configurar ViewBag para la vista
            ViewBag.CodigoMedico = codigo;
            ViewBag.NombreMedico = medico?.NombreCompleto ?? codigo;
            ViewBag.Lunes = lunesSemanaSeleccionada;
            ViewBag.SemanaAnterior = semanaAnterior;
            ViewBag.SemanaSiguiente = semanaSiguiente;
            ViewBag.PuedeRetroceder = semanaAnterior >= limiteInferior;
            ViewBag.PuedeAvanzar = semanaSiguiente <= limiteSuperior;

            return View(filas);
        }

        // GET: /Empleado/Clinica -> formulario con los datos de la clínica
        [HttpGet]
        public async Task<IActionResult> Clinica()
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var respuesta = await _servicioClinica.ObtenerClinicaAsync();

            var clinica = respuesta.Leer<Clinica>();

            if (clinica == null)
            {
                // Si no hay clínica registrada, mostrar formulario vacío
                clinica = new Clinica
                {
                    Nombre = "Clínica Salud y Bienestar"
                };
                TempData["MensajeInfo"] = "Aún no hay datos registrados. Complete el formulario para registrar la información de la clínica.";
            }

            return View(clinica);
        }

        // POST: /Empleado/Clinica -> guardar cambios
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Clinica(Clinica modelo)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            if (!ModelState.IsValid)
            {
                return View(modelo);
            }

            var datos = new
            {
                nombre = "Clínica Salud y Bienestar", // Nombre fijo
                direccion = modelo.Direccion,
                telefono = modelo.Telefono,
                correo = modelo.Correo,
                hora_apertura = modelo.HoraApertura,
                hora_cierre = modelo.HoraCierre,
                dias_laborales = modelo.DiasLaborales ?? new List<string>()
            };

            // Primero intentar modificar
            var respuestaModificar = await _servicioClinica.ModificarClinicaAsync(datos);

            if (respuestaModificar.FueExitoso)
            {
                TempData["MensajeExito"] = respuestaModificar.Mensaje;
                return RedirectToAction("Clinica");
            }

            // Si no se pudo modificar porque no existe, registrar
            var respuestaRegistrar = await _servicioClinica.RegistrarClinicaAsync(datos);

            if (respuestaRegistrar.FueExitoso)
            {
                TempData["MensajeExito"] = respuestaRegistrar.Mensaje;
                return RedirectToAction("Clinica");
            }

            TempData["MensajeError"] = respuestaRegistrar.Mensaje;
            return View(modelo);
        }

        // Método auxiliar para calcular el lunes de la semana
        private DateTime CalcularLunes(DateTime fecha)
        {
            int diasDesdeLunes = ((int)fecha.DayOfWeek + 6) % 7;
            return fecha.Date.AddDays(-diasDesdeLunes);
        }
    }
}