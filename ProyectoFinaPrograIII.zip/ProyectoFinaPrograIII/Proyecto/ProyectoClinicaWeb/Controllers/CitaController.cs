﻿using Microsoft.AspNetCore.Mvc;
using ProyectoClinicaWeb.Models;
using ProyectoClinicaWeb.Servicios;

namespace ProyectoClinicaWeb.Controllers
{
    public class CitaController : Controller
    {
        private readonly IServicioClinica _servicioClinica;

        public CitaController(IServicioClinica servicioClinica)
        {
            _servicioClinica = servicioClinica;
        }

        // Identificación real del paciente (guardada en la sesión al hacer login)
        private string? ReferenciaCliente => HttpContext.Session.GetString("Referencia");

        private bool EsEmpleado() => HttpContext.Session.GetString("TipoUsuario") == "Empleado";

        // Cliente que el empleado está atendiendo en este momento
        private string? ClienteGestionado => HttpContext.Session.GetString("ClienteGestionado");

        // Sobre quién se agenda la cita: si es un empleado, sobre el cliente que
        // está atendiendo; si es un cliente, sobre él mismo
        private string? IdentificacionParaCita()
        {
            return EsEmpleado() ? ClienteGestionado : ReferenciaCliente;
        }

        // A dónde volver después de agendar, cancelar o reprogramar
        private IActionResult VolverAlListado()
        {
            if (EsEmpleado())
            {
                return RedirectToAction("Gestion", new { identificacion = ClienteGestionado });
            }
            return RedirectToAction("Index");
        }

        // Cita -> historial de citas del cliente logueado
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            if (string.IsNullOrEmpty(ReferenciaCliente))
            {
                return RedirectToAction("Login", "Account");
            }

            var filtros = new { identificacion_paciente = ReferenciaCliente };
            var respuesta = await _servicioClinica.ListarCitasAsync(filtros);

            var citas = respuesta.Leer<List<Cita>>() ?? new();
            return View(citas);
        }

        // POST: /Cita/Agendar (viene desde Views/Medico/Horarios.cshtml)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Agendar(ReservarCitaView modelo)
        {
            var identificacion = IdentificacionParaCita();
            if (string.IsNullOrEmpty(identificacion))
            {
                return RedirectToAction("Login", "Account");
            }

            var datosCita = new
            {
                identificacion_paciente = identificacion,
                codigo_medico = modelo.CodigoMedico,
                id_horario = modelo.IdHorario
            };

            var respuesta = await _servicioClinica.ReservarCitaAsync(datosCita);

            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return VolverAlListado();
        }

        // POST: /Cita/Cancelar/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cancelar(int idCita)
        {
            var respuesta = await _servicioClinica.CancelarCitaAsync(idCita);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return VolverAlListado();
        }

        // GET: /Cita/Reprogramar/5 -> elegir un horario nuevo del mismo médico
        [HttpGet]
        public async Task<IActionResult> Reprogramar(int id)
        {
            var respuestaCitas = await _servicioClinica.ListarCitasAsync(
                new { identificacion_paciente = IdentificacionParaCita() });
            var cita = (respuestaCitas.Leer<List<Cita>>() ?? new())
                .FirstOrDefault(c => c.IdCita == id);

            if (cita is null)
            {
                TempData["MensajeError"] = "No se encontró la cita indicada.";
                return VolverAlListado();
            }

            var respuestaHorarios = await _servicioClinica.HorariosDisponiblesAsync(cita.CodigoMedico, null);
            var horarios = respuestaHorarios.Leer<List<Horario>>() ?? new();

            ViewBag.IdCita = id;
            return View(horarios);
        }

        // POST: /Cita/Reprogramar
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Reprogramar(ReprogramarCitaView modelo)
        {
            var respuesta = await _servicioClinica.ReprogramarCitaAsync(modelo.IdCita, modelo.IdHorario);
            TempData[respuesta.FueExitoso ? "MensajeExito" : "MensajeError"] = respuesta.Mensaje;
            return VolverAlListado();
        }

        // Cita/Gestion -> el empleado busca un cliente y administra sus citas
        [HttpGet]
        public async Task<IActionResult> Gestion(string? identificacion)
        {
            if (!EsEmpleado()) return RedirectToAction("Login", "Account");

            var citas = new List<Cita>();
            Paciente? paciente = null;

            if (!string.IsNullOrWhiteSpace(identificacion))
            {
                var respPaciente = await _servicioClinica.ObtenerPacienteAsync(identificacion);
                paciente = respPaciente.Leer<Paciente>();

                if (paciente is null)
                {
                    TempData["MensajeError"] = respPaciente.Mensaje;
                }
                else
                {
                    // Se recuerda a quién se está atendiendo, para que el flujo de
                    // agendar (especialidad -> médico -> horario) sepa sobre quién va
                    HttpContext.Session.SetString("ClienteGestionado", identificacion);

                    var respCitas = await _servicioClinica.ListarCitasAsync(
                        new { identificacion_paciente = identificacion });
                    citas = respCitas.Leer<List<Cita>>() ?? new();
                }
            }

            ViewBag.Identificacion = identificacion;
            ViewBag.Paciente = paciente;
            return View(citas);
        }
    }
}