﻿using ProyectoClinicaWeb.Models;

namespace ProyectoClinicaWeb.Servicios
{
    // traduce cada método de la interfaz a una acción
    public class ServicioClinica : IServicioClinica
    {
        private readonly ClienteSocket _socket;

       
        public ServicioClinica(IConfiguration configuracion)
        {
            var host = configuracion["Socket:Host"] ?? "localhost";
            var puerto = int.Parse(configuracion["Socket:Puerto"] ?? "8000");
            _socket = new ClienteSocket(host, puerto);
        }

        public Task<RespuestaSocket> IniciarSesionClienteAsync(string usuario, string contrasena) =>
            _socket.EnviarAsync("login_cliente", new { usuario, contrasena });

        public Task<RespuestaSocket> IniciarSesionEmpleadoAsync(string usuario, string contrasena) =>
            _socket.EnviarAsync("login_empleado", new { usuario, contrasena });

        public Task<RespuestaSocket> RegistrarClienteAsync(object datosCliente) =>
            _socket.EnviarAsync("registrar_paciente", datosCliente);

        public Task<RespuestaSocket> ListarEspecialidadesAsync() =>
            _socket.EnviarAsync("listar_especialidades");

        public Task<RespuestaSocket> ListarMedicosAsync() =>
            _socket.EnviarAsync("listar_medicos");

        public Task<RespuestaSocket> BuscarMedicosAsync(object filtros) =>
            _socket.EnviarAsync("buscar_medicos", filtros);
        public Task<RespuestaSocket> ObtenerMedicoAsync(string codigo) =>
            _socket.EnviarAsync("obtener_medico", new { codigo });

        public Task<RespuestaSocket> HorariosDisponiblesAsync(string codigoMedico, string? fecha) =>
            _socket.EnviarAsync("horarios_disponibles", new { codigo_medico = codigoMedico, fecha });

        public Task<RespuestaSocket> ListarCitasAsync(object filtros) =>
            _socket.EnviarAsync("listar_citas", filtros);

        public Task<RespuestaSocket> ReservarCitaAsync(object datosCita) =>
            _socket.EnviarAsync("reservar_cita", datosCita);

        public Task<RespuestaSocket> CancelarCitaAsync(int idCita) =>
            _socket.EnviarAsync("cancelar_cita", new { id_cita = idCita });

        public Task<RespuestaSocket> ReprogramarCitaAsync(int idCita, int idHorario) =>
            _socket.EnviarAsync("reprogramar_cita", new { id_cita = idCita, id_horario = idHorario });

        public Task<RespuestaSocket> ObtenerCitaAsync(int idCita) =>
            _socket.EnviarAsync("obtener_cita", new { id_cita = idCita });

        public Task<RespuestaSocket> ListarServiciosAsync(bool soloActivos = false) =>
            _socket.EnviarAsync("listar_servicios", new { solo_activos = soloActivos });

        public Task<RespuestaSocket> RegistrarServicioAsync(object datosServicio) =>
            _socket.EnviarAsync("registrar_servicio", datosServicio);

        public Task<RespuestaSocket> ModificarServicioAsync(int idServicio, object cambios) =>
            _socket.EnviarAsync("modificar_servicio", new { id_servicio = idServicio, cambios });

        public Task<RespuestaSocket> EliminarServicioAsync(int idServicio) =>
            _socket.EnviarAsync("eliminar_servicio", new { id_servicio = idServicio });

        public Task<RespuestaSocket> ReactivarServicioAsync(int idServicio) =>
            _socket.EnviarAsync("reactivar_servicio", new { id_servicio = idServicio });

        public Task<RespuestaSocket> GenerarFacturaAsync(int idCita, object lineas) =>
            _socket.EnviarAsync("generar_factura", new { id_cita = idCita, lineas });

        public Task<RespuestaSocket> ObtenerFacturaAsync(int idCita) =>
            _socket.EnviarAsync("obtener_factura", new { id_cita = idCita });

        public Task<RespuestaSocket> RegistrarPagoAsync(int idCita, string metodoPago) =>
            _socket.EnviarAsync("registrar_pago", new { id_cita = idCita, metodo_pago = metodoPago });

        public Task<RespuestaSocket> ListarUsuariosAsync(bool incluirInactivos) =>
            _socket.EnviarAsync("listar_usuarios", new { incluir_inactivos = incluirInactivos });

        public Task<RespuestaSocket> RegistrarUsuarioAsync(object datosUsuario) =>
            _socket.EnviarAsync("registrar_usuario", datosUsuario);

        public Task<RespuestaSocket> ModificarUsuarioAsync(string usuario, object cambios) =>
            _socket.EnviarAsync("modificar_usuario", new { usuario, cambios });

        public Task<RespuestaSocket> EliminarUsuarioAsync(string usuario) =>
            _socket.EnviarAsync("eliminar_usuario", new { usuario });

        public Task<RespuestaSocket> ReactivarUsuarioAsync(string usuario) =>
            _socket.EnviarAsync("reactivar_usuario", new { usuario });

        public Task<RespuestaSocket> RegistrarMedicoAsync(object datosMedico) =>
         _socket.EnviarAsync("registrar_medico", datosMedico);

        public Task<RespuestaSocket> ModificarMedicoAsync(string codigo, object cambios) =>
            _socket.EnviarAsync("modificar_medico", new { codigo, cambios });

        public Task<RespuestaSocket> EliminarMedicoAsync(string codigo) =>
            _socket.EnviarAsync("eliminar_medico", new { codigo });

        public Task<RespuestaSocket> ReactivarMedicoAsync(string codigo) =>
            _socket.EnviarAsync("reactivar_medico", new { codigo });

        public Task<RespuestaSocket> AsignarEspecialidadesAsync(string codigo, List<int> idsEspecialidad) =>
            _socket.EnviarAsync("asignar_especialidades", new { codigo, ids_especialidad = idsEspecialidad });

        public Task<RespuestaSocket> RegistrarEspecialidadAsync(string nombre) =>
            _socket.EnviarAsync("registrar_especialidad", new { nombre });

        public Task<RespuestaSocket> ModificarEspecialidadAsync(int idEspecialidad, string nombre) =>
            _socket.EnviarAsync("modificar_especialidad", new { id_especialidad = idEspecialidad, nombre });

        public Task<RespuestaSocket> EliminarEspecialidadAsync(int idEspecialidad) =>
            _socket.EnviarAsync("eliminar_especialidad", new { id_especialidad = idEspecialidad });

        public Task<RespuestaSocket> GenerarHorariosAsync(string codigoMedico, string fecha, string horaInicio, string horaFin) =>
            _socket.EnviarAsync("generar_horarios", new { codigo_medico = codigoMedico, fecha, hora_inicio = horaInicio, hora_fin = horaFin });

        public Task<RespuestaSocket> MarcarNoDisponibleAsync(string codigoMedico, string fecha, string? horaInicio) =>
            _socket.EnviarAsync("marcar_no_disponible", new { codigo_medico = codigoMedico, fecha, hora_inicio = horaInicio });

        public Task<RespuestaSocket> ListarHorariosAsync(string codigoMedico, string? fecha) =>
            _socket.EnviarAsync("listar_horarios", new { codigo_medico = codigoMedico, fecha });

        public Task<RespuestaSocket> ObtenerPacienteAsync(string identificacion) =>
            _socket.EnviarAsync("obtener_paciente", new { identificacion });

        public Task<RespuestaSocket> ModificarPacienteAsync(string identificacion, object cambios) =>
            _socket.EnviarAsync("modificar_paciente", new { identificacion, cambios });

        public Task<RespuestaSocket> ObtenerClinicaAsync() =>
             _socket.EnviarAsync("obtener_clinica");

        public Task<RespuestaSocket> ModificarClinicaAsync(object cambios) =>
            _socket.EnviarAsync("modificar_clinica", new { cambios });

        public Task<RespuestaSocket> RegistrarClinicaAsync(object datosClinica) =>
            _socket.EnviarAsync("registrar_clinica", datosClinica);
    }
}
