﻿using System.Threading.Tasks;
using ProyectoClinicaWeb.Models;

namespace ProyectoClinicaWeb.Servicios
{
    public interface IServicioClinica
    {
        // --- Cuentas / login ---
        Task<RespuestaSocket> IniciarSesionClienteAsync(string usuario, string contrasena);
        Task<RespuestaSocket> IniciarSesionEmpleadoAsync(string usuario, string contrasena);
        Task<RespuestaSocket> RegistrarClienteAsync(object datosCliente);

        // --- Médicos y especialidades ---
        Task<RespuestaSocket> ListarEspecialidadesAsync();  
        Task<RespuestaSocket> ListarMedicosAsync();
        Task<RespuestaSocket> BuscarMedicosAsync(object filtros);
        Task<RespuestaSocket> ObtenerMedicoAsync(string codigo);

        // --- Horarios y citas ---
        Task<RespuestaSocket> HorariosDisponiblesAsync(string codigoMedico, string? fecha);
        Task<RespuestaSocket> ListarCitasAsync(object filtros);
        Task<RespuestaSocket> ObtenerCitaAsync(int idCita);
        Task<RespuestaSocket> ReservarCitaAsync(object datosCita);
        Task<RespuestaSocket> CancelarCitaAsync(int idCita);
        Task<RespuestaSocket> ReprogramarCitaAsync(int idCita, int idHorario);

        // --- Facturación ---
        Task<RespuestaSocket> ListarServiciosAsync(bool soloActivos = false);
        Task<RespuestaSocket> RegistrarServicioAsync(object datosServicio);
        Task<RespuestaSocket> ModificarServicioAsync(int idServicio, object cambios);
        Task<RespuestaSocket> EliminarServicioAsync(int idServicio);
        Task<RespuestaSocket> ReactivarServicioAsync(int idServicio);
        Task<RespuestaSocket> GenerarFacturaAsync(int idCita, object lineas);
        Task<RespuestaSocket> ObtenerFacturaAsync(int idCita);
        Task<RespuestaSocket> RegistrarPagoAsync(int idCita, string metodoPago);

        // --- Mantenimiento de usuarios (clientes y empleados) ---
        Task<RespuestaSocket> ListarUsuariosAsync(bool incluirInactivos);
        Task<RespuestaSocket> RegistrarUsuarioAsync(object datosUsuario);
        Task<RespuestaSocket> ModificarUsuarioAsync(string usuario, object cambios);
        Task<RespuestaSocket> EliminarUsuarioAsync(string usuario);
        Task<RespuestaSocket> ReactivarUsuarioAsync(string usuario);

        // --- Mantenimiento de médicos ---
        Task<RespuestaSocket> RegistrarMedicoAsync(object datosMedico);
        Task<RespuestaSocket> ModificarMedicoAsync(string codigo, object cambios);
        Task<RespuestaSocket> EliminarMedicoAsync(string codigo);
        Task<RespuestaSocket> ReactivarMedicoAsync(string codigo);
        Task<RespuestaSocket> AsignarEspecialidadesAsync(string codigo, List<int> idsEspecialidad);

        // --- Mantenimiento de especialidades ---
        Task<RespuestaSocket> RegistrarEspecialidadAsync(string nombre);
        Task<RespuestaSocket> ModificarEspecialidadAsync(int idEspecialidad, string nombre);
        Task<RespuestaSocket> EliminarEspecialidadAsync(int idEspecialidad);

        // --- Mantenimiento de horarios ---
        Task<RespuestaSocket> GenerarHorariosAsync(string codigoMedico, string fecha, string horaInicio, string horaFin);
        Task<RespuestaSocket> MarcarNoDisponibleAsync(string codigoMedico, string fecha, string? horaInicio);
        Task<RespuestaSocket> ListarHorariosAsync(string codigoMedico, string? fecha);
        Task<RespuestaSocket> ObtenerPacienteAsync(string identificacion);

        // --- Datos de la clínica ---
        // --- Datos de la clínica ---
        Task<RespuestaSocket> ObtenerClinicaAsync();
        Task<RespuestaSocket> ModificarClinicaAsync(object cambios);
        Task<RespuestaSocket> RegistrarClinicaAsync(object datosClinica);

        // --- Mantenimiento de pacientes ---
        Task<RespuestaSocket> ModificarPacienteAsync(string identificacion, object cambios);
    }
}
