﻿using ProyectoClinicaWeb.Models;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

namespace ProyectoClinicaWeb.Servicios
{
    
        public class ClienteSocket
        {
            private readonly string _host;
            private readonly int _puerto;

            public ClienteSocket(string host, int puerto)
            {
                _host = host;
                _puerto = puerto;
            }

            // Abre una conexión nueva por cada petición 
            public async Task<RespuestaSocket> EnviarAsync(string accion, object? datos = null)
            {
                using var cliente = new TcpClient();

                try
                {
                    await cliente.ConnectAsync(_host, _puerto);
                }
                catch (SocketException)
                {
                    // El servidor de Python (ServidorAPI.py) no está corriendo
                    return new RespuestaSocket
                    {
                        Ok = false,
                        Mensaje = "No se pudo conectar con el servidor de la clínica. " +
                                   "Verifique que ServidorAPI.py esté en ejecución."
                    };
                }

                using var flujo = cliente.GetStream();

                // Se arma la petición exactamente en el formato que se espera
                var peticion = new { accion, datos = datos ?? new { } };
                var json = JsonSerializer.Serialize(peticion);
                var bytesEnvio = Encoding.UTF8.GetBytes(json + "\n");
                await flujo.WriteAsync(bytesEnvio);

                // Se lee hasta encontrar el salto de línea que marca el fin del mensaje
                var textoRespuesta = await LeerHastaSaltoDeLineaAsync(flujo);

                try
                {
                    var respuesta = JsonSerializer.Deserialize<RespuestaSocket>(textoRespuesta);
                    return respuesta ?? new RespuestaSocket { Ok = false, Mensaje = "Respuesta vacía del servidor." };
                }
                catch (JsonException)
                {
                    return new RespuestaSocket { Ok = false, Mensaje = "El servidor respondió algo que no es JSON válido." };
                }
            }

            private static async Task<string> LeerHastaSaltoDeLineaAsync(NetworkStream flujo)
            {
                var buffer = new byte[4096];
                var texto = new StringBuilder();

                while (true)
                {
                    int leidos = await flujo.ReadAsync(buffer);
                    if (leidos == 0) break; // el servidor cerró la conexión

                    texto.Append(Encoding.UTF8.GetString(buffer, 0, leidos));
                    if (texto.ToString().Contains('\n')) break;
                }

                // Se corta justo en el salto de línea, por si llegó algo extra después
                var completo = texto.ToString();
                var indice = completo.IndexOf('\n');
                return indice >= 0 ? completo[..indice] : completo;
            }
        
        }
}
