"""Carga un juego de datos grande y completo para la demostración del sistema.

BORRA todo lo que haya en MongoDB y en SQL Server y lo reemplaza por datos de
una clínica en operación: doce médicos, treinta pacientes, seis semanas de
horarios, y citas y facturas en todos los estados posibles.

Se ejecuta desde la raíz del proyecto:
    python cargar_datos_demo.py

Todas las cuentas quedan con la contraseña: demo123
"""

import random
from datetime import date, timedelta

from Entidades.cita import Cita
from Entidades.clinica import Clinica
from Entidades.detalle_factura import DetalleFactura
from Entidades.especialidad import Especialidad
from Entidades.factura import Factura
from Entidades.horario import Horario
from Entidades.medico import Medico
from Entidades.paciente import Paciente
from Entidades.servicio import Servicio
from Entidades.usuario import Usuario

from BL.seguridad import generar_hash
from DAL import repositorio, sqlserver
from DAL.mongo import guardar_documentos

CONTRASENA_DEMO = "demo123"

# Todas las fechas se calculan a partir de hoy, así el juego de datos sigue
# sirviendo cualquier día que se ejecute
HOY = date.today()

# Semilla fija: el juego de datos sale igual cada vez que se corre el script
random.seed(2026)

# Horas de atención de cada médico (slots de 30 minutos)
HORAS = ["08:00", "08:30", "09:00", "09:30",
         "10:00", "10:30", "11:00", "11:30"]

# Semanas que se generan: dos hacia atrás, la actual y tres hacia adelante
SEMANAS_ATRAS = 2
SEMANAS_ADELANTE = 3


# ---------------------------------------------------------------------------
# Datos base
# ---------------------------------------------------------------------------

# (id, nombre, activo)
ESPECIALIDADES = [
    (1, "Medicina General", True),
    (2, "Cardiología", True),
    (3, "Pediatría", True),
    (4, "Dermatología", True),
    (5, "Oftalmología", True),
    (6, "Ginecología", True),
    (7, "Ortopedia", True),
    (8, "Neurología", True),
    (9, "Psiquiatría", True),
    (10, "Odontología", True),
    (11, "Nutrición", False),          # inactiva
    (12, "Medicina del deporte", False),  # inactiva
]

# (codigo, identificacion, nombre, apellido1, apellido2, especialidades, activo)
MEDICOS = [
    ("M001", "105340221", "Carlos", "Ramírez", "Solano", [2, 1], True),
    ("M002", "204580332", "Laura", "Quesada", "Mora", [3, 1], True),
    ("M003", "108970445", "Andrés", "Mora", "Vega", [4, 2], True),
    ("M004", "303450778", "Patricia", "Núñez", "Rojas", [5], True),
    ("M005", "112230669", "Javier", "Fonseca", "Arias", [6, 1], True),
    ("M006", "115560998", "Mariana", "Castro", "Rivas", [7], True),
    ("M007", "205670334", "Diego", "Alvarado", "Pérez", [8, 1], True),
    ("M008", "118920556", "Silvia", "Bermúdez", "León", [9], True),
    ("M009", "402310889", "Rodrigo", "Chaves", "Muñoz", [10], True),
    ("M010", "109450223", "Gabriela", "Sandoval", "Cruz", [1, 3], True),
    ("M011", "207890112", "Fernando", "Zamora", "Gutiérrez", [2, 7], True),
    ("M012", "113670998", "Adriana", "Villalobos", "Soto", [4, 6], True),
    # Médicos eliminados: no deben aparecer en las búsquedas ni al agendar
    ("M013", "104450667", "Esteban", "Rojas", "Duarte", [1], False),
    ("M014", "306780445", "Karla", "Méndez", "Aguilar", [5], False),
]

# (identificacion, nacionalidad, nombre, apellido1, apellido2, padecimientos, tratamientos, activo)
PACIENTES = [
    ("102340567", "Costarricense", "María", "Jiménez", "Solís", ["Hipertensión"], ["Enalapril 10mg"], True),
    ("118450023", "Costarricense", "Roberto", "Vargas", "López", [], [], True),
    ("205340112", "Costarricense", "Ana", "Rodríguez", "Castro", ["Asma"], ["Salbutamol"], True),
    ("119260680", "Costarricense", "Emanuel", "Torres", "Núñez", [], [], True),
    ("401230456", "Nicaragüense", "Sofía", "Herrera", "Blanco", ["Diabetes tipo 2"], ["Metformina 850mg"], True),
    ("123456789", "Costarricense", "Diego", "Salas", "Ureña", [], [], True),
    ("305670889", "Panameña", "Valeria", "Campos", "Rojas", [], [], True),
    ("208990334", "Costarricense", "Luis", "Mena", "Alfaro", [], [], False),
    ("110230445", "Costarricense", "Andrea", "Solís", "Méndez", ["Migraña"], [], True),
    ("206780991", "Costarricense", "José", "Aguilar", "Ramírez", ["Colesterol alto"], ["Atorvastatina"], True),
    ("304560223", "Costarricense", "Carmen", "Bolaños", "Vega", [], [], True),
    ("107890334", "Salvadoreña", "Ricardo", "Pineda", "Cruz", ["Gastritis"], ["Omeprazol"], True),
    ("209340778", "Costarricense", "Lucía", "Fernández", "Mora", [], [], True),
    ("115670445", "Costarricense", "Manuel", "Ortiz", "Chaves", ["Hipertensión", "Diabetes tipo 2"], ["Losartán", "Insulina"], True),
    ("303450112", "Costarricense", "Gabriela", "Ruiz", "Sandoval", [], [], True),
    ("111230889", "Colombiana", "Sebastián", "Rojas", "Peña", [], [], True),
    ("207560334", "Costarricense", "Daniela", "Cordero", "Blanco", ["Anemia"], ["Sulfato ferroso"], True),
    ("305890667", "Costarricense", "Óscar", "Navarro", "León", [], [], True),
    ("113450223", "Costarricense", "Fabiola", "Guzmán", "Arias", [], [], True),
    ("208670991", "Costarricense", "Alberto", "Cruz", "Zamora", ["Artritis"], ["Ibuprofeno"], True),
    ("301230445", "Venezolana", "Isabel", "Márquez", "Torres", [], [], True),
    ("116780334", "Costarricense", "Tomás", "Delgado", "Vargas", [], [], True),
    ("204450778", "Costarricense", "Rebeca", "Espinoza", "Mata", ["Tiroides"], ["Levotiroxina"], True),
    ("309560112", "Costarricense", "Ignacio", "Brenes", "Quirós", [], [], True),
    ("117890223", "Costarricense", "Natalia", "Vega", "Sánchez", [], [], True),
    ("205230667", "Hondureña", "Marcos", "Reyes", "Flores", ["Obesidad"], [], True),
    ("308670445", "Costarricense", "Paula", "Arce", "Montero", [], [], True),
    ("114560889", "Costarricense", "Esteban", "Lobo", "Calderón", [], [], False),
    ("206340223", "Costarricense", "Verónica", "Trejos", "Alfaro", ["Depresión"], ["Sertralina"], True),
    ("302780991", "Costarricense", "Hugo", "Segura", "Barrantes", [], [], False),
]

# (nombre, precio, descripcion, activo)
SERVICIOS = [
    ("Consulta general", 25000, "Consulta médica general de valoración", True),
    ("Consulta especializada", 40000, "Consulta con médico especialista", True),
    ("Consulta de control", 18000, "Seguimiento de un tratamiento en curso", True),
    ("Toma de presión arterial", 5000, "Control de presión arterial", True),
    ("Aplicación de inyección", 8000, "Aplicación de medicamento inyectable", True),
    ("Electrocardiograma", 35000, "Estudio del ritmo cardíaco", True),
    ("Laboratorio básico", 18000, "Hemograma y química sanguínea", True),
    ("Ultrasonido", 45000, "Estudio por ultrasonido", True),
    ("Curación de herida", 12000, "Limpieza y vendaje", True),
    ("Vacunación", 15000, "Aplicación de vacuna", True),
    ("Consulta a domicilio", 60000, "Servicio descontinuado", False),
    ("Radiografía", 30000, "Servicio trasladado a otro proveedor", False),
]

METODOS_PAGO = ["Efectivo", "Tarjeta", "Sinpe"]


# ---------------------------------------------------------------------------
# MongoDB
# ---------------------------------------------------------------------------

def cargar_especialidades() -> list:
    """Guarda el catálogo de especialidades"""
    especialidades = [Especialidad(id_e, nombre, activo)
                      for id_e, nombre, activo in ESPECIALIDADES]
    repositorio.guardar_especialidades(especialidades)
    return especialidades


def cargar_medicos() -> list:
    """Guarda los médicos. Los teléfonos y correos se arman a partir del código"""
    medicos = []
    for i, (codigo, identificacion, nombre, ap1, ap2, especialidades, activo) in enumerate(MEDICOS):
        inicial = nombre[0].lower()
        apellido = ap1.lower().replace("í", "i").replace("é", "e").replace("ú", "u").replace("ñ", "n")
        medicos.append(Medico(
            codigo, identificacion, nombre, ap1, ap2,
            f"8342{1100 + i}", f"{inicial}.{apellido}@personal.com",
            f"2234{1100 + i}", f"{inicial}.{apellido}@clinica.com",
            list(especialidades), activo
        ))
    repositorio.guardar_medicos(medicos)
    return medicos


def cargar_pacientes() -> list:
    """Guarda los pacientes. Los teléfonos y correos se arman a partir del nombre"""
    pacientes = []
    for i, (identificacion, nacionalidad, nombre, ap1, ap2,
            padecimientos, tratamientos, activo) in enumerate(PACIENTES):
        limpio = (nombre + "." + ap1).lower()
        for viejo, nuevo in [("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"),
                             ("ú", "u"), ("ñ", "n")]:
            limpio = limpio.replace(viejo, nuevo)
        pacientes.append(Paciente(
            identificacion, nacionalidad, nombre, ap1, ap2,
            f"8{6000000 + i * 111111}"[:8], f"{limpio}@correo.com",
            padecimientos=list(padecimientos),
            tratamientos=list(tratamientos),
            activo=activo
        ))
    repositorio.guardar_pacientes(pacientes)
    return pacientes


def cargar_usuarios(medicos: list, pacientes: list) -> list:
    """Cuentas de empleados y de clientes.

    Se incluyen cuentas inactivas, que el sistema no debe dejar ingresar.
    """
    clave = generar_hash(CONTRASENA_DEMO)
    usuarios = [
        Usuario("admin", clave, "Administrador"),
        Usuario("admin2", clave, "Administrador"),
        Usuario("recepcion", clave, "Recepcionista"),
        Usuario("recepcion2", clave, "Recepcionista"),
        Usuario("recepcion3", clave, "Recepcionista"),
        # Empleado eliminado: no debe poder ingresar
        Usuario("recepcion.old", clave, "Recepcionista", activo=False),
    ]

    # Cuenta para los primeros seis médicos activos
    activos = [m for m in medicos if m.activo]
    for medico in activos[:6]:
        apellido = medico.apellido1.lower()
        for viejo, nuevo in [("á", "a"), ("é", "e"), ("í", "i"), ("ó", "o"),
                             ("ú", "u"), ("ñ", "n")]:
            apellido = apellido.replace(viejo, nuevo)
        usuarios.append(Usuario(f"dr.{apellido}", clave, "Medico",
                                referencia=medico.codigo))

    # Un cliente por paciente: el usuario es la identificación.
    # Los pacientes eliminados también tienen cuenta, pero inactiva.
    for paciente in pacientes:
        usuarios.append(Usuario(paciente.identificacion, clave, "Cliente",
                                referencia=paciente.identificacion,
                                activo=paciente.activo))

    repositorio.guardar_usuarios(usuarios)
    return usuarios


def cargar_clinica() -> Clinica:
    """Datos generales de la clínica"""
    clinica = Clinica(
        nombre="Clínica Salud y Bienestar",
        direccion="Av. Central 120, San José, Costa Rica",
        telefono="22340000",
        correo="info@saludybienestar.cr",
        hora_apertura="07:00",
        hora_cierre="19:00",
        dias_laborales=["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"]
    )
    repositorio.guardar_clinica(clinica)
    return clinica


def cargar_horarios(codigos: list) -> list:
    """Genera los slots de atención de cada médico activo.

    Cubre desde dos semanas atrás (para el historial) hasta tres semanas
    adelante, siempre de lunes a viernes.
    """
    horarios = []
    siguiente_id = 1

    lunes_actual = HOY - timedelta(days=HOY.weekday())
    primer_lunes = lunes_actual - timedelta(days=7 * SEMANAS_ATRAS)
    total_semanas = SEMANAS_ATRAS + 1 + SEMANAS_ADELANTE

    for semana in range(total_semanas):
        for dia in range(5):                      # lunes a viernes
            fecha = primer_lunes + timedelta(days=semana * 7 + dia)
            for codigo in codigos:
                for hora in HORAS:
                    fin_h = int(hora[:2])
                    fin_m = int(hora[3:]) + 30
                    if fin_m >= 60:
                        fin_h += 1
                        fin_m -= 60
                    horarios.append(Horario(
                        siguiente_id, codigo, fecha.strftime("%Y-%m-%d"),
                        hora, f"{fin_h:02d}:{fin_m:02d}"
                    ))
                    siguiente_id += 1

    repositorio.guardar_horarios(horarios)
    return horarios


# ---------------------------------------------------------------------------
# SQL Server
# ---------------------------------------------------------------------------

def limpiar_sql() -> None:
    """Borra las tablas de SQL Server y reinicia los contadores de id"""
    sqlserver.ejecutar_accion("DELETE FROM DetalleFactura")
    sqlserver.ejecutar_accion("DELETE FROM Facturas")
    sqlserver.ejecutar_accion("DELETE FROM Citas")
    sqlserver.ejecutar_accion("DELETE FROM Servicios")

    for tabla in ("DetalleFactura", "Facturas", "Citas", "Servicios"):
        sqlserver.ejecutar_accion(f"DBCC CHECKIDENT ('{tabla}', RESEED, 0)")


def cargar_servicios() -> list:
    """Catálogo de servicios facturables"""
    servicios = []
    for nombre, precio, descripcion, activo in SERVICIOS:
        servicio = Servicio(None, nombre, precio, descripcion, activo)
        servicio.id_servicio = repositorio.insertar_servicio(servicio)
        servicios.append(servicio)
    return servicios


def cargar_citas(horarios: list, pacientes: list) -> list:
    """Crea muchas citas en los tres estados, repartidas entre los pacientes.

    Las pasadas quedan Completadas, las futuras Reservadas, y algunas
    Canceladas. Cada cita ocupa su slot; las canceladas lo liberan.
    """
    activos = [p.identificacion for p in pacientes if p.activo]

    # Los slots se agrupan en pasados y futuros para repartir las citas
    hoy_texto = HOY.strftime("%Y-%m-%d")
    manana_texto = (HOY + timedelta(days=1)).strftime("%Y-%m-%d")

    pasados = [h for h in horarios if h.fecha < hoy_texto]
    de_hoy = [h for h in horarios if h.fecha == hoy_texto]
    de_manana = [h for h in horarios if h.fecha == manana_texto]
    futuros = [h for h in horarios if h.fecha > manana_texto]

    random.shuffle(pasados)
    random.shuffle(de_hoy)
    random.shuffle(de_manana)
    random.shuffle(futuros)

    planeadas = []

    # 260 citas ya atendidas: llenan las agendas de las semanas pasadas
    for i, slot in enumerate(pasados[:260]):
        planeadas.append((activos[i % len(activos)], slot, "Completada"))

    # 160 citas reservadas a futuro (se pueden reprogramar y cancelar)
    for i, slot in enumerate(futuros[:160]):
        planeadas.append((activos[(i + 7) % len(activos)], slot, "Reservada"))

    # 14 citas de HOY, atendidas: son las unicas que se pueden cobrar, porque el
    # sistema solo permite facturar las citas del dia
    for i, slot in enumerate(de_hoy[:14]):
        planeadas.append((activos[(i + 5) % len(activos)], slot, "Completada"))

    # 10 citas para mañana: NO se pueden cancelar (regla de los 2 días)
    for i, slot in enumerate(de_manana[:10]):
        planeadas.append((activos[(i + 3) % len(activos)], slot, "Reservada"))

    # 40 citas canceladas
    for i, slot in enumerate(futuros[160:200]):
        planeadas.append((activos[(i + 13) % len(activos)], slot, "Cancelada"))

    citas = []
    for identificacion, slot, estado in planeadas:
        slot.disponible = (estado == "Cancelada")

        cita = Cita(None, identificacion, slot.codigo_medico, slot.id_horario,
                    slot.fecha, slot.hora_inicio, estado)
        cita.id_cita = repositorio.insertar_cita(cita)
        citas.append(cita)

    repositorio.guardar_horarios(horarios)
    return citas


def cargar_facturas(citas: list, servicios: list) -> list:
    """Factura la mayoría de las citas completadas.

    Quedan pagadas unas, pendientes otras, y cinco citas completadas se dejan
    SIN factura para poder cobrarlas en vivo durante la presentación.
    """
    activos = [s for s in servicios if s.activo]
    hoy_texto = HOY.strftime("%Y-%m-%d")

    # Las citas de hoy son las que se van a cobrar en la demostración, así que
    # la mayoría queda sin factura. Las de días anteriores sí se facturan.
    completadas = [c for c in citas if c.estado == "Completada" and c.fecha != hoy_texto]
    de_hoy = [c for c in citas if c.estado == "Completada" and c.fecha == hoy_texto]

    # De las de hoy se facturan solo las cuatro primeras: así se ve el estado
    # "ya cobrada" y quedan diez para cobrar en vivo
    completadas = completadas + de_hoy[:4]

    facturas = []
    for i, cita in enumerate(completadas):
        # Entre uno y tres servicios por factura
        elegidos = random.sample(activos, random.randint(1, 3))
        lineas = [(s, random.randint(1, 2)) for s in elegidos]
        subtotal = sum(s.precio * cantidad for s, cantidad in lineas)

        # Dos de cada tres facturas quedan pagadas
        pagada = (i % 3 != 2)
        estado = "Pagada" if pagada else "Pendiente"
        metodo = random.choice(METODOS_PAGO) if pagada else None

        factura = Factura(None, cita.id_cita, cita.identificacion_paciente,
                          subtotal=subtotal, estado=estado, metodo_pago=metodo)
        factura.id_factura = repositorio.insertar_factura(factura)

        for servicio, cantidad in lineas:
            repositorio.insertar_detalle_factura(DetalleFactura(
                None, factura.id_factura, servicio.id_servicio,
                cantidad, servicio.precio
            ))

        facturas.append(factura)

    return facturas


# ---------------------------------------------------------------------------

def main():
    """Borra todo y vuelve a cargar el juego de datos de la demostración"""
    print("Limpiando MongoDB...")
    for coleccion in ("pacientes", "doctores", "especialidades", "horarios",
                      "usuarios", "clinica"):
        guardar_documentos(coleccion, [])

    print("Limpiando SQL Server...")
    limpiar_sql()

    print("\nCargando MongoDB:")
    especialidades = cargar_especialidades()
    inactivas = len([e for e in especialidades if not e.activo])
    print(f"  especialidades: {len(especialidades)} ({inactivas} inactivas)")

    medicos = cargar_medicos()
    activos = [m for m in medicos if m.activo]
    print(f"  médicos: {len(medicos)} ({len(activos)} activos, "
          f"{len(medicos) - len(activos)} inactivos)")

    pacientes = cargar_pacientes()
    pac_activos = len([p for p in pacientes if p.activo])
    print(f"  pacientes: {len(pacientes)} ({pac_activos} activos, "
          f"{len(pacientes) - pac_activos} inactivos)")

    usuarios = cargar_usuarios(medicos, pacientes)
    usr_inactivos = len([u for u in usuarios if not u.activo])
    print(f"  usuarios: {len(usuarios)} ({usr_inactivos} inactivos)")

    cargar_clinica()
    print("  datos de la clínica: cargados")

    horarios = cargar_horarios([m.codigo for m in activos])
    semanas = SEMANAS_ATRAS + 1 + SEMANAS_ADELANTE
    print(f"  horarios: {len(horarios)} slots en {semanas} semanas")

    print("\nCargando SQL Server:")
    servicios = cargar_servicios()
    serv_inactivos = len([s for s in servicios if not s.activo])
    print(f"  servicios: {len(servicios)} ({serv_inactivos} inactivos)")

    citas = cargar_citas(horarios, pacientes)
    completadas = len([c for c in citas if c.estado == "Completada"])
    reservadas = len([c for c in citas if c.estado == "Reservada"])
    canceladas = len([c for c in citas if c.estado == "Cancelada"])
    print(f"  citas: {len(citas)} ({completadas} completadas, "
          f"{reservadas} reservadas, {canceladas} canceladas)")

    facturas = cargar_facturas(citas, servicios)
    pagadas = len([f for f in facturas if f.estado == "Pagada"])
    total_facturado = sum(f.total for f in facturas if f.estado == "Pagada")
    print(f"  facturas: {len(facturas)} ({pagadas} pagadas, "
          f"{len(facturas) - pagadas} pendientes)")
    print(f"  cobrado: {total_facturado:,.2f} colones")
    hoy_texto = HOY.strftime("%Y-%m-%d")
    cobrables = [c for c in citas
                 if c.fecha == hoy_texto and c.estado != "Cancelada"]
    print(f"  citas de HOY: {len(cobrables)} "
          f"({completadas - len(facturas)} sin factura, para cobrar en vivo)")

    print("\nListo. Todas las cuentas usan la contraseña:", CONTRASENA_DEMO)
    print("\n  Empleados:  admin | admin2 | recepcion | recepcion2 | recepcion3")
    print("  Médicos:    dr.ramirez | dr.quesada | dr.mora | dr.nunez | dr.fonseca | dr.castro")
    print("  Clientes:   la identificación del paciente (ej: 102340567)")
    print("  Inactivos:  recepcion.old | 208990334 | 114560889 | 302780991")


if __name__ == "__main__":
    main()
