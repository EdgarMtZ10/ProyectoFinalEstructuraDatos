// ===========================================================================
// SCRIPT DE ESTRUCTURA - MONGODB
// Crea la base de datos "clinica" con sus colecciones, validaciones e índices.
// Basado en Docs/diccionario-mongo.md
//
// Ejecutar desde la raíz del proyecto:
//     mongosh < Datos/mongo/script.js
// ===========================================================================

use("clinica");

// --- Se eliminan las colecciones si ya existen (para poder repetir el script) ---
db.clinica.drop();
db.especialidades.drop();
db.pacientes.drop();
db.doctores.drop();
db.horarios.drop();
db.usuarios.drop();


// ---------------------------------------------------------------------------
// Colección: clinica
// ---------------------------------------------------------------------------
db.createCollection("clinica", {
    validator: {
        $jsonSchema: {
            bsonType: "object",
            required: ["nombre", "direccion", "telefono", "correo",
                       "horaApertura", "horaCierre", "diasLaborales"],
            properties: {
                nombre:        { bsonType: "string" },
                direccion:     { bsonType: "string" },
                telefono:      { bsonType: "string" },
                correo:        { bsonType: "string" },
                horaApertura:  { bsonType: "string" },
                horaCierre:    { bsonType: "string" },
                diasLaborales: { bsonType: "array", items: { bsonType: "string" } }
            }
        }
    }
});


// ---------------------------------------------------------------------------
// Colección: especialidades
// ---------------------------------------------------------------------------
db.createCollection("especialidades", {
    validator: {
        $jsonSchema: {
            bsonType: "object",
            required: ["idEspecialidad", "nombre"],
            properties: {
                idEspecialidad: { bsonType: "int" },
                nombre:         { bsonType: "string" },
                activo:         { bsonType: "bool" }
            }
        }
    }
});

db.especialidades.createIndex({ idEspecialidad: 1 }, { unique: true });


// ---------------------------------------------------------------------------
// Colección: pacientes
// ---------------------------------------------------------------------------
db.createCollection("pacientes", {
    validator: {
        $jsonSchema: {
            bsonType: "object",
            required: ["identificacion", "nacionalidad", "nombre", "apellido1",
                       "telefono", "correo"],
            properties: {
                identificacion: { bsonType: "string" },
                nacionalidad:   { bsonType: "string" },
                nombre:         { bsonType: "string" },
                apellido1:      { bsonType: "string" },
                apellido2:      { bsonType: "string" },
                telefono:       { bsonType: "string" },
                correo:         { bsonType: "string" },
                padecimientos:  { bsonType: "array", items: { bsonType: "string" } },
                tratamientos:   { bsonType: "array", items: { bsonType: "string" } },
                activo:         { bsonType: "bool" }
            }
        }
    }
});

db.pacientes.createIndex({ identificacion: 1 }, { unique: true });


// ---------------------------------------------------------------------------
// Colección: doctores
// especialidades[] referencia a especialidades.idEspecialidad
// ---------------------------------------------------------------------------
db.createCollection("doctores", {
    validator: {
        $jsonSchema: {
            bsonType: "object",
            required: ["codigo", "identificacion", "nombre", "apellido1",
                       "telefonoPersonal", "correoPersonal",
                       "telefonoClinica", "correoClinica"],
            properties: {
                codigo:           { bsonType: "string" },
                identificacion:   { bsonType: "string" },
                nombre:           { bsonType: "string" },
                apellido1:        { bsonType: "string" },
                apellido2:        { bsonType: "string" },
                telefonoPersonal: { bsonType: "string" },
                correoPersonal:   { bsonType: "string" },
                telefonoClinica:  { bsonType: "string" },
                correoClinica:    { bsonType: "string" },
                especialidades:   { bsonType: "array", items: { bsonType: "int" } },
                activo:           { bsonType: "bool" }
            }
        }
    }
});

db.doctores.createIndex({ codigo: 1 }, { unique: true });
db.doctores.createIndex({ identificacion: 1 }, { unique: true });


// ---------------------------------------------------------------------------
// Colección: horarios
// codigoMedico referencia a doctores.codigo
// ---------------------------------------------------------------------------
db.createCollection("horarios", {
    validator: {
        $jsonSchema: {
            bsonType: "object",
            required: ["idHorario", "codigoMedico", "fecha",
                       "horaInicio", "horaFin", "disponible"],
            properties: {
                idHorario:    { bsonType: "int" },
                codigoMedico: { bsonType: "string" },
                fecha:        { bsonType: ["date", "string"] },
                horaInicio:   { bsonType: "string" },
                horaFin:      { bsonType: "string" },
                disponible:   { bsonType: "bool" },
                activo:       { bsonType: "bool" }
            }
        }
    }
});

db.horarios.createIndex({ idHorario: 1 }, { unique: true });
db.horarios.createIndex({ codigoMedico: 1, fecha: 1 });


// ---------------------------------------------------------------------------
// Colección: usuarios
// referencia apunta a doctores.codigo cuando el rol es Medico
// ---------------------------------------------------------------------------
db.createCollection("usuarios", {
    validator: {
        $jsonSchema: {
            bsonType: "object",
            required: ["usuario", "contrasena", "rol", "activo"],
            properties: {
                usuario:    { bsonType: "string" },
                contrasena: { bsonType: "string" },
                rol:        { enum: ["Cliente", "Administrador", "Recepcionista", "Medico"] },
                referencia: { bsonType: ["string", "null"] },   // null cuando la cuenta no apunta a nadie
                activo:     { bsonType: "bool" }
            }
        }
    }
});

db.usuarios.createIndex({ usuario: 1 }, { unique: true });


print("Estructura de la base de datos 'clinica' creada correctamente.");
