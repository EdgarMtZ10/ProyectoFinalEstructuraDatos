
---Creacion de la base de datos

IF DB_ID('ClinicaSaludBienestar') IS NOT NULL
BEGIN
    ALTER DATABASE ClinicaSaludBienestar SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE ClinicaSaludBienestar;
END
GO

CREATE DATABASE ClinicaSaludBienestar;
GO

USE ClinicaSaludBienestar;
GO



-- Tabla: Citas
-- Almacena las citas medicas agendadas.
-- identificacionPaciente, codigoMedico e idHorario son referencias logicas

CREATE TABLE Citas (
    idCita                  INT IDENTITY(1,1) PRIMARY KEY,
    identificacionPaciente  VARCHAR(20)   NOT NULL,
    codigoMedico            VARCHAR(20)   NOT NULL,
    idHorario               INT           NOT NULL,
    fecha                   DATE          NOT NULL,
    hora                    TIME          NOT NULL,
    estado                  VARCHAR(15)   NOT NULL
        CONSTRAINT DF_Citas_estado DEFAULT ('Reservada')
        CONSTRAINT CK_Citas_estado CHECK (estado IN ('Reservada', 'Cancelada', 'Completada'))
);
GO

-- Evita agendar dos citas en el mismo slot de horario
CREATE UNIQUE INDEX UQ_Citas_idHorario ON Citas(idHorario)
    WHERE estado <> 'Cancelada';
GO

-- Acelera busquedas por paciente y por medico
CREATE INDEX IX_Citas_identificacionPaciente ON Citas(identificacionPaciente);
CREATE INDEX IX_Citas_codigoMedico_fecha ON Citas(codigoMedico, fecha);
GO


-- Tabla: Servicios
-- Catalogo de servicios facturables.

CREATE TABLE Servicios (
    idServicio    INT IDENTITY(1,1) PRIMARY KEY,
    nombre        VARCHAR(100)    NOT NULL,
    descripcion   VARCHAR(255)    NULL,
    precio        DECIMAL(10,2)   NOT NULL
        CONSTRAINT CK_Servicios_precio CHECK (precio >= 0),
    activo        BIT             NOT NULL
        CONSTRAINT DF_Servicios_activo DEFAULT (1)
);
GO



-- Tabla: Facturas
-- Encabezado de cada factura emitida. Se enlaza a una cita.

CREATE TABLE Facturas (
    idFactura               INT IDENTITY(1,1) PRIMARY KEY,
    idCita                  INT             NOT NULL,
    identificacionPaciente  VARCHAR(20)     NOT NULL,
    fechaEmision            DATETIME2       NOT NULL
        CONSTRAINT DF_Facturas_fechaEmision DEFAULT (SYSDATETIME()),
    subtotal                DECIMAL(10,2)   NOT NULL
        CONSTRAINT CK_Facturas_subtotal CHECK (subtotal >= 0),
    impuesto                DECIMAL(10,2)   NOT NULL
        CONSTRAINT CK_Facturas_impuesto CHECK (impuesto >= 0),
    total                   DECIMAL(10,2)   NOT NULL
        CONSTRAINT CK_Facturas_total CHECK (total >= 0),
    estado                  VARCHAR(15)     NOT NULL
        CONSTRAINT DF_Facturas_estado DEFAULT ('Pendiente')
        CONSTRAINT CK_Facturas_estado CHECK (estado IN ('Pendiente', 'Pagada', 'Anulada')),
    metodoPago              VARCHAR(20)     NULL,

    CONSTRAINT FK_Facturas_Citas FOREIGN KEY (idCita) REFERENCES Citas(idCita)
);
GO

-- Una cita tiene a lo sumo una factura
CREATE UNIQUE INDEX UQ_Facturas_idCita ON Facturas(idCita);
CREATE INDEX IX_Facturas_identificacionPaciente ON Facturas(identificacionPaciente);
GO



-- Tabla: DetalleFactura
-- Lineas de servicios que van cada factura.

CREATE TABLE DetalleFactura (
    idDetalle       INT IDENTITY(1,1) PRIMARY KEY,
    idFactura       INT             NOT NULL,
    idServicio      INT             NOT NULL,
    cantidad        INT             NOT NULL
        CONSTRAINT CK_DetalleFactura_cantidad CHECK (cantidad > 0),
    precioUnitario  DECIMAL(10,2)   NOT NULL
        CONSTRAINT CK_DetalleFactura_precioUnitario CHECK (precioUnitario >= 0),
    subtotalLinea   DECIMAL(10,2)   NOT NULL
        CONSTRAINT CK_DetalleFactura_subtotalLinea CHECK (subtotalLinea >= 0),

    CONSTRAINT FK_DetalleFactura_Facturas FOREIGN KEY (idFactura) REFERENCES Facturas(idFactura),
    CONSTRAINT FK_DetalleFactura_Servicios FOREIGN KEY (idServicio) REFERENCES Servicios(idServicio)
);
GO

CREATE INDEX IX_DetalleFactura_idFactura ON DetalleFactura(idFactura);
GO


/* ============================================================================
   DATOS DE PRUEBA
   ============================================================================ */

-- Servicios de ejemplo
INSERT INTO Servicios (nombre, descripcion, precio, activo) VALUES
('Consulta general', 'Consulta medica general de valoracion', 25000.00, 1),
('Consulta especializada', 'Consulta con medico especialista', 40000.00, 1),
('Toma de presion arterial', 'Control de presion arterial', 5000.00, 1),
('Aplicacion de inyeccion', 'Aplicacion de medicamento inyectable', 8000.00, 1);
GO

-- Citas de ejemplo 
INSERT INTO Citas (identificacionPaciente, codigoMedico, idHorario, fecha, hora, estado) VALUES
('101110111', 'MED-001', 1, '2026-08-03', '08:00', 'Completada'),
('205230456', 'MED-002', 5, '2026-08-05', '09:30', 'Reservada'),
('304450789', 'MED-001', 9, '2026-08-06', '10:00', 'Cancelada');
GO

-- Factura de ejemplo
INSERT INTO Facturas (idCita, identificacionPaciente, subtotal, impuesto, total, estado, metodoPago) VALUES
(1, '101110111', 25000.00, 3250.00, 28250.00, 'Pagada', 'Tarjeta');
GO

INSERT INTO DetalleFactura (idFactura, idServicio, cantidad, precioUnitario, subtotalLinea) VALUES
(1, 1, 1, 25000.00, 25000.00);
GO

PRINT 'Base de datos ClinicaSaludBienestar creada correctamente.';
GO