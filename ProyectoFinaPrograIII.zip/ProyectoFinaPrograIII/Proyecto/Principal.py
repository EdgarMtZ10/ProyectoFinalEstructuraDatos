"""Punto de entrada del sistema de gestión de clínica"""

from BL.servicio_especialidades import ServicioEspecialidades
from BL.servicio_medicos import ServicioMedicos
from BL.servicio_horarios import ServicioHorarios
from BL.servicio_pacientes import ServicioPacientes
from BL.servicio_citas import ServicioCitas
from BL.servicio_busquedas import ServicioBusquedas
from UI import menu_principal


if __name__ == "__main__":
    serv_especialidades = ServicioEspecialidades()
    serv_medicos        = ServicioMedicos(serv_especialidades)
    serv_horarios       = ServicioHorarios(serv_medicos)
    serv_pacientes      = ServicioPacientes()
    serv_citas          = ServicioCitas(serv_horarios, serv_pacientes, serv_medicos)
    serv_busquedas      = ServicioBusquedas(serv_medicos, serv_especialidades, serv_horarios)

    servicios = {
        "especialidades": serv_especialidades,
        "medicos":        serv_medicos,
        "horarios":       serv_horarios,
        "pacientes":      serv_pacientes,
        "citas":          serv_citas,
        "busquedas":      serv_busquedas,
    }

    menu_principal.ejecutar(servicios)
