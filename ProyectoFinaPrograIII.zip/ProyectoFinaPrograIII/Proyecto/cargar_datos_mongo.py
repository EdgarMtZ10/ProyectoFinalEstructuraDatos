"""Carga inicial: pasa los datos de los archivos JSON a las colecciones de MongoDB.

Se ejecuta una sola vez desde la raíz del proyecto:
    python cargar_datos_mongo.py
"""

import os
from DAL.gestor import cargar_json
from DAL.mongo import guardar_documentos, cerrar_conexion

# Cada archivo JSON con su colección correspondiente
ARCHIVOS = [
    ("pacientes.json", "pacientes"),
    ("medicos.json", "doctores"),
    ("especialidades.json", "especialidades"),
    ("horarios.json", "horarios"),
    ("usuarios.json", "usuarios")
]


def main():
    """Copia el contenido de cada JSON a su colección en MongoDB"""
    for nombre_archivo, coleccion in ARCHIVOS:
        ruta = os.path.join("Datos", nombre_archivo)
        datos = cargar_json(ruta)
        guardar_documentos(coleccion, datos)
        print(f"{coleccion}: {len(datos)} documentos cargados.")

    cerrar_conexion()
    print("Carga inicial terminada.")


if __name__ == "__main__":
    main()
