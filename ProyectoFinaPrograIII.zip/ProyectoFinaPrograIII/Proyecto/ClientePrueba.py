"""Cliente de prueba de la API por sockets.

Sirve para probar el servidor sin necesidad del proyecto web.

Ejemplos:
    python ClientePrueba.py ping
    python ClientePrueba.py listar_medicos
    python ClientePrueba.py horarios_disponibles '{"codigo_medico": "M001"}'
"""

import json
import socket
import sys

HOST = "localhost"
PUERTO = 8000


def enviar(accion: str, datos: dict) -> dict:
    """Envía una acción al servidor y retorna la respuesta"""
    peticion = json.dumps({"accion": accion, "datos": datos}, ensure_ascii=False) + "\n"

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as cliente:
        cliente.connect((HOST, PUERTO))
        cliente.sendall(peticion.encode("utf-8"))

        partes = []
        while True:
            pedazo = cliente.recv(4096)
            if not pedazo:
                break
            partes.append(pedazo.decode("utf-8"))
            if "\n" in partes[-1]:
                break

    return json.loads("".join(partes))


if __name__ == "__main__":
    accion = sys.argv[1] if len(sys.argv) > 1 else "ping"
    datos = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}

    respuesta = enviar(accion, datos)
    print(json.dumps(respuesta, indent=2, ensure_ascii=False))
