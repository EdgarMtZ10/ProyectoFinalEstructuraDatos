============================================================================
DICCIONARIO DE DATOS - MONGODB
============================================================================

Motor documental. Almacena los datos personales de doctores y clientes,
especialidades, datos de la clínica, horarios de disponibilidad y los usuarios
del sistema con su rol. Los tipos indicados corresponden a tipos BSON.
Documento de referencia: define cada colección, sus campos y tipos. No es un
script de creación.

----------------------------------------------------------------------------
Colección: clinica
Almacena los datos generales de la clínica.
----------------------------------------------------------------------------
Campo          | Tipo (BSON)     | Descripción
---------------|-----------------|--------------------------------------------
_id            | ObjectId        | Identificador interno del documento
nombre         | String          | Nombre de la clínica
direccion      | String          | Dirección física
telefono       | String          | Teléfono de la clínica
correo         | String          | Correo institucional
horaApertura   | String          | Hora de apertura (ej. "07:00")
horaCierre     | String          | Hora de cierre (ej. "22:00")
diasLaborales  | Array<String>   | Días laborales (lunes a sábado)


----------------------------------------------------------------------------
Colección: especialidades
Almacena las especialidades médicas disponibles en la clínica.
----------------------------------------------------------------------------
Campo           | Tipo (BSON) | Descripción
----------------|-------------|-----------------------------------------------
_id             | ObjectId    | Identificador interno del documento
idEspecialidad  | Int32       | Identificador único de la especialidad
nombre          | String      | Nombre de la especialidad


----------------------------------------------------------------------------
Colección: pacientes
Almacena la información personal y médica de los clientes.
----------------------------------------------------------------------------
Campo           | Tipo (BSON)     | Descripción
----------------|-----------------|-------------------------------------------
_id             | ObjectId        | Identificador interno del documento
identificacion  | String          | Número de identificación (único)
nacionalidad    | String          | Nacionalidad del paciente
nombre          | String          | Nombre del paciente
apellido1       | String          | Primer apellido
apellido2       | String          | Segundo apellido
telefono        | String          | Número telefónico
correo          | String          | Correo electrónico
padecimientos   | Array<String>   | Lista de padecimientos registrados
tratamientos    | Array<String>   | Lista de tratamientos recibidos


----------------------------------------------------------------------------
Colección: doctores
Almacena la información personal de los doctores y sus datos de contacto.
----------------------------------------------------------------------------
Campo             | Tipo (BSON)   | Descripción
------------------|---------------|---------------------------------------------
_id               | ObjectId      | Identificador interno del documento
codigo            | String        | Código único del médico
identificacion    | String        | Número de identificación
nombre            | String        | Nombre del médico
apellido1         | String        | Primer apellido
apellido2         | String        | Segundo apellido
telefonoPersonal  | String        | Teléfono personal
correoPersonal    | String        | Correo personal
telefonoClinica   | String        | Teléfono asignado por la clínica
correoClinica     | String        | Correo institucional de la clínica
especialidades    | Array<Int32>  | Referencias a idEspecialidad


----------------------------------------------------------------------------
Colección: horarios
Almacena los horarios de disponibilidad de cada médico como slots de 30 min.
----------------------------------------------------------------------------
Campo         | Tipo (BSON) | Descripción
--------------|-------------|-------------------------------------------------
_id           | ObjectId    | Identificador interno del documento
idHorario     | Int32       | Identificador único del slot
codigoMedico  | String      | Referencia a doctores.codigo
fecha         | Date        | Fecha del slot
horaInicio    | String      | Hora de inicio ("HH:MM")
horaFin       | String      | Hora de fin ("HH:MM")
disponible    | Boolean     | Indica si el slot está libre


----------------------------------------------------------------------------
Colección: usuarios
Almacena los usuarios del sistema y su rol.
----------------------------------------------------------------------------
Campo        | Tipo (BSON) | Descripción
-------------|-------------|--------------------------------------------------
_id          | ObjectId    | Identificador interno del documento
usuario      | String      | Nombre de usuario (único)
contrasena   | String      | Contraseña almacenada como hash
rol          | String      | Rol del usuario (Administrador, Recepcionista, Medico)
referencia   | String      | Código de médico o identificación asociada (opcional)
activo       | Boolean     | Indica si la cuenta está activa


----------------------------------------------------------------------------
Relaciones lógicas (dentro de MongoDB)
----------------------------------------------------------------------------
horarios.codigoMedico        -> doctores.codigo           (los horarios pertenecen a un médico)
doctores.especialidades[]    -> especialidades.idEspecialidad  (un médico ejerce varias)
usuarios.referencia          -> doctores.codigo           (opcional, cuando el rol es Medico)