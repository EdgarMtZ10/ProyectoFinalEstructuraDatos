# Manual de conexión y operación de la API

Cómo levantar el servidor de la clínica y cómo consumirlo desde otro programa
(por ejemplo el ProyectoClinicaWeb).

La lista completa de acciones está en [api-socket.md](api-socket.md).

---

## 1. Qué es

El proyecto de Python expone su lógica de negocio por un **socket TCP**, para
que otro programa la use sin repetir las reglas del negocio.

```
ProyectoClinicaWeb  ──socket TCP──>  API  ──>  BL  ──>  MongoDB / SQL Server
```

**No es HTTP.** No se puede consultar desde el navegador ni desde Postman.

La aplicación de consola (`Principal.py`) sigue funcionando aparte.

---

## 2. Instalación

Se necesita Python 3.9 o superior, MongoDB y SQL Server.

### Windows

```
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

El driver de SQL Server (`ODBC Driver 17 for SQL Server`) se descarga del sitio
de Microsoft. Si ya tenés SQL Server instalado, normalmente ya viene.

### macOS

```
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
brew install unixodbc
brew tap microsoft/mssql-release
brew install msodbcsql17
```

---

## 3. Preparar las bases (una sola vez)

MongoDB:

```
mongosh < Datos/mongo/script.js
python cargar_datos_mongo.py
```

En Windows, si `mongosh <` no funciona en PowerShell, usar:

```
mongosh --file Datos\mongo\script.js
```

SQL Server: ejecutar `Datos/sql/script.sql`.

Si la base ya tenía usuarios creados con una versión anterior, hay que
convertir sus contraseñas a hash una sola vez:

```
python migrar_contrasenas.py
```

Ojo: `script.js` borra las colecciones antes de crearlas.

Si una de las dos bases no está levantada, el servidor igual arranca. Las
acciones de esa base devuelven error y las demás siguen funcionando.

---

## 4. Levantar el servidor

```
python ServidorAPI.py
```

Debe mostrar:

```
Servidor de la clínica escuchando en localhost:8000
Presione Ctrl+C para detenerlo.
```

Para detenerlo: `Ctrl+C`.

### Cambiar puerto o conexiones

| Variable | Por defecto |
|---|---|
| `API_HOST` | `localhost` |
| `API_PUERTO` | `8000` |
| `MONGO_URL` | `mongodb://localhost:27017` |
| `MONGO_BD` | `clinica` |
| `SQL_SERVIDOR` | `localhost` |
| `SQL_BASE_DATOS` | `ClinicaSaludBienestar` |

Windows (PowerShell):

```
$env:API_PUERTO="9000"
python ServidorAPI.py
```

macOS:

```
API_PUERTO=9000 python ServidorAPI.py
```

Si el web corre en otra máquina, poner `API_HOST` en `0.0.0.0` para que el
servidor acepte conexiones de afuera.

---

## 5. Cómo se conversa con el servidor

**Una conexión, una petición, una respuesta.** El servidor cierra la conexión
al responder; para la siguiente petición se abre una nueva.

Se envía un JSON en una sola línea, terminado en `\n`, en UTF-8:

```json
{"accion": "obtener_medico", "datos": {"codigo": "M001"}}
```

La respuesta siempre trae los mismos tres campos:

```json
{"ok": true, "mensaje": "", "datos": {"codigo": "M001", "nombre": "Carlos"}}
```

| Campo | Significado |
|---|---|
| `ok` | `true` si se hizo, `false` si no |
| `mensaje` | texto listo para mostrarle al usuario |
| `datos` | el resultado; `null` cuando hubo error |

**Lo primero que revisa el cliente es `ok`.** Si es `false`, se muestra
`mensaje`. El servidor nunca se cae por una petición mala: el error viaja
dentro de la respuesta.

---

## 6. Probar que funciona

Con el cliente incluido en el proyecto:

```
python ClientePrueba.py ping
python ClientePrueba.py listar_medicos
python ClientePrueba.py obtener_medico "{\"codigo\": \"M001\"}"
```

En macOS las comillas van más simples:

```
python ClientePrueba.py obtener_medico '{"codigo": "M001"}'
```

Desde la terminal directo:

```
# Windows (PowerShell)
$c = New-Object Net.Sockets.TcpClient("localhost", 8000)
$s = $c.GetStream()
$b = [Text.Encoding]::UTF8.GetBytes('{"accion":"ping","datos":{}}' + "`n")
$s.Write($b, 0, $b.Length)
(New-Object IO.StreamReader($s)).ReadLine()
$c.Close()

# macOS
echo '{"accion":"ping","datos":{}}' | nc -w 2 localhost 8000
```

---

## 7. Conectarse desde C# (ProyectoClinicaWeb)

```csharp
using System.Net.Sockets;
using System.Text;
using System.Text.Json;

public class ClienteApiClinica
{
    private readonly string _host;
    private readonly int _puerto;

    public ClienteApiClinica(string host = "localhost", int puerto = 8000)
    {
        _host = host;
        _puerto = puerto;
    }

    public JsonElement Enviar(string accion, object datos)
    {
        var peticion = JsonSerializer.Serialize(new { accion, datos }) + "\n";

        using var cliente = new TcpClient(_host, _puerto);
        using var flujo = cliente.GetStream();

        var bytes = Encoding.UTF8.GetBytes(peticion);
        flujo.Write(bytes, 0, bytes.Length);

        using var lector = new StreamReader(flujo, Encoding.UTF8);
        return JsonDocument.Parse(lector.ReadLine()).RootElement;
    }
}
```

Uso:

```csharp
var api = new ClienteApiClinica();
var respuesta = api.Enviar("buscar_medicos", new { ids_especialidad = new[] { 1 } });

if (respuesta.GetProperty("ok").GetBoolean())
{
    foreach (var medico in respuesta.GetProperty("datos").EnumerateArray())
        Console.WriteLine(medico.GetProperty("nombre_completo").GetString());
}
else
{
    Console.WriteLine(respuesta.GetProperty("mensaje").GetString());
}
```

---

## 8. Flujos principales

### Agendar una cita

```json
{"accion": "buscar_medicos", "datos": {"ids_especialidad": [1]}}
{"accion": "horarios_disponibles", "datos": {"codigo_medico": "M001"}}
{"accion": "reservar_cita", "datos": {"identificacion_paciente": "102340567", "codigo_medico": "M001", "id_horario": 13}}
```

El servidor valida solo que el paciente y el médico existan, que el slot sea de
ese médico y esté libre, y que la fecha no sea pasada ni tenga más de 30 días
de anticipación.

### Cancelar o reprogramar

```json
{"accion": "cancelar_cita", "datos": {"id_cita": 5}}
{"accion": "reprogramar_cita", "datos": {"id_cita": 5, "id_horario": 20}}
```

Cancelar libera el slot. Reprogramar solo acepta un slot del mismo médico.

### Facturar

```json
{"accion": "listar_servicios", "datos": {}}
{"accion": "generar_factura", "datos": {"id_cita": 5, "lineas": [{"id_servicio": 1, "cantidad": 2}]}}
{"accion": "registrar_pago", "datos": {"id_cita": 5, "metodo_pago": "Efectivo"}}
```

Una cita solo se factura una vez, y no se puede facturar una cita cancelada.

### Eliminar algo

Nada se borra de verdad: se marca como inactivo. Cada `eliminar_*` tiene su
`reactivar_*`.

```json
{"accion": "eliminar_paciente", "datos": {"identificacion": "102340567"}}
{"accion": "reactivar_paciente", "datos": {"identificacion": "102340567"}}
```

Los listados esconden los eliminados. Para verlos:

```json
{"accion": "listar_pacientes", "datos": {"incluir_inactivos": true}}
```

### Administrar cuentas

```json
{"accion": "registrar_usuario", "datos": {"usuario": "recepcion1", "contrasena": "1234", "rol": "Recepcionista"}}
{"accion": "login_empleado", "datos": {"usuario": "recepcion1", "contrasena": "1234"}}
{"accion": "cambiar_contrasena", "datos": {"usuario": "recepcion1", "contrasena_actual": "1234", "contrasena_nueva": "5678"}}
```

Los roles válidos son `Cliente`, `Administrador`, `Recepcionista` y `Medico`.
Una cuenta eliminada no puede iniciar sesión.

La contraseña se manda **normal, como la escribió el usuario**. El servidor la
guarda hasheada (PBKDF2-SHA256 con sal), así que en la base nunca queda el
texto plano. Ninguna respuesta devuelve la contraseña ni el hash.

### Abrir agenda de un médico

```json
{"accion": "generar_horarios", "datos": {"codigo_medico": "M002", "fecha": "2026-09-20", "hora_inicio": "08:00", "hora_fin": "12:00"}}
```

Genera slots de 30 minutos, sin duplicar los que ya existan.

---

## 9. Varios clientes a la vez

Cada conexión se atiende en su propio hilo, así que el web puede hacer varias
consultas al mismo tiempo.

Las lecturas de MongoDB corren en paralelo. Las escrituras y todo lo de SQL
Server se ejecutan de una en una, protegidas por un candado, para no perder
datos.

En la práctica: si dos usuarios reservan el mismo slot a la vez, uno lo obtiene
y el otro recibe `"El slot ya está ocupado."`.

---

## 10. Errores frecuentes

| Qué se ve | Qué pasó | Solución |
|---|---|---|
| `Connection refused` | el servidor no está corriendo | levantar `python ServidorAPI.py` |
| `Address already in use` | el puerto 8000 está ocupado | cerrar el servidor anterior o cambiar `API_PUERTO` |
| `El mensaje recibido no es un JSON válido.` | el texto no era JSON | revisar el mensaje |
| `La petición debe incluir el campo 'accion'.` | faltó `accion` | corregir el mensaje |
| `La acción 'x' no existe.` | nombre mal escrito | ver `api-socket.md` |
| El cliente se queda esperando | faltó el `\n` al final | agregarlo |
| `ServerSelectionTimeoutError` | MongoDB no está levantado | iniciar MongoDB |
| `Can't open lib 'ODBC Driver 17...'` | falta el driver | instalar el ODBC Driver 17 |

Primer diagnóstico siempre:

```
python ClientePrueba.py ping
```

Si responde `pong`, el servidor está bien y el problema está en la petición o
en las bases de datos.

---

## Resumen

```
pip install -r requirements.txt      # una vez
mongosh < Datos/mongo/script.js      # una vez
python cargar_datos_mongo.py         # una vez
python ServidorAPI.py                # cada vez que se usa
```

Desde el cliente: abrir socket, mandar `{"accion": "...", "datos": {...}}\n`,
leer la respuesta, revisar `ok`.
