============================================================================
DICCIONARIO DE DATOS - SQL SERVER
============================================================================

Nota sobre referencias entre motores: los datos personales (pacientes, doctores,
horarios) viven en MongoDB. Por eso las columnas identificacionPaciente,
codigoMedico e idHorario de la tabla Citas son REFERENCIAS LÓGICAS (no claves
foráneas) a colecciones de Mongo. La coherencia la garantiza el aplicativo Python.


----------------------------------------------------------------------------
Tabla: Citas
Almacena las citas médicas agendadas.
----------------------------------------------------------------------------
Campo                   | Tipo               | Clave | Descripción
------------------------|--------------------|-------|-----------------------------------------
idCita                  | INT IDENTITY(1,1)  | PK    | Identificador único de la cita
identificacionPaciente  | VARCHAR(20)        |       | Referencia lógica a pacientes (MongoDB)
codigoMedico            | VARCHAR(20)        |       | Referencia lógica a doctores (MongoDB)
idHorario               | INT                |       | Referencia lógica a horarios (MongoDB)
fecha                   | DATE               |       | Fecha de la cita
hora                    | TIME               |       | Hora de la cita
estado                  | VARCHAR(15)        |       | Reservada, Cancelada o Completada


----------------------------------------------------------------------------
Tabla: Servicios
Catálogo de servicios facturables.
----------------------------------------------------------------------------
Campo         | Tipo               | Clave | Descripción
--------------|--------------------|-------|-----------------------------------------
idServicio    | INT IDENTITY(1,1)  | PK    | Identificador único del servicio
nombre        | VARCHAR(100)       |       | Nombre del servicio
descripcion   | VARCHAR(255)       |       | Descripción del servicio
precio        | DECIMAL(10,2)      |       | Precio unitario
activo        | BIT                |       | Indica si el servicio está vigente (1 = sí)


----------------------------------------------------------------------------
Tabla: Facturas
Encabezado de cada factura emitida. Se enlaza a una cita.
----------------------------------------------------------------------------
Campo                   | Tipo               | Clave | Descripción
------------------------|--------------------|-------|-----------------------------------------
idFactura               | INT IDENTITY(1,1)  | PK    | Identificador único de la factura
idCita                  | INT                | FK    | Clave foránea a Citas
identificacionPaciente  | VARCHAR(20)        |       | Identificación del paciente facturado
fechaEmision            | DATETIME2          |       | Fecha y hora de emisión
subtotal                | DECIMAL(10,2)      |       | Suma de líneas antes de impuesto
impuesto                | DECIMAL(10,2)      |       | Monto de impuesto (IVA)
total                   | DECIMAL(10,2)      |       | Total a pagar
estado                  | VARCHAR(15)        |       | Pendiente, Pagada o Anulada
metodoPago              | VARCHAR(20)        |       | Método de pago


----------------------------------------------------------------------------
Tabla: DetalleFactura
Líneas de servicios que componen cada factura.
----------------------------------------------------------------------------
Campo           | Tipo               | Clave | Descripción
----------------|--------------------|-------|-----------------------------------------
idDetalle       | INT IDENTITY(1,1)  | PK    | Identificador único de la línea de detalle
idFactura       | INT                | FK    | Clave foránea a Facturas
idServicio      | INT                | FK    | Clave foránea a Servicios
cantidad        | INT                |       | Cantidad del servicio
precioUnitario  | DECIMAL(10,2)      |       | Precio unitario al momento de facturar
subtotalLinea   | DECIMAL(10,2)      |       | cantidad * precioUnitario


----------------------------------------------------------------------------
Relaciones (claves foráneas reales, dentro de SQL Server)
----------------------------------------------------------------------------
Facturas.idCita          -> Citas.idCita           (una cita tiene 0 o 1 factura)
DetalleFactura.idFactura -> Facturas.idFactura      (una factura tiene muchas líneas)
DetalleFactura.idServicio-> Servicios.idServicio    (un servicio aparece en muchas líneas)