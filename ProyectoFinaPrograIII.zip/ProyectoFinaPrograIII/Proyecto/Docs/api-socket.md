# API por sockets

El proyecto de Python funciona como servidor: expone la lógica de negocio (BL)
a través de un socket TCP para que el ProyectoClinicaWeb la consulte.
La aplicación de consola (`Principal.py`) sigue funcionando igual y por aparte.

## Cómo levantarlo

```
python ServidorAPI.py
```

Por defecto escucha en `localhost:8000`. Se puede cambiar con las variables de
entorno `API_HOST` y `API_PUERTO`.

Para probarlo sin el proyecto web:

```
python ClientePrueba.py ping
python ClientePrueba.py listar_medicos
python ClientePrueba.py horarios_disponibles '{"codigo_medico": "M001"}'
```

## Protocolo

Una petición por conexión. El mensaje es un objeto JSON en una sola línea,
terminado en salto de línea (`\n`), codificado en UTF-8.

Petición:

```json
{"accion": "reservar_cita", "datos": {"identificacion_paciente": "102340567", "codigo_medico": "M001", "id_horario": 12}}
```

Respuesta:

```json
{"ok": true, "mensaje": "Cita reservada correctamente.", "datos": {"id_cita": 5, "...": "..."}}
```

Cuando algo falla, `ok` es `false`, `mensaje` explica el motivo y `datos` es `null`.
El servidor nunca se cae por un error de una petición: lo devuelve como respuesta.

## Hilos

Cada conexión se atiende en su propio hilo, así que varios clientes pueden
consultar al mismo tiempo. Cada petición crea sus propios servicios de BL,
por lo que no comparten estado entre sí.

Las acciones que **escriben** datos y todas las que usan **SQL Server** se
ejecutan dentro de un candado (`threading.Lock`), por dos razones:

- al guardar en MongoDB se reemplaza la colección completa, y dos escrituras
  simultáneas sobre la misma colección podrían perder datos;
- la conexión de `pyodbc` es una sola y compartida, y no es segura entre hilos.

Las consultas que solo leen de MongoDB no usan el candado, así que sí corren
en paralelo de verdad.

## Acciones disponibles

### Consultas (MongoDB, en paralelo)

| Acción | Datos que recibe | Devuelve |
|---|---|---|
| `ping` | — | `"pong"` |
| `listar_especialidades` | `incluir_inactivos` (opcional) | lista de especialidades |
| `obtener_especialidad` | `id_especialidad` | una especialidad |
| `listar_medicos` | `incluir_inactivos` (opcional) | lista de médicos |
| `obtener_medico` | `codigo` | un médico |
| `buscar_medicos` | `nombre`, `apellido`, `ids_especialidad`, `fecha_disponible` (todos opcionales) | lista de médicos (vista pública) |
| `listar_pacientes` | `incluir_inactivos` (opcional) | lista de pacientes |
| `obtener_paciente` | `identificacion` | un paciente |
| `listar_horarios` | `codigo_medico`, `fecha` (opcional) | lista de slots |
| `horarios_disponibles` | `codigo_medico`, `fecha` (opcional) | lista de slots libres |
| `obtener_horario` | `id_horario` | un slot |
| `listar_usuarios` | `incluir_inactivos` (opcional) | lista de usuarios (sin contraseña) |
| `obtener_usuario` | `usuario` | un usuario (sin contraseña) |
| `obtener_clinica` | — | datos generales de la clínica |

### Escrituras en MongoDB

| Acción | Datos que recibe |
|---|---|
| `registrar_paciente` | los campos del paciente (`identificacion`, `nacionalidad`, `nombre`, `apellido1`, `apellido2`, `telefono`, `correo`, `padecimientos`, `tratamientos`) y la `contrasena` de la cuenta. Además del paciente crea su cuenta de cliente: el nombre de usuario es la `identificacion` |
| `modificar_paciente` | `identificacion`, `cambios` |
| `registrar_medico` | los campos del médico (`codigo`, `identificacion`, `nombre`, `apellido1`, `apellido2`, `telefono_personal`, `correo_personal`, `telefono_clinica`, `correo_clinica`, `especialidades`) |
| `modificar_medico` | `codigo`, `cambios` |
| `asignar_especialidades` | `codigo`, `ids_especialidad` |
| `registrar_especialidad` | `nombre` |
| `modificar_especialidad` | `id_especialidad`, `nombre` |
| `generar_horarios` | `codigo_medico`, `fecha`, `hora_inicio`, `hora_fin` |
| `marcar_no_disponible` | `codigo_medico`, `fecha`, `hora_inicio` (opcional) |
| `eliminar_paciente` | `identificacion` |
| `reactivar_paciente` | `identificacion` |
| `eliminar_medico` | `codigo` |
| `reactivar_medico` | `codigo` |
| `eliminar_especialidad` | `id_especialidad` |
| `reactivar_especialidad` | `id_especialidad` |
| `eliminar_horario` | `id_horario` (solo si el slot no está reservado) |
| `login_cliente` | `usuario`, `contrasena` |
| `login_empleado` | `usuario`, `contrasena` |
| `registrar_usuario` | `usuario`, `contrasena`, `rol`, `referencia` (opcional) |
| `modificar_usuario` | `usuario`, `cambios` |
| `eliminar_usuario` | `usuario` |
| `reactivar_usuario` | `usuario` |
| `cambiar_contrasena` | `usuario`, `contrasena_actual`, `contrasena_nueva` |
| `registrar_clinica` | `nombre`, `direccion`, `telefono`, `correo`, `hora_apertura`, `hora_cierre`, `dias_laborales` |
| `modificar_clinica` | `cambios` |
| `eliminar_clinica` | — |

### Citas y facturación (SQL Server)

| Acción | Datos que recibe |
|---|---|
| `listar_citas` | `identificacion_paciente`, `codigo_medico`, `fecha` o `estado` (se usa el primero que venga; sin filtros devuelve todas) |
| `obtener_cita` | `id_cita` |
| `reservar_cita` | `identificacion_paciente`, `codigo_medico`, `id_horario` |
| `cancelar_cita` | `id_cita` |
| `reprogramar_cita` | `id_cita`, `id_horario` |
| `listar_servicios` | `solo_activos` (opcional) |
| `obtener_servicio` | `id_servicio` |
| `registrar_servicio` | `nombre`, `precio`, `descripcion` (opcional) |
| `modificar_servicio` | `id_servicio`, `cambios` |
| `eliminar_servicio` | `id_servicio` |
| `reactivar_servicio` | `id_servicio` |
| `generar_factura` | `id_cita`, `lineas` (lista de `{"id_servicio": n, "cantidad": n}`) |
| `obtener_factura` | `id_cita` |
| `registrar_pago` | `id_cita`, `metodo_pago` |
| `anular_factura` | `id_cita` |

---

## Sobre el borrado

Ningún `eliminar_*` borra el registro: lo marca como inactivo (`activo: false`).
Esto protege el histórico — un médico eliminado que tiene citas viejas sigue
existiendo, así que esas citas no quedan apuntando a la nada.

Consecuencias para el cliente:

- Los `listar_*` **no devuelven los eliminados**. Para verlos hay que mandar
  `"incluir_inactivos": true`.
- Los `obtener_*` sí devuelven el registro aunque esté eliminado, con
  `"activo": false`, para poder consultar el histórico.
- Todo `eliminar_*` tiene su `reactivar_*` para deshacer.
- Un usuario eliminado no puede iniciar sesión.
- Un slot de horario reservado no se puede eliminar; primero hay que cancelar
  la cita.
- Una factura no se elimina: se anula con `anular_factura`, y solo si todavía
  no fue pagada.
- Los datos de la clínica sí se borran de verdad, porque nadie los referencia.

---

## Sobre las contraseñas

Las contraseñas **no se guardan en texto plano**. Se guarda un hash PBKDF2-SHA256
con 100.000 iteraciones y una sal aleatoria distinta para cada usuario, en el
formato `pbkdf2$<sal>$<hash>`. Del hash no se puede volver a la contraseña.

Para el cliente esto es transparente:

- `registrar_usuario`, `modificar_usuario` y `cambiar_contrasena` reciben la
  contraseña **tal como la escribió el usuario**; el servidor la hashea antes
  de guardarla.
- `login_cliente` y `login_empleado` reciben la contraseña normal y el servidor
  la compara contra el hash.
- Ninguna respuesta incluye la contraseña ni el hash.

Si una base vieja tiene contraseñas en texto plano, esas cuentas **no podrán
iniciar sesión** hasta correr la migración una sola vez:

```
python migrar_contrasenas.py
```
