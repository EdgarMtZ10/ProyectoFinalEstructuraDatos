"""Módulo de lectura y escritura genérica de archivos JSON"""

import json
import os


def _crear_archivo(ruta):
    """Crea el archivo con [] si no existe"""
    if not os.path.exists(ruta):
        os.makedirs(os.path.dirname(ruta), exist_ok=True)
        with open(ruta, "w", encoding="utf-8") as f:
            json.dump([], f, indent=4, ensure_ascii=False)


def cargar_json(ruta: str) -> list:
    """Carga y retorna la lista de datos del archivo JSON.
    Si no existe, lo crea con []. Si está corrupto, retorna []"""
    _crear_archivo(ruta)
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        print(f"Advertencia: el archivo '{ruta}' está corrupto. Se retorna lista vacía.")
        return []


def guardar_json(ruta: str, datos: list) -> None:
    """Guarda la lista de datos en el archivo JSON"""
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(datos, f, indent=4, ensure_ascii=False)
