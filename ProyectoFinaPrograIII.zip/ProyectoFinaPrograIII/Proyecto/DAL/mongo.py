"""Conexión a MongoDB y acceso genérico a las colecciones"""

import os
from pymongo import MongoClient

# Datos de conexión (se pueden cambiar con variables de entorno)
URL_MONGO = os.environ.get("MONGO_URL", "mongodb://localhost:27017")
NOMBRE_BD = os.environ.get("MONGO_BD", "clinica")

# Se guarda el cliente una sola vez para no abrir una conexión por consulta
_cliente = None


def obtener_bd():
    """Retorna la base de datos de MongoDB, abriendo la conexión la primera vez"""
    global _cliente
    if _cliente is None:
        _cliente = MongoClient(URL_MONGO)
    return _cliente[NOMBRE_BD]


def obtener_coleccion(nombre: str):
    """Retorna una colección de la base de datos"""
    return obtener_bd()[nombre]


def cargar_documentos(nombre_coleccion: str) -> list:
    """Retorna todos los documentos de la colección, sin el campo _id"""
    coleccion = obtener_coleccion(nombre_coleccion)
    return list(coleccion.find({}, {"_id": 0}))


def guardar_documentos(nombre_coleccion: str, documentos: list) -> None:
    """Reemplaza el contenido de la colección con la lista de documentos"""
    coleccion = obtener_coleccion(nombre_coleccion)
    coleccion.delete_many({})
    if documentos:
        coleccion.insert_many(documentos)


def cerrar_conexion() -> None:
    """Cierra la conexión con MongoDB"""
    global _cliente
    if _cliente is not None:
        _cliente.close()
        _cliente = None
