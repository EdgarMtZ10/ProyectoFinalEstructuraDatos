"""Repositorio por entidad: traduce entre objetos de dominio y las bases de datos

Pacientes, médicos, especialidades y horarios se guardan en MongoDB
(ver Docs/diccionario-mongo.md). Las citas se guardan en SQL Server
(ver Docs/diccionario-sql-server.md).
"""

from typing import Optional

from DAL.mongo import cargar_documentos, guardar_documentos
from DAL.sqlserver import ejecutar_consulta, ejecutar_accion, ejecutar_insert_y_obtener_id
from Entidades.paciente import Paciente
from Entidades.medico import Medico
from Entidades.especialidad import Especialidad
from Entidades.horario import Horario
from Entidades.cita import Cita
from Entidades.servicio import Servicio
from Entidades.factura import Factura
from Entidades.detalle_factura import DetalleFactura
from Entidades.usuario import Usuario
from Entidades.clinica import Clinica

# Nombres de las colecciones en MongoDB
_COL_PACIENTES      = "pacientes"
_COL_MEDICOS        = "doctores"
_COL_ESPECIALIDADES = "especialidades"
_COL_HORARIOS       = "horarios"


# --- Pacientes ---

def cargar_pacientes() -> list:
    """Carga y retorna la lista de pacientes desde MongoDB"""
    datos = cargar_documentos(_COL_PACIENTES)
    return [Paciente.from_dict(d) for d in datos]


def guardar_pacientes(pacientes: list) -> None:
    """Guarda la lista de pacientes en MongoDB"""
    guardar_documentos(_COL_PACIENTES, [p.to_dict() for p in pacientes])


# --- Médicos (colección "doctores") ---
# Nota: la colección usa camelCase; se traduce a snake_case para la entidad y viceversa.

def _medico_a_dict(m):
    """Convierte un Medico al formato camelCase de la colección"""
    return {
        "codigo": m.codigo,
        "identificacion": m.identificacion,
        "nombre": m.nombre,
        "apellido1": m.apellido1,
        "apellido2": m.apellido2,
        "telefonoPersonal": m.telefono,
        "correoPersonal": m.correo,
        "telefonoClinica": m.telefono_clinica,
        "correoClinica": m.correo_clinica,
        "especialidades": m.especialidades,
        "activo": m.activo
    }


def _dict_a_medico(d):
    """Crea un Medico desde el formato camelCase de la colección"""
    return Medico(
        codigo=d["codigo"],
        identificacion=d["identificacion"],
        nombre=d["nombre"],
        apellido1=d["apellido1"],
        apellido2=d.get("apellido2", ""),
        telefono_personal=d["telefonoPersonal"],
        correo_personal=d["correoPersonal"],
        telefono_clinica=d["telefonoClinica"],
        correo_clinica=d["correoClinica"],
        especialidades=d.get("especialidades", []),
        activo=d.get("activo", True)
    )


def cargar_medicos() -> list:
    """Carga y retorna la lista de médicos desde MongoDB"""
    datos = cargar_documentos(_COL_MEDICOS)
    return [_dict_a_medico(d) for d in datos]


def guardar_medicos(medicos: list) -> None:
    """Guarda la lista de médicos en MongoDB"""
    guardar_documentos(_COL_MEDICOS, [_medico_a_dict(m) for m in medicos])


# --- Especialidades ---
# Nota: la colección usa idEspecialidad (camelCase).

def _especialidad_a_dict(e):
    """Convierte una Especialidad al formato camelCase de la colección"""
    return {
        "idEspecialidad": e.id_especialidad,
        "nombre": e.nombre,
        "activo": e.activo
    }


def _dict_a_especialidad(d):
    """Crea una Especialidad desde el formato camelCase de la colección"""
    return Especialidad(
        id_especialidad=d["idEspecialidad"],
        nombre=d["nombre"],
        activo=d.get("activo", True)
    )


def cargar_especialidades() -> list:
    """Carga y retorna la lista de especialidades desde MongoDB"""
    datos = cargar_documentos(_COL_ESPECIALIDADES)
    return [_dict_a_especialidad(d) for d in datos]


def guardar_especialidades(especialidades: list) -> None:
    """Guarda la lista de especialidades en MongoDB"""
    guardar_documentos(_COL_ESPECIALIDADES, [_especialidad_a_dict(e) for e in especialidades])


# --- Horarios ---
# Nota: la colección usa camelCase (idHorario, codigoMedico, horaInicio, horaFin).

def _horario_a_dict(h):
    """Convierte un Horario al formato camelCase de la colección"""
    return {
        "idHorario": h.id_horario,
        "codigoMedico": h.codigo_medico,
        "fecha": h.fecha,
        "horaInicio": h.hora_inicio,
        "horaFin": h.hora_fin,
        "disponible": h.disponible,
        "activo": h.activo
    }


def _dict_a_horario(d):
    """Crea un Horario desde el formato camelCase de la colección"""
    return Horario(
        id_horario=d["idHorario"],
        codigo_medico=d["codigoMedico"],
        fecha=d["fecha"],
        hora_inicio=d["horaInicio"],
        hora_fin=d["horaFin"],
        disponible=d.get("disponible", True),
        activo=d.get("activo", True)
    )


def cargar_horarios() -> list:
    """Carga y retorna la lista de horarios desde MongoDB"""
    datos = cargar_documentos(_COL_HORARIOS)
    return [_dict_a_horario(d) for d in datos]


def guardar_horarios(horarios: list) -> None:
    """Guarda la lista de horarios en MongoDB"""
    guardar_documentos(_COL_HORARIOS, [_horario_a_dict(h) for h in horarios])


# Citas (tabla Citas en SQL)

def _dict_a_cita(fila: dict) -> Cita:
    """Crea una Cita a partir de una fila (dict) devuelta por ejecutar_consulta"""
    return Cita(
        id_cita=fila["idCita"],
        identificacion_paciente=fila["identificacionPaciente"],
        codigo_medico=fila["codigoMedico"],
        id_horario=fila["idHorario"],
        fecha=str(fila["fecha"]),
        hora=str(fila["hora"]),
        estado=fila["estado"]
    )


def cargar_citas() -> list:
    """Carga y retorna todas las citas desde SQL Server"""
    filas = ejecutar_consulta(
        "SELECT idCita, identificacionPaciente, codigoMedico, idHorario, fecha, hora, estado "
        "FROM Citas"
    )
    return [_dict_a_cita(f) for f in filas]


def obtener_cita_por_id(id_cita: int) -> Optional[Cita]:
    """Retorna una cita por su id, o None si no existe"""
    filas = ejecutar_consulta(
        "SELECT idCita, identificacionPaciente, codigoMedico, idHorario, fecha, hora, estado "
        "FROM Citas WHERE idCita = ?",
        (id_cita,)
    )
    return _dict_a_cita(filas[0]) if filas else None


def insertar_cita(cita: Cita) -> int:
    """Inserta una nueva cita en SQL Server y retorna el idCita generado"""
    nuevo_id = ejecutar_insert_y_obtener_id(
        "INSERT INTO Citas (identificacionPaciente, codigoMedico, idHorario, fecha, hora, estado) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (cita.identificacion_paciente, cita.codigo_medico, cita.id_horario,
         cita.fecha, cita.hora, cita.estado)
    )
    cita.id_cita = nuevo_id
    return nuevo_id


def actualizar_cita(cita: Cita) -> None:
    """Actualiza idHorario, fecha, hora y estado de una cita ya existente
    (usado al cancelar o reprogramar)"""
    ejecutar_accion(
        "UPDATE Citas SET idHorario = ?, fecha = ?, hora = ?, estado = ? WHERE idCita = ?",
        (cita.id_horario, cita.fecha, cita.hora, cita.estado, cita.id_cita)
    )


def guardar_citas(citas: list) -> None:
    """Guarda una lista de citas en SQL Server: inserta las que todavía no tienen id
    (citas nuevas, id_cita en None) y actualiza las que ya existen. Se mantiene con este
    nombre por compatibilidad con ServicioCitas, que trabaja con la lista completa en memoria."""
    for c in citas:
        if c.id_cita is None:
            insertar_cita(c)
        else:
            actualizar_cita(c)

# --- Servicios (tabla Servicios en SQL)

def _dict_a_servicio(fila: dict) -> Servicio:
    """Crea un Servicio a partir de una fila devuelta por ejecutar_consulta"""
    return Servicio(
        id_servicio=fila["idServicio"],
        nombre=fila["nombre"],
        precio=float(fila["precio"]),
        descripcion=fila.get("descripcion", ""),
        activo=bool(fila["activo"])
    )


def cargar_servicios() -> list:
    """Carga y retorna todos los servicios activos e inactivos desde SQL"""
    filas = ejecutar_consulta(
        "SELECT idServicio, nombre, descripcion, precio, activo FROM Servicios"
    )
    return [_dict_a_servicio(f) for f in filas]


def obtener_servicio_por_id(id_servicio: int) -> Optional[Servicio]:
    """Retorna un servicio por su id, o None si no existe"""
    filas = ejecutar_consulta(
        "SELECT idServicio, nombre, descripcion, precio, activo FROM Servicios "
        "WHERE idServicio = ?",
        (id_servicio,)
    )
    return _dict_a_servicio(filas[0]) if filas else None


def insertar_servicio(servicio: Servicio) -> int:
    """Inserta un servicio nuevo y retorna el idServicio generado"""
    nuevo_id = ejecutar_insert_y_obtener_id(
        "INSERT INTO Servicios (nombre, descripcion, precio, activo) VALUES (?, ?, ?, ?)",
        (servicio.nombre, servicio.descripcion, servicio.precio, servicio.activo)
    )
    servicio.id_servicio = nuevo_id
    return nuevo_id


def actualizar_servicio(servicio: Servicio) -> None:
    """Actualiza nombre, descripción, precio y estado de un servicio existente"""
    ejecutar_accion(
        "UPDATE Servicios SET nombre = ?, descripcion = ?, precio = ?, activo = ? "
        "WHERE idServicio = ?",
        (servicio.nombre, servicio.descripcion, servicio.precio,
         servicio.activo, servicio.id_servicio)
    )

# Facturas (tabla Facturas en SQL) 
def _dict_a_factura(fila: dict) -> Factura:
    """Crea una Factura a partir de una fila devuelta por ejecutar_consulta.
    Se usa subtotal='crudo' porque impuesto y total se recalculan solos (@property)."""
    return Factura(
        id_factura=fila["idFactura"],
        id_cita=fila["idCita"],
        identificacion_paciente=fila["identificacionPaciente"],
        subtotal=float(fila["subtotal"]),
        estado=fila["estado"],
        metodo_pago=fila.get("metodoPago")
    )

def insertar_factura(factura: Factura) -> int:
    """Inserta una nueva factura y retorna el idFactura generado.
    Se guarda subtotal, impuesto y total ya calculados."""
    nuevo_id = ejecutar_insert_y_obtener_id(
        "INSERT INTO Facturas (idCita, identificacionPaciente, subtotal, impuesto, total, estado, metodoPago) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (factura.id_cita, factura.identificacion_paciente, factura.subtotal,
         factura.impuesto, factura.total, factura.estado, factura.metodo_pago)
    )
    factura.id_factura = nuevo_id
    return nuevo_id


def actualizar_factura(factura: Factura) -> None:
    """Actualiza subtotal, impuesto, total, estado y método de pago de una factura existente
    (se usa al marcarla como pagada)"""
    ejecutar_accion(
        "UPDATE Facturas SET subtotal = ?, impuesto = ?, total = ?, estado = ?, metodoPago = ? "
        "WHERE idFactura = ?",
        (factura.subtotal, factura.impuesto, factura.total, factura.estado,
         factura.metodo_pago, factura.id_factura)
    )

def obtener_factura_por_cita(id_cita: int) -> Optional[Factura]:
    """Retorna la factura asociada a una cita, o None si esa cita todavía no se ha facturado"""
    filas = ejecutar_consulta(
        "SELECT idFactura, idCita, identificacionPaciente, subtotal, impuesto, total, estado, metodoPago "
        "FROM Facturas WHERE idCita = ?",
        (id_cita,)
    )
    return _dict_a_factura(filas[0]) if filas else None


# DetalleFactura (tabla DetalleFactura en SQL) 

def _dict_a_detalle(fila: dict) -> DetalleFactura:
    """Crea un DetalleFactura a partir de una fila devuelta por ejecutar_consulta"""
    return DetalleFactura(
        id_detalle=fila["idDetalle"],
        id_factura=fila["idFactura"],
        id_servicio=fila["idServicio"],
        cantidad=fila["cantidad"],
        precio_unitario=float(fila["precioUnitario"])
    )


def insertar_detalle_factura(detalle: DetalleFactura) -> int:
    """Inserta una línea de detalle y retorna el idDetalle generado"""
    nuevo_id = ejecutar_insert_y_obtener_id(
        "INSERT INTO DetalleFactura (idFactura, idServicio, cantidad, precioUnitario, subtotalLinea) "
        "VALUES (?, ?, ?, ?, ?)",
        (detalle.id_factura, detalle.id_servicio, detalle.cantidad,
         detalle.precio_unitario, detalle.subtotal_linea)
    )
    detalle.id_detalle = nuevo_id
    return nuevo_id


def obtener_detalles_por_factura(id_factura: int) -> list:
    """Retorna todas las líneas de servicio que componen una factura"""
    filas = ejecutar_consulta(
        "SELECT idDetalle, idFactura, idServicio, cantidad, precioUnitario "
        "FROM DetalleFactura WHERE idFactura = ?",
        (id_factura,)
    )
    return [_dict_a_detalle(f) for f in filas]

# --- Usuarios (colección "usuarios" en MongoDB) ---

_COL_USUARIOS = "usuarios"


def cargar_usuarios() -> list:
    """Carga y retorna la lista de usuarios desde MongoDB"""
    datos = cargar_documentos(_COL_USUARIOS)
    return [Usuario.from_dict(d) for d in datos]


def guardar_usuarios(usuarios: list) -> None:
    """Guarda la lista de usuarios en MongoDB"""
    guardar_documentos(_COL_USUARIOS, [u.to_dict() for u in usuarios])


# --- Clínica (colección "clinica" en MongoDB) ---

_COL_CLINICA = "clinica"


def _clinica_a_dict(c):
    """Convierte una Clinica al formato camelCase de la colección"""
    return {
        "nombre": c.nombre,
        "direccion": c.direccion,
        "telefono": c.telefono,
        "correo": c.correo,
        "horaApertura": c.hora_apertura,
        "horaCierre": c.hora_cierre,
        "diasLaborales": c.dias_laborales
    }


def _dict_a_clinica(d):
    """Crea una Clinica desde el formato camelCase de la colección"""
    return Clinica(
        nombre=d["nombre"],
        direccion=d["direccion"],
        telefono=d["telefono"],
        correo=d["correo"],
        hora_apertura=d["horaApertura"],
        hora_cierre=d["horaCierre"],
        dias_laborales=d.get("diasLaborales", [])
    )


def cargar_clinica():
    """Retorna los datos de la clínica, o None si todavía no se han registrado.
    La colección guarda un solo documento."""
    datos = cargar_documentos(_COL_CLINICA)
    return _dict_a_clinica(datos[0]) if datos else None


def guardar_clinica(clinica: Clinica) -> None:
    """Guarda (o reemplaza) los datos de la clínica en MongoDB"""
    guardar_documentos(_COL_CLINICA, [_clinica_a_dict(clinica)])


def borrar_clinica() -> None:
    """Borra los datos de la clínica (deja la colección vacía)"""
    guardar_documentos(_COL_CLINICA, [])
