"""Conexión a SQL Server """

import os
import pyodbc

# Datos de conexión 
SQL_SERVIDOR = os.environ.get("SQL_SERVIDOR", "localhost")
SQL_BASE_DATOS = os.environ.get("SQL_BASE_DATOS", "ClinicaSaludBienestar")
SQL_USUARIO = os.environ.get("SQL_USUARIO", "sa")
SQL_CONTRASENA = os.environ.get("SQL_CONTRASENA", "")
SQL_DRIVER = os.environ.get("SQL_DRIVER", "{ODBC Driver 17 for SQL Server}")

# Se guarda la conexión una sola vez para no abrir una por consulta
_conexion = None


def obtener_conexion():
    """Retorna la conexión a SQL Server, abriéndola la primera vez"""
    global _conexion
    if _conexion is None:
        cadena = (
            f"DRIVER={SQL_DRIVER};"
            f"SERVER={SQL_SERVIDOR};"
            f"DATABASE={SQL_BASE_DATOS};"
            f"UID={SQL_USUARIO};"
            f"PWD={SQL_CONTRASENA};"
            f"TrustServerCertificate=yes;"
        )
        _conexion = pyodbc.connect(cadena)
    return _conexion


def _es_error_de_conexion(error) -> bool:
    """Indica si el error es porque se perdió la conexión con SQL Server.
    Pasa cuando el servidor se reinicia: la conexión guardada queda muerta."""
    texto = str(error)
    senales = [
        "08S01",                        # link failure
        "08003",                        # conexión no abierta
        "Communication link failure",
        "Read from the server failed",
        "Unexpected EOF from the server",
        "TDS server is unavailable",
        "Adaptive Server connection failed",
        "Connection is busy",
    ]
    return any(s in texto for s in senales)


def _ejecutar(operacion):
    """Corre la operación y, si la conexión estaba muerta, reconecta y reintenta
    una vez. Así el servidor sigue sirviendo aunque SQL Server se haya
    reiniciado, sin tener que reiniciarlo a mano."""
    try:
        return operacion(obtener_conexion())
    except pyodbc.Error as error:
        if not _es_error_de_conexion(error):
            raise

        # Se descarta la conexión muerta y se vuelve a intentar con una nueva
        global _conexion
        try:
            if _conexion is not None:
                _conexion.close()
        except pyodbc.Error:
            pass
        _conexion = None

        return operacion(obtener_conexion())


def ejecutar_consulta(sql: str, parametros: tuple = ()) -> list:
    """Ejecuta un SELECT y retorna una lista de diccionarios (columna -> valor)"""
    def consulta(conexion):
        cursor = conexion.cursor()
        cursor.execute(sql, parametros)
        columnas = [col[0] for col in cursor.description]
        filas = cursor.fetchall()
        return [dict(zip(columnas, fila)) for fila in filas]

    return _ejecutar(consulta)


def ejecutar_accion(sql: str, parametros: tuple = ()) -> int:
    """Ejecuta un INSERT, UPDATE o DELETE y retorna el número de filas afectadas.
    Hace commit de inmediato."""
    def accion(conexion):
        cursor = conexion.cursor()
        cursor.execute(sql, parametros)
        conexion.commit()
        return cursor.rowcount

    return _ejecutar(accion)


def ejecutar_insert_y_obtener_id(sql: str, parametros: tuple = ()) -> int:
    """Ejecuta un INSERT y retorna el idCita/idFactura/etc. generado (IDENTITY).
    El sql no debe incluir el SELECT del id; se agrega automáticamente."""
    def insertar(conexion):
        cursor = conexion.cursor()
        cursor.execute(sql + "; SELECT SCOPE_IDENTITY();", parametros)
        nuevo_id = cursor.fetchval()
        conexion.commit()
        return int(nuevo_id)

    return _ejecutar(insertar)


def cerrar_conexion() -> None:
    """Cierra la conexión con SQL Server"""
    global _conexion
    if _conexion is not None:
        _conexion.close()
        _conexion = None