"""Servicio de lógica de negocio para el catálogo de servicios facturables"""

from Entidades.servicio import Servicio
from DAL.repositorio import (
    cargar_servicios, obtener_servicio_por_id,
    insertar_servicio, actualizar_servicio
)


class ServicioServicios:
    """Gestiona el registro, modificación y consulta de los servicios de la clínica"""

    def __init__(self):
        """Carga los servicios desde el repositorio"""
        self.servicios = cargar_servicios()

    def _nombre_duplicado(self, nombre: str, id_ignorar=None) -> bool:
        """Verifica si ya existe otro servicio con el mismo nombre"""
        nombre_normalizado = nombre.strip().lower()
        for s in self.servicios:
            if s.id_servicio == id_ignorar:
                continue
            if s.nombre.strip().lower() == nombre_normalizado:
                return True
        return False

    def listar(self, solo_activos=False) -> list:
        """Retorna los servicios. Por defecto retorna todos"""
        if solo_activos:
            return [s for s in self.servicios if s.activo]
        return self.servicios

    def obtener(self, id_servicio: int):
        """Retorna un servicio por su id o None si no existe"""
        return obtener_servicio_por_id(id_servicio)

    def registrar(self, datos: dict) -> tuple:
        """Registra un servicio nuevo en el catálogo"""
        nombre = datos.get("nombre", "")

        if self._nombre_duplicado(nombre):
            return False, f"Ya existe un servicio con el nombre '{nombre.strip()}'.", None

        try:
            nuevo = Servicio(
                id_servicio=None,
                nombre=nombre,
                precio=datos.get("precio", 0),
                descripcion=datos.get("descripcion", ""),
                activo=datos.get("activo", True)
            )
        except ValueError as e:
            return False, str(e), None

        insertar_servicio(nuevo)
        self.servicios.append(nuevo)
        return True, "Servicio registrado correctamente.", nuevo

    def modificar(self, id_servicio: int, cambios: dict) -> tuple:
        """Modifica los datos de un servicio existente"""
        servicio = obtener_servicio_por_id(id_servicio)
        if servicio is None:
            return False, f"No se encontró un servicio con id '{id_servicio}'.", None

        nombre = cambios.get("nombre", servicio.nombre)
        if self._nombre_duplicado(nombre, id_ignorar=id_servicio):
            return False, f"Ya existe un servicio con el nombre '{nombre.strip()}'.", None

        try:
            actualizado = Servicio(
                id_servicio=id_servicio,
                nombre=nombre,
                precio=cambios.get("precio", servicio.precio),
                descripcion=cambios.get("descripcion", servicio.descripcion),
                activo=cambios.get("activo", servicio.activo)
            )
        except ValueError as e:
            return False, str(e), None

        actualizar_servicio(actualizado)
        self.servicios = cargar_servicios()
        return True, "Servicio modificado correctamente.", actualizado

    def eliminar(self, id_servicio: int) -> tuple:
        """Elimina un servicio de forma lógica: lo desactiva para que deje de
        ofrecerse, sin borrarlo, porque puede estar en facturas ya emitidas"""
        servicio = obtener_servicio_por_id(id_servicio)
        if servicio is None:
            return False, f"No se encontró un servicio con id '{id_servicio}'.", None

        if not servicio.activo:
            return False, "El servicio ya está eliminado.", None

        servicio.cambiar_estado(False)
        actualizar_servicio(servicio)
        self.servicios = cargar_servicios()
        return True, "Servicio eliminado correctamente.", servicio

    def reactivar(self, id_servicio: int) -> tuple:
        """Vuelve a activar un servicio eliminado"""
        servicio = obtener_servicio_por_id(id_servicio)
        if servicio is None:
            return False, f"No se encontró un servicio con id '{id_servicio}'.", None

        if servicio.activo:
            return False, "El servicio ya está activo.", None

        servicio.cambiar_estado(True)
        actualizar_servicio(servicio)
        self.servicios = cargar_servicios()
        return True, "Servicio reactivado correctamente.", servicio
