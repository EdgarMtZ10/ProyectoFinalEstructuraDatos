"""Servicio de lógica de negocio para horarios"""

from datetime import datetime, timedelta
from Entidades.horario import Horario
from Entidades.constantes import FORMATO_HORA
from DAL.repositorio import cargar_horarios, guardar_horarios


class ServicioHorarios:
    """Gestiona la generación y consulta de slots de horario para médicos"""

    def __init__(self, serv_medicos):
        """Carga los horarios desde el repositorio"""
        self.horarios = cargar_horarios()
        self.serv_medicos = serv_medicos

    def _siguiente_id(self) -> int:
        """Retorna el próximo id disponible para un horario"""
        if not self.horarios:
            return 1
        return max(h.id_horario for h in self.horarios) + 1

    def generar_disponibilidad(self, codigo_medico: str, fecha: str,
                               hora_inicio: str, hora_fin: str) -> tuple:
        """Genera slots de 30 minutos entre hora_inicio y hora_fin para el médico y fecha dados"""
        if self.serv_medicos.buscar_por_codigo(codigo_medico) is None:
            return False, f"No se encontró un médico con código '{codigo_medico}'.", []

        # Slots ya existentes para ese médico y fecha (para evitar duplicados)
        existentes = {
            h.hora_inicio
            for h in self.horarios
            if h.codigo_medico == codigo_medico and h.fecha == fecha and h.activo
        }

        try:
            cursor = datetime.strptime(hora_inicio, FORMATO_HORA)
            fin_dt = datetime.strptime(hora_fin, FORMATO_HORA)
        except ValueError:
            return False, "Formato de hora inválido. Use HH:MM.", []

        if cursor >= fin_dt:
            return False, "La hora de inicio debe ser anterior a la hora de fin.", []

        nuevos = []
        siguiente_id = self._siguiente_id()

        while cursor < fin_dt:
            inicio_str = cursor.strftime(FORMATO_HORA)
            fin_str = (cursor + timedelta(minutes=30)).strftime(FORMATO_HORA)

            slot = Horario(siguiente_id, codigo_medico, fecha, inicio_str, fin_str)
            valido, motivo = slot.es_valido()

            if not valido:
                cursor += timedelta(minutes=30)
                continue

            if inicio_str not in existentes:
                self.horarios.append(slot)
                existentes.add(inicio_str)
                nuevos.append(slot)
                siguiente_id += 1

            cursor += timedelta(minutes=30)

        if not nuevos:
            return False, "No se generaron slots nuevos. Verifique el rango o que no estén duplicados.", []

        self.guardar()
        return True, f"Se generaron {len(nuevos)} slot(s) correctamente.", nuevos

    def marcar_no_disponible(self, codigo_medico: str, fecha: str,
                             hora_inicio=None) -> tuple:
        """Marca como no disponible un slot específico o todos los slots de una fecha.
        Retorna cuántos slots fueron modificados"""
        afectados = 0

        for slot in self.horarios:
            if slot.codigo_medico != codigo_medico or slot.fecha != fecha:
                continue
            if hora_inicio is not None and slot.hora_inicio != hora_inicio:
                continue
            if not slot.disponible:
                continue
            slot.cambiar_disponibilidad(False)
            afectados += 1

        if afectados == 0:
            return False, "No se encontraron slots disponibles para modificar.", 0

        self.guardar()
        return True, f"Se marcaron {afectados} slot(s) como no disponible(s).", afectados

    def slots_de_medico(self, codigo_medico: str, fecha=None) -> list:
        """Retorna todos los slots de un médico, opcionalmente filtrados por fecha"""
        return [
            h for h in self.horarios
            if h.codigo_medico == codigo_medico
            and h.activo
            and (fecha is None or h.fecha == fecha)
        ]

    def slots_disponibles(self, codigo_medico: str, fecha=None) -> list:
        """Retorna los slots disponibles de un médico, opcionalmente filtrados por fecha"""
        return [
            h for h in self.horarios
            if h.codigo_medico == codigo_medico
            and h.activo
            and h.disponible
            and (fecha is None or h.fecha == fecha)
        ]

    def eliminar_slot(self, id_horario: int) -> tuple:
        """Elimina un slot de forma lógica: lo marca como inactivo.
        No se puede eliminar un slot ya reservado"""
        slot = self.buscar_slot(id_horario)
        if slot is None:
            return False, f"No se encontró el slot con id '{id_horario}'.", None

        if not slot.activo:
            return False, "El slot ya está eliminado.", None

        if not slot.disponible:
            return False, "No se puede eliminar un slot que ya tiene una cita reservada.", None

        slot.activo = False
        self.guardar()
        return True, "Slot eliminado correctamente.", slot

    def buscar_slot(self, id_horario: int):
        """Retorna el slot con ese id o None si no existe"""
        for h in self.horarios:
            if h.id_horario == id_horario:
                return h
        return None

    def guardar(self) -> None:
        """Persiste la lista de horarios en el repositorio"""
        guardar_horarios(self.horarios)
