"""Servicio de lógica de negocio para pacientes"""

from Entidades.paciente import Paciente
from DAL.repositorio import cargar_pacientes, guardar_pacientes


class ServicioPacientes:
    """Gestiona el registro, modificación y consulta de pacientes"""

    def __init__(self):
        """Carga los pacientes desde el repositorio e inicializa el índice"""
        self.pacientes = cargar_pacientes()
        self.indice = {p.identificacion: p for p in self.pacientes}

    def registrar(self, datos: dict) -> tuple:
        """Registra un nuevo paciente a partir de un diccionario de datos"""
        identificacion = datos.get("identificacion", "")

        if identificacion in self.indice:
            return False, f"Ya existe un paciente con identificación '{identificacion}'.", None

        try:
            nuevo = Paciente(
                identificacion=identificacion,
                nacionalidad=datos.get("nacionalidad", ""),
                nombre=datos.get("nombre", ""),
                apellido1=datos.get("apellido1", ""),
                apellido2=datos.get("apellido2", ""),
                telefono=datos.get("telefono", ""),
                correo=datos.get("correo", ""),
                padecimientos=datos.get("padecimientos", []),
                tratamientos=datos.get("tratamientos", [])
            )
        except ValueError as e:
            return False, str(e), None

        self.pacientes.append(nuevo)
        self.indice[nuevo.identificacion] = nuevo
        self.guardar()
        return True, "Paciente registrado correctamente.", nuevo

    def modificar(self, identificacion: str, cambios: dict) -> tuple:
        """Modifica los datos de un paciente existente"""
        paciente = self.indice.get(identificacion)
        if paciente is None:
            return False, f"No se encontró un paciente con identificación '{identificacion}'.", None

        try:
            # Aplicar solo los campos presentes en cambios
            nombre    = cambios.get("nombre",    paciente.nombre)
            apellido1 = cambios.get("apellido1", paciente.apellido1)
            apellido2 = cambios.get("apellido2", paciente.apellido2)
            telefono  = cambios.get("telefono",  paciente.telefono)
            correo    = cambios.get("correo",    paciente.correo)
            nacional  = cambios.get("nacionalidad", paciente.nacionalidad)

            actualizado = Paciente(
                identificacion=identificacion,
                nacionalidad=nacional,
                nombre=nombre,
                apellido1=apellido1,
                apellido2=apellido2,
                telefono=telefono,
                correo=correo,
                padecimientos=cambios.get("padecimientos", paciente.padecimientos),
                tratamientos=cambios.get("tratamientos", paciente.tratamientos),
                activo=paciente.activo
            )
        except ValueError as e:
            return False, str(e), None

        # Reemplazar en la lista y en el índice
        pos = self.pacientes.index(paciente)
        self.pacientes[pos] = actualizado
        self.indice[identificacion] = actualizado
        self.guardar()
        return True, "Paciente modificado correctamente.", actualizado

    def listar(self, incluir_inactivos=False) -> list:
        """Retorna los pacientes. Por defecto solo los activos"""
        if incluir_inactivos:
            return self.pacientes
        return [p for p in self.pacientes if p.activo]

    def eliminar(self, identificacion: str) -> tuple:
        """Elimina un paciente de forma lógica: lo marca como inactivo.
        No se borra el documento para no dejar citas huérfanas"""
        paciente = self.indice.get(identificacion)
        if paciente is None:
            return False, f"No se encontró un paciente con identificación '{identificacion}'.", None

        if not paciente.activo:
            return False, "El paciente ya está eliminado.", None

        paciente.activo = False
        self.guardar()
        return True, "Paciente eliminado correctamente.", paciente

    def reactivar(self, identificacion: str) -> tuple:
        """Vuelve a activar un paciente eliminado"""
        paciente = self.indice.get(identificacion)
        if paciente is None:
            return False, f"No se encontró un paciente con identificación '{identificacion}'.", None

        if paciente.activo:
            return False, "El paciente ya está activo.", None

        paciente.activo = True
        self.guardar()
        return True, "Paciente reactivado correctamente.", paciente

    def buscar_por_identificacion(self, identificacion: str):
        """Retorna el paciente con esa identificación o None si no existe"""
        return self.indice.get(identificacion)

    def guardar(self) -> None:
        """Persiste la lista de pacientes en el repositorio"""
        guardar_pacientes(self.pacientes)
