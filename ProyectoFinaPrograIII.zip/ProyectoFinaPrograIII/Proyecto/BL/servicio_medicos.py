"""Servicio de lógica de negocio para médicos"""

from Entidades.medico import Medico
from DAL.repositorio import cargar_medicos, guardar_medicos


class ServicioMedicos:
    """Gestiona el registro, modificación y consulta de médicos"""

    def __init__(self, serv_especialidades):
        """Carga los médicos desde el repositorio e inicializa el índice"""
        self.medicos = cargar_medicos()
        self.indice = {m.codigo: m for m in self.medicos}
        self.serv_esp = serv_especialidades

    def _validar_especialidades(self, ids: list) -> tuple:
        """Valida que todos los ids de especialidad existan"""
        if not ids:
            return False, "Debe asignarse al menos una especialidad."
        for id_esp in ids:
            if not self.serv_esp.existe(id_esp):
                return False, f"La especialidad con id '{id_esp}' no existe."
        return True, ""

    def registrar(self, datos: dict) -> tuple:
        """Registra un nuevo médico a partir de un diccionario de datos"""
        codigo = datos.get("codigo", "")

        if codigo in self.indice:
            return False, f"Ya existe un médico con código '{codigo}'.", None

        especialidades = datos.get("especialidades", [])
        ok, msg = self._validar_especialidades(especialidades)
        if not ok:
            return False, msg, None

        try:
            nuevo = Medico(
                codigo=codigo,
                identificacion=datos.get("identificacion", ""),
                nombre=datos.get("nombre", ""),
                apellido1=datos.get("apellido1", ""),
                apellido2=datos.get("apellido2", ""),
                telefono_personal=datos.get("telefono_personal", ""),
                correo_personal=datos.get("correo_personal", ""),
                telefono_clinica=datos.get("telefono_clinica", ""),
                correo_clinica=datos.get("correo_clinica", ""),
                especialidades=especialidades
            )
        except ValueError as e:
            return False, str(e), None

        self.medicos.append(nuevo)
        self.indice[nuevo.codigo] = nuevo
        self.guardar()
        return True, "Médico registrado correctamente.", nuevo

    def modificar(self, codigo: str, cambios: dict) -> tuple:
        """Modifica los datos de un médico existente"""
        medico = self.indice.get(codigo)
        if medico is None:
            return False, f"No se encontró un médico con código '{codigo}'.", None

        try:
            actualizado = Medico(
                codigo=codigo,
                identificacion=cambios.get("identificacion", medico.identificacion),
                nombre=cambios.get("nombre", medico.nombre),
                apellido1=cambios.get("apellido1", medico.apellido1),
                apellido2=cambios.get("apellido2", medico.apellido2),
                telefono_personal=cambios.get("telefono_personal", medico.telefono),
                correo_personal=cambios.get("correo_personal", medico.correo),
                telefono_clinica=cambios.get("telefono_clinica", medico.telefono_clinica),
                correo_clinica=cambios.get("correo_clinica", medico.correo_clinica),
                especialidades=cambios.get("especialidades", medico.especialidades),
                activo=medico.activo
            )
        except ValueError as e:
            return False, str(e), None

        pos = self.medicos.index(medico)
        self.medicos[pos] = actualizado
        self.indice[codigo] = actualizado
        self.guardar()
        return True, "Médico modificado correctamente.", actualizado

    def asignar_especialidades(self, codigo: str, ids: list) -> tuple:
        """Asigna especialidades a un médico, validando que existan"""
        medico = self.indice.get(codigo)
        if medico is None:
            return False, f"No se encontró un médico con código '{codigo}'.", None

        ok, msg = self._validar_especialidades(ids)
        if not ok:
            return False, msg, None

        for id_esp in ids:
            medico.agregar_especialidad(id_esp)

        self.guardar()
        return True, "Especialidades asignadas correctamente.", medico

    def listar(self, incluir_inactivos=False) -> list:
        """Retorna los médicos. Por defecto solo los activos"""
        if incluir_inactivos:
            return self.medicos
        return [m for m in self.medicos if m.activo]

    def eliminar(self, codigo: str) -> tuple:
        """Elimina un médico de forma lógica: lo marca como inactivo"""
        medico = self.indice.get(codigo)
        if medico is None:
            return False, f"No se encontró un médico con código '{codigo}'.", None

        if not medico.activo:
            return False, "El médico ya está eliminado.", None

        medico.activo = False
        self.guardar()
        return True, "Médico eliminado correctamente.", medico

    def reactivar(self, codigo: str) -> tuple:
        """Vuelve a activar un médico eliminado"""
        medico = self.indice.get(codigo)
        if medico is None:
            return False, f"No se encontró un médico con código '{codigo}'.", None

        if medico.activo:
            return False, "El médico ya está activo.", None

        medico.activo = True
        self.guardar()
        return True, "Médico reactivado correctamente.", medico

    def buscar_por_codigo(self, codigo: str):
        """Retorna el médico con ese código o None si no existe"""
        return self.indice.get(codigo)

    def guardar(self) -> None:
        """Persiste la lista de médicos en el repositorio"""
        guardar_medicos(self.medicos)
