"""
Se encarga de generar la factura de una cita (con sus líneas de servicio),
calcular el IVA y el total, y registrar el pago. Depende de ServicioCitas
para validar que la cita exista y esté como facturable.
"""
from Entidades.factura import Factura
from Entidades.detalle_factura import DetalleFactura
from Entidades.constantes import ESTADO_FACTURA_PENDIENTE, ESTADO_COMPLETADA
from DAL.repositorio import (
    cargar_servicios, obtener_servicio_por_id,
    insertar_factura, actualizar_factura, obtener_factura_por_cita,
    insertar_detalle_factura, obtener_detalles_por_factura,
    actualizar_cita
)


class ServicioFacturacion:
    """Gestiona la generación de facturas y el registro de pagos de citas"""

    def __init__(self, serv_citas):
        """Recibe ServicioCitas para poder validar la cita
        antes de facturarla"""
        self.serv_citas = serv_citas

    def listar_servicios_activos(self) -> list:
        """Retorna solo los servicios que se pueden ofrecer/cobrar actualmente."""
        return [s for s in cargar_servicios() if s.activo]

    def generar_factura(self, id_cita: int, lineas: list) -> tuple:
        """Genera la factura de una cita a partir de una lista de líneas.

        Las lineas debe ser una lista de diccionarios

        Retorna (exito: bool, mensaje: str, factura: Factura o None, detalles: list)
        """
        #La cita debe existir
        cita = self.serv_citas.buscar_por_id(id_cita)
        if cita is None:
            return False, f"No se encontró una cita con id '{id_cita}'.", None, []

        #No se puede facturar una cita cancelada
        if cita.estado == "Cancelada":
            return False, "No se puede facturar una cita cancelada.", None, []

        #No se puede facturar dos veces la misma cita
        factura_existente = obtener_factura_por_cita(id_cita)
        if factura_existente is not None:
            return False, f"La cita '{id_cita}' ya tiene una factura registrada.", None, []

        #Debe venir al menos una línea de servicio
        if not lineas:
            return False, "Debe indicar al menos un servicio a cobrar.", None, []

        #Validar cada línea contra el catálogo de servicios ANTES de crear nada,
        # así si algo falla no queda una factura a medias
        lineas_validadas = []  # lista de tuplas (servicio, cantidad)
        for linea in lineas:
            id_servicio = linea.get("id_servicio")
            cantidad = linea.get("cantidad")

            servicio = obtener_servicio_por_id(id_servicio)
            if servicio is None:
                return False, f"No se encontró el servicio con id '{id_servicio}'.", None, []
            if not servicio.activo:
                return False, f"El servicio '{servicio.nombre}' no está activo.", None, []
            if not isinstance(cantidad, int) or cantidad <= 0:
                return False, f"La cantidad para '{servicio.nombre}' debe ser un entero mayor a 0.", None, []

            lineas_validadas.append((servicio, cantidad))

        #Todo válido: se arma la factura
        factura = Factura(
            id_factura=None,
            id_cita=id_cita,
            identificacion_paciente=cita.identificacion_paciente,
            subtotal=0.0,
            estado=ESTADO_FACTURA_PENDIENTE
        )
        for servicio, cantidad in lineas_validadas:
            monto_linea = round(servicio.precio * cantidad, 2)
            factura.agregar_monto(monto_linea)

        #Se inserta la factura ya con el subtotal final, para que
        # el impuesto y el total que se guardan queden correctos
        insertar_factura(factura)

        #Se inserta cada línea de detalle, ligada al idFactura recién creado
        detalles = []
        for servicio, cantidad in lineas_validadas:
            detalle = DetalleFactura(
                id_detalle=None,
                id_factura=factura.id_factura,
                id_servicio=servicio.id_servicio,
                cantidad=cantidad,
                precio_unitario=servicio.precio
            )
            insertar_detalle_factura(detalle)
            detalles.append(detalle)

        return True, "Factura generada correctamente.", factura, detalles

    def obtener_detalle_para_mostrar(self, id_cita: int) -> tuple:
        """Retorna la factura de una cita junto con sus líneas, tal como se debe
        mostrar en pantalla antes de pagar"""
        factura = obtener_factura_por_cita(id_cita)
        if factura is None:
            return None, []
        detalles = obtener_detalles_por_factura(factura.id_factura)
        return factura, detalles

    def anular_factura(self, id_cita: int) -> tuple:
        """Anula la factura de una cita. Es el "eliminar" de una factura:
        no se borra porque es un documento contable, se marca como anulada.

        Retorna (exito: bool, mensaje: str, factura: Factura o None)
        """
        factura = obtener_factura_por_cita(id_cita)
        if factura is None:
            return False, f"La cita '{id_cita}' todavía no tiene una factura generada.", None

        if factura.estado == "Anulada":
            return False, "Esta factura ya está anulada.", None

        try:
            factura.marcar_anulada()
        except ValueError as e:
            return False, str(e), None

        actualizar_factura(factura)
        return True, "Factura anulada correctamente.", factura

    def registrar_pago(self, id_cita: int, metodo_pago: str) -> tuple:
        """Marca como pagada la factura de una cita y actualiza la cita a Completada.

        Retorna (exito: bool, mensaje: str, factura: Factura o None)
        """
        factura = obtener_factura_por_cita(id_cita)
        if factura is None:
            return False, f"La cita '{id_cita}' todavía no tiene una factura generada.", None

        if factura.estado == "Pagada":
            return False, "Esta factura ya fue pagada.", None
        if factura.estado == "Anulada":
            return False, "No se puede pagar una factura anulada.", None

        # Marca la factura como pagada (valida que venga un método de pago)
        factura.marcar_pagada(metodo_pago)
        actualizar_factura(factura)

        # La cita pasa a "Completada" una vez que se cobró
        cita = self.serv_citas.buscar_por_id(id_cita)
        if cita is not None:
            cita.cambiar_estado(ESTADO_COMPLETADA)
            actualizar_cita(cita)

        return True, "Pago registrado correctamente.", factura