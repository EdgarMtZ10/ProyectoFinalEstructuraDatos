"""Servicio de búsqueda de médicos y horarios disponibles"""


class ServicioBusquedas:
    """Permite buscar médicos por criterios combinados y consultar su disponibilidad"""

    def __init__(self, serv_medicos, serv_especialidades, serv_horarios):
        """Inicializa el servicio con las dependencias necesarias"""
        self.serv_medicos = serv_medicos
        self.serv_especialidades = serv_especialidades
        self.serv_horarios = serv_horarios

    def _nombre_especialidad(self, id_esp):
        """Retorna el nombre de la especialidad o su id si no se encuentra"""
        esp = self.serv_especialidades.indice.get(id_esp)
        return esp.nombre if esp else str(id_esp)

    def buscar_medicos(self, nombre=None, apellido=None, identificacion=None,
                   ids_especialidad=None, fecha_disponible=None) -> list:
        """Busca médicos combinando criterios con AND (todos los presentes deben cumplirse).
        Retorna vista_publica() de cada médico con especialidades en texto"""
        resultados = []

        for medico in self.serv_medicos.medicos:
            # Los médicos eliminados no aparecen en las búsquedas
            if not medico.activo:
                continue

            # Filtro por nombre (coincidencia parcial, case-insensitive)
            if nombre is not None:
                nombre_completo = f"{medico.nombre} {medico.apellido1} {medico.apellido2}".lower()
                if nombre.lower() not in nombre_completo:
                    continue
            # Filtro por apellido (busca en apellido1 y apellido2)
            if apellido is not None:
                apellido_lower = apellido.lower()
                if (apellido_lower not in medico.apellido1.lower() and
                        apellido_lower not in medico.apellido2.lower()):
                    continue

            # Filtro por identificación (coincidencia parcial)
            if identificacion is not None:
                if identificacion not in medico.identificacion:
                    continue    

            # Filtro por especialidad: al menos una de las indicadas
            if ids_especialidad is not None:
                tiene_alguna = any(id_e in medico.especialidades for id_e in ids_especialidad)
                if not tiene_alguna:
                    continue

            # Filtro por disponibilidad en fecha
            if fecha_disponible is not None:
                slots = self.serv_horarios.slots_disponibles(medico.codigo, fecha_disponible)
                if not slots:
                    continue

            # Armar vista pública con nombres de especialidades en texto
            vista = medico.vista_publica()
            vista["especialidades"] = [
                self._nombre_especialidad(id_e) for id_e in medico.especialidades
            ]
            resultados.append(vista)

        return resultados

    def horarios_disponibles_de(self, codigo_medico: str, fecha=None) -> list:
        """Retorna los slots disponibles de un médico, opcionalmente filtrados por fecha"""
        return self.serv_horarios.slots_disponibles(codigo_medico, fecha)
