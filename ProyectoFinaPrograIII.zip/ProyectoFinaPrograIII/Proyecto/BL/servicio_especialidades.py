"""Servicio de lógica de negocio para especialidades"""

from Entidades.especialidad import Especialidad
from DAL.repositorio import cargar_especialidades, guardar_especialidades


class ServicioEspecialidades:
    """Gestiona el registro, modificación y consulta de especialidades"""

    def __init__(self):
        """Carga las especialidades desde el repositorio e inicializa el índice"""
        self.especialidades = cargar_especialidades()
        self.indice = {e.id_especialidad: e for e in self.especialidades}

    def _nombre_duplicado(self, nombre: str) -> bool:
        """Verifica si ya existe una especialidad con el mismo nombre (case-insensitive)"""
        nombre_normalizado = nombre.strip().lower()
        # Solo cuentan las activas: el nombre de una eliminada se puede reutilizar
        return any(e.nombre.strip().lower() == nombre_normalizado
                   for e in self.especialidades if e.activo)

    def registrar(self, nombre: str) -> tuple:
        """Registra una nueva especialidad con id autogenerado"""
        if self._nombre_duplicado(nombre):
            return False, f"Ya existe una especialidad con el nombre '{nombre.strip()}'.", None

        nuevo_id = max(self.indice.keys()) + 1 if self.indice else 1

        try:
            nueva = Especialidad(nuevo_id, nombre)
        except ValueError as e:
            return False, str(e), None

        self.especialidades.append(nueva)
        self.indice[nueva.id_especialidad] = nueva
        self.guardar()
        return True, "Especialidad registrada correctamente.", nueva

    def modificar(self, id_especialidad: int, nombre: str) -> tuple:
        """Modifica el nombre de una especialidad existente"""
        especialidad = self.indice.get(id_especialidad)
        if especialidad is None:
            return False, f"No se encontró una especialidad con id '{id_especialidad}'.", None

        if self._nombre_duplicado(nombre) and nombre.strip().lower() != especialidad.nombre.strip().lower():
            return False, f"Ya existe una especialidad con el nombre '{nombre.strip()}'.", None

        try:
            actualizada = Especialidad(id_especialidad, nombre, especialidad.activo)
        except ValueError as e:
            return False, str(e), None

        pos = self.especialidades.index(especialidad)
        self.especialidades[pos] = actualizada
        self.indice[id_especialidad] = actualizada
        self.guardar()
        return True, "Especialidad modificada correctamente.", actualizada

    def listar(self, incluir_inactivos=False) -> list:
        """Retorna las especialidades. Por defecto solo las activas"""
        if incluir_inactivos:
            return self.especialidades
        return [e for e in self.especialidades if e.activo]

    def obtener(self, id_especialidad: int):
        """Retorna la especialidad con ese id o None si no existe"""
        return self.indice.get(id_especialidad)

    def eliminar(self, id_especialidad: int) -> tuple:
        """Elimina una especialidad de forma lógica: la marca como inactiva"""
        especialidad = self.indice.get(id_especialidad)
        if especialidad is None:
            return False, f"No se encontró una especialidad con id '{id_especialidad}'.", None

        if not especialidad.activo:
            return False, "La especialidad ya está eliminada.", None

        especialidad.activo = False
        self.guardar()
        return True, "Especialidad eliminada correctamente.", especialidad

    def reactivar(self, id_especialidad: int) -> tuple:
        """Vuelve a activar una especialidad eliminada"""
        especialidad = self.indice.get(id_especialidad)
        if especialidad is None:
            return False, f"No se encontró una especialidad con id '{id_especialidad}'.", None

        if especialidad.activo:
            return False, "La especialidad ya está activa.", None

        especialidad.activo = True
        self.guardar()
        return True, "Especialidad reactivada correctamente.", especialidad

    def existe(self, id_especialidad: int) -> bool:
        """Verifica si existe una especialidad activa con el id dado.
        Una especialidad eliminada no se puede asignar a un médico"""
        especialidad = self.indice.get(id_especialidad)
        return especialidad is not None and especialidad.activo

    def guardar(self) -> None:
        """Persiste la lista de especialidades en el repositorio"""
        guardar_especialidades(self.especialidades)
