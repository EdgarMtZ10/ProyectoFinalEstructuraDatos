"""Servicio de lógica de para autenticación de usuarios"""

from Entidades.usuario import Usuario, ROLES_VALIDOS
from BL.seguridad import generar_hash, verificar
from DAL.repositorio import cargar_usuarios, guardar_usuarios


class ServicioUsuarios:
    """Gestiona el login de clientes y empleados"""

    def __init__(self):
        """Carga los usuarios desde el repositorio e inicializa el índice"""
        self.usuarios = cargar_usuarios()
        self.indice = {u.usuario: u for u in self.usuarios}

    def _validar_login(self, nombre_usuario: str, contrasena: str, rol_esperado: str) -> tuple:
        """Lógica compartida de validación entre login de cliente y de empleado.
        Retorna (exito, mensaje, usuario)"""
        usuario = self.indice.get(nombre_usuario)

        if usuario is None:
            return False, "Usuario o contraseña incorrectos.", None

        if not verificar(contrasena, usuario.contrasena):
            return False, "Usuario o contraseña incorrectos.", None

        if not usuario.activo:
            return False, "Esta cuenta se encuentra inactiva.", None

        # Un cliente no puede loguearse como empleado y viceversa
        if rol_esperado == "Cliente" and usuario.rol != "Cliente":
            return False, "Esta cuenta no corresponde a un cliente.", None
        if rol_esperado == "Empleado" and usuario.rol == "Cliente":
            return False, "Esta cuenta no corresponde a un empleado.", None

        return True, "Inicio de sesión exitoso.", usuario

    def login_cliente(self, nombre_usuario: str, contrasena: str) -> tuple:
        """Valida el login de un cliente (solo usuarios activos con rol Cliente)"""
        return self._validar_login(nombre_usuario, contrasena, "Cliente")

    def login_empleado(self, nombre_usuario: str, contrasena: str) -> tuple:
        """Valida el login de un empleado (solo empleados activos, cualquier
        rol distinto de Cliente: Administrador, Recepcionista o Medico)"""
        return self._validar_login(nombre_usuario, contrasena, "Empleado")

    # --- CRUD de cuentas ---

    def listar(self, incluir_inactivos=False) -> list:
        """Retorna los usuarios. Por defecto solo los activos"""
        if incluir_inactivos:
            return self.usuarios
        return [u for u in self.usuarios if u.activo]

    def obtener(self, nombre_usuario: str):
        """Retorna el usuario con ese nombre o None si no existe"""
        return self.indice.get(nombre_usuario)

    def registrar(self, datos: dict) -> tuple:
        """Registra una cuenta nueva"""
        nombre_usuario = datos.get("usuario", "")

        if nombre_usuario in self.indice:
            return False, f"Ya existe un usuario con el nombre '{nombre_usuario}'.", None

        contrasena = datos.get("contrasena", "")
        if not contrasena or not contrasena.strip():
            return False, "La contraseña es obligatoria.", None

        try:
            nuevo = Usuario(
                usuario=nombre_usuario,
                contrasena=generar_hash(contrasena),
                rol=datos.get("rol", ""),
                referencia=datos.get("referencia"),
                activo=datos.get("activo", True)
            )
        except ValueError as e:
            return False, str(e), None

        self.usuarios.append(nuevo)
        self.indice[nuevo.usuario] = nuevo
        self.guardar()
        return True, "Usuario registrado correctamente.", nuevo

    def modificar(self, nombre_usuario: str, cambios: dict) -> tuple:
        """Modifica la contraseña, el rol o la referencia de una cuenta.
        El nombre de usuario no se puede cambiar porque es la llave"""
        usuario = self.indice.get(nombre_usuario)
        if usuario is None:
            return False, f"No se encontró un usuario con el nombre '{nombre_usuario}'.", None

        rol = cambios.get("rol", usuario.rol)
        if rol not in ROLES_VALIDOS:
            return False, f"Rol inválido. Debe ser uno de: {ROLES_VALIDOS}.", None

        # Si viene una contraseña nueva se guarda hasheada; si no, se deja la que estaba
        if "contrasena" in cambios:
            nueva = cambios["contrasena"]
            if not nueva or not nueva.strip():
                return False, "La contraseña es obligatoria.", None
            usuario.contrasena = generar_hash(nueva)

        usuario.rol = rol
        usuario.referencia = cambios.get("referencia", usuario.referencia)

        self.guardar()
        return True, "Usuario modificado correctamente.", usuario

    def eliminar(self, nombre_usuario: str) -> tuple:
        """Elimina una cuenta de forma lógica: la desactiva.
        Una cuenta inactiva no puede iniciar sesión"""
        usuario = self.indice.get(nombre_usuario)
        if usuario is None:
            return False, f"No se encontró un usuario con el nombre '{nombre_usuario}'.", None

        if not usuario.activo:
            return False, "El usuario ya está eliminado.", None

        usuario.activo = False
        self.guardar()
        return True, "Usuario eliminado correctamente.", usuario

    def reactivar(self, nombre_usuario: str) -> tuple:
        """Vuelve a activar una cuenta eliminada"""
        usuario = self.indice.get(nombre_usuario)
        if usuario is None:
            return False, f"No se encontró un usuario con el nombre '{nombre_usuario}'.", None

        if usuario.activo:
            return False, "El usuario ya está activo.", None

        usuario.activo = True
        self.guardar()
        return True, "Usuario reactivado correctamente.", usuario

    def cambiar_contrasena(self, nombre_usuario: str, contrasena_actual: str,
                           contrasena_nueva: str) -> tuple:
        """Cambia la contraseña validando primero la actual"""
        usuario = self.indice.get(nombre_usuario)
        if usuario is None:
            return False, "Usuario o contraseña incorrectos.", None

        if not verificar(contrasena_actual, usuario.contrasena):
            return False, "Usuario o contraseña incorrectos.", None

        if not contrasena_nueva or not contrasena_nueva.strip():
            return False, "La contraseña nueva es obligatoria.", None

        usuario.contrasena = generar_hash(contrasena_nueva)
        self.guardar()
        return True, "Contraseña actualizada correctamente.", usuario

    def guardar(self) -> None:
        """Persiste la lista de usuarios en el repositorio"""
        guardar_usuarios(self.usuarios)
