"""Manejo seguro de contraseñas.

Las contraseñas nunca se guardan tal cual: se guarda un hash del que no se
puede volver a la contraseña original. Para poder verificar un login se guarda
también la "sal", que es un texto aleatorio distinto para cada usuario y que
hace que dos personas con la misma contraseña tengan hashes diferentes.

Formato guardado:   pbkdf2$<sal>$<hash>
"""

import hashlib
import secrets

# Algoritmo y cantidad de repeticiones. Entre más repeticiones, más lento es
# probar contraseñas por fuerza bruta.
ALGORITMO = "pbkdf2"
ITERACIONES = 100000
SEPARADOR = "$"


def _calcular(sal: str, contrasena: str) -> str:
    """Calcula el hash de una contraseña usando una sal dada"""
    resultado = hashlib.pbkdf2_hmac(
        "sha256",
        contrasena.encode("utf-8"),
        bytes.fromhex(sal),
        ITERACIONES
    )
    return resultado.hex()


def generar_hash(contrasena: str) -> str:
    """Retorna el hash de una contraseña, con una sal nueva y aleatoria"""
    if not contrasena or not contrasena.strip():
        raise ValueError("La contraseña no puede estar vacía.")

    sal = secrets.token_hex(16)
    return SEPARADOR.join([ALGORITMO, sal, _calcular(sal, contrasena)])


def es_hash(valor) -> bool:
    """Indica si el valor guardado ya está en formato de hash.
    Sirve para detectar contraseñas viejas guardadas en texto plano"""
    if not isinstance(valor, str):
        return False
    partes = valor.split(SEPARADOR)
    return len(partes) == 3 and partes[0] == ALGORITMO


def verificar(contrasena: str, guardado: str) -> bool:
    """Compara una contraseña escrita por el usuario contra el hash guardado.
    Retorna False si el valor guardado no es un hash válido"""
    if not es_hash(guardado):
        return False

    _, sal, esperado = guardado.split(SEPARADOR)

    try:
        calculado = _calcular(sal, contrasena)
    except ValueError:
        return False

    # compare_digest compara sin delatar en cuántos caracteres coincide
    return secrets.compare_digest(calculado, esperado)
