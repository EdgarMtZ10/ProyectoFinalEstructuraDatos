"""Servicio de lógica de negocio para los datos generales de la clínica"""

from Entidades.clinica import Clinica
from DAL.repositorio import cargar_clinica, guardar_clinica, borrar_clinica


class ServicioClinica:
    """Gestiona los datos generales de la clínica.
    Solo existe un registro, así que no hay listar ni buscar por id"""

    def __init__(self):
        """Carga los datos de la clínica desde el repositorio"""
        self.clinica = cargar_clinica()

    def obtener(self):
        """Retorna los datos de la clínica o None si no se han registrado"""
        return self.clinica

    def registrar(self, datos: dict) -> tuple:
        """Registra los datos de la clínica por primera vez"""
        if self.clinica is not None:
            return False, "Los datos de la clínica ya están registrados. Use modificar.", None

        try:
            nueva = Clinica(
                nombre=datos.get("nombre", ""),
                direccion=datos.get("direccion", ""),
                telefono=datos.get("telefono", ""),
                correo=datos.get("correo", ""),
                hora_apertura=datos.get("hora_apertura", ""),
                hora_cierre=datos.get("hora_cierre", ""),
                dias_laborales=datos.get("dias_laborales", [])
            )
        except ValueError as e:
            return False, str(e), None

        guardar_clinica(nueva)
        self.clinica = nueva
        return True, "Datos de la clínica registrados correctamente.", nueva

    def modificar(self, cambios: dict) -> tuple:
        """Modifica los datos de la clínica"""
        if self.clinica is None:
            return False, "Todavía no se han registrado los datos de la clínica.", None

        actual = self.clinica
        try:
            actualizada = Clinica(
                nombre=cambios.get("nombre", actual.nombre),
                direccion=cambios.get("direccion", actual.direccion),
                telefono=cambios.get("telefono", actual.telefono),
                correo=cambios.get("correo", actual.correo),
                hora_apertura=cambios.get("hora_apertura", actual.hora_apertura),
                hora_cierre=cambios.get("hora_cierre", actual.hora_cierre),
                dias_laborales=cambios.get("dias_laborales", actual.dias_laborales)
            )
        except ValueError as e:
            return False, str(e), None

        guardar_clinica(actualizada)
        self.clinica = actualizada
        return True, "Datos de la clínica modificados correctamente.", actualizada

    def eliminar(self) -> tuple:
        """Borra los datos de la clínica.
        Es un borrado real porque la clínica no la referencia nadie"""
        if self.clinica is None:
            return False, "Todavía no se han registrado los datos de la clínica.", None

        borrada = self.clinica
        borrar_clinica()
        self.clinica = None
        return True, "Datos de la clínica eliminados correctamente.", borrada
