"""Servicio de lógica de negocio para citas"""

from datetime import datetime, timedelta
from Entidades.cita import Cita
from Entidades.constantes import FORMATO_FECHA, MAX_DIAS_ANTICIPACION, MIN_DIAS_ANTICIPACION_CAMBIO
from DAL.repositorio import cargar_citas, guardar_citas


class ServicioCitas:
    """Gestiona la reserva, cancelación y consulta de citas médicas"""

    def __init__(self, serv_horarios, serv_pacientes, serv_medicos):
        """Carga las citas desde el repositorio e inicializa las dependencias"""
        self.citas = cargar_citas()
        self.serv_horarios = serv_horarios
        self.serv_pacientes = serv_pacientes
        self.serv_medicos = serv_medicos

    def reservar(self, identificacion_paciente: str, codigo_medico: str,
                 id_horario: int) -> tuple:
        """Reserva una cita validando paciente, médico, slot y restricciones de tiempo"""
        # 1. Paciente existe
        paciente = self.serv_pacientes.buscar_por_identificacion(identificacion_paciente)
        if paciente is None:
            return False, f"No se encontró un paciente con identificación '{identificacion_paciente}'.", None
        if not paciente.activo:
            return False, "No se puede reservar: el paciente está eliminado.", None

        # 2. Médico existe
        medico = self.serv_medicos.buscar_por_codigo(codigo_medico)
        if medico is None:
            return False, f"No se encontró un médico con código '{codigo_medico}'.", None
        if not medico.activo:
            return False, "No se puede reservar: el médico está eliminado.", None

        # 3. Slot existe y pertenece al médico
        slot = self.serv_horarios.buscar_slot(id_horario)
        if slot is None:
            return False, f"No se encontró el slot con id '{id_horario}'.", None
        if not slot.activo:
            return False, "No se puede reservar: el slot está eliminado.", None
        if slot.codigo_medico != codigo_medico:
            return False, "El slot no pertenece al médico indicado.", None

        # 4. Validación clínica del slot
        valido, motivo = slot.es_valido()
        if not valido:
            return False, f"El slot no es válido: {motivo}", None

        # 5. Disponibilidad
        if not slot.disponible:
            return False, "El slot ya está ocupado.", None

        # 6. Anticipación: hoy <= fecha_slot <= hoy + 30 días
        hoy = datetime.today().date()
        fecha_slot = datetime.strptime(slot.fecha, FORMATO_FECHA).date()
        if fecha_slot < hoy:
            return False, "No se puede reservar una cita en una fecha pasada.", None
        if fecha_slot > hoy + timedelta(days=MAX_DIAS_ANTICIPACION):
            return False, f"No se puede reservar con más de {MAX_DIAS_ANTICIPACION} días de anticipación.", None

        # Todo correcto: marcar slot ocupado y crear la cita
        slot.cambiar_disponibilidad(False)
        self.serv_horarios.guardar()

        nueva_cita = Cita(
            id_cita=None,
            identificacion_paciente=identificacion_paciente,
            codigo_medico=codigo_medico,
            id_horario=id_horario,
            fecha=slot.fecha,
            hora=slot.hora_inicio
        )
        self.citas.append(nueva_cita)
        self.guardar()
        return True, "Cita reservada correctamente.", nueva_cita

    def _validar_anticipacion_minima(self, cita, accion: str) -> tuple:
        """Verifica que falten al menos MIN_DIAS_ANTICIPACION_CAMBIO días para la cita"""
        hoy = datetime.today().date()
        fecha_cita = datetime.strptime(cita.fecha, FORMATO_FECHA).date()
        dias_restantes = (fecha_cita - hoy).days

        if dias_restantes < MIN_DIAS_ANTICIPACION_CAMBIO:
            return False, (
                f"No se puede {accion} una cita con menos de "
                f"{MIN_DIAS_ANTICIPACION_CAMBIO} días de anticipación."
            )
        return True, ""

    def cancelar(self, id_cita: int) -> tuple:
        """Cancela una cita y libera el slot asociado"""
        cita = None
        for c in self.citas:
            if c.id_cita == id_cita:
                cita = c
                break

        if cita is None:
            return False, f"No se encontró una cita con el id '{id_cita}'.", None

        if cita.estado == "Cancelada":
            return False, "La cita ya está cancelada.", None

        # NUEVO: exige la anticipación mínima antes de cancelar
        valido, motivo = self._validar_anticipacion_minima(cita, "cancelar")
        if not valido:
            return False, motivo, None

        cita.cambiar_estado("Cancelada")

        # Liberar el campo asociado
        slot = self.serv_horarios.buscar_slot(cita.id_horario)
        if slot is not None:
            slot.cambiar_disponibilidad(True)
            self.serv_horarios.guardar()

        self.guardar()
        return True, "Cita cancelada correctamente.", cita

    def reprogramar(self, id_cita: int, nuevo_id_horario: int) :
        """Reprograma una cita a un nuevo slot, validando el nuevo slot antes de tocar el viejo"""
        # Localizar la cita
        cita = None
        for c in self.citas:
            if c.id_cita == id_cita:
                cita = c
                break

        if cita is None:
            return False, f"No se encontró una cita con id '{id_cita}'.", None

        if cita.estado == "Cancelada":
            return False, "No se puede reprogramar una cita cancelada.", None

        # NUEVO: exige la anticipación mínima antes de reprogramar
        # (se valida contra la fecha ACTUAL de la cita, no la nueva)
        valido, motivo = self._validar_anticipacion_minima(cita, "reprogramar")
        if not valido:
            return False, motivo, None

        # Validar el nuevo slot con la misma lógica de reservar (sin tocar nada aún)
        nuevo_slot = self.serv_horarios.buscar_slot(nuevo_id_horario)
        if nuevo_slot is None:
            return False, f"No se encontró el slot con id '{nuevo_id_horario}'.", None

        if not nuevo_slot.activo:
            return False, "No se puede reprogramar: el slot nuevo está eliminado.", None

        medico = self.serv_medicos.buscar_por_codigo(cita.codigo_medico)
        if medico is not None and not medico.activo:
            return False, "No se puede reprogramar: el médico está eliminado.", None

        if nuevo_slot.codigo_medico != cita.codigo_medico:
            return False, "El nuevo slot no pertenece al mismo médico.", None

        valido, motivo = nuevo_slot.es_valido()
        if not valido:
            return False, f"El nuevo slot no es válido: {motivo}", None

        if not nuevo_slot.disponible:
            return False, "El nuevo slot ya está ocupado.", None

        hoy = datetime.today().date()
        fecha_nuevo = datetime.strptime(nuevo_slot.fecha, FORMATO_FECHA).date()
        if fecha_nuevo < hoy:
            return False, "No se puede reprogramar a una fecha pasada.", None
        if fecha_nuevo > hoy + timedelta(days=MAX_DIAS_ANTICIPACION):
            return False, f"No se puede reprogramar con más de {MAX_DIAS_ANTICIPACION} días de anticipación.", None

        # Todo válido: liberar slot viejo, ocupar nuevo, actualizar cita
        slot_viejo = self.serv_horarios.buscar_slot(cita.id_horario)
        if slot_viejo is not None:
            slot_viejo.cambiar_disponibilidad(True)

        nuevo_slot.cambiar_disponibilidad(False)
        self.serv_horarios.guardar()

        # La cita queda apuntando al slot nuevo
        cita.id_horario = nuevo_slot.id_horario
        cita.fecha = nuevo_slot.fecha
        cita.hora = nuevo_slot.hora_inicio
        self.guardar()
        return True, "Cita reprogramada correctamente.", cita

    def buscar_por_paciente(self, identificacion: str) -> list:
        """Retorna todas las citas del paciente con esa identificación"""
        return [c for c in self.citas if c.identificacion_paciente == identificacion]

    def buscar_por_medico(self, codigo: str) -> list:
        """Retorna todas las citas del médico con ese código"""
        return [c for c in self.citas if c.codigo_medico == codigo]

    def buscar_por_fecha(self, fecha: str) -> list:
        """Retorna todas las citas en esa fecha"""
        return [c for c in self.citas if c.fecha == fecha]

    def buscar_por_estado(self, estado: str) -> list:
        """Retorna todas las citas con ese estado"""
        return [c for c in self.citas if c.estado == estado]

    def buscar_por_id(self, id_cita: int):
        """Retorna la cita con ese id o None si no existe"""
        for c in self.citas:
            if c.id_cita == id_cita:
                return c
        return None

    def guardar(self) -> None:
        """Persiste la lista de citas en el repositorio"""
        guardar_citas(self.citas)
