"""Migración: convierte a hash las contraseñas que estén guardadas en texto plano.

Se ejecuta UNA sola vez, después de actualizar el sistema:
    python migrar_contrasenas.py

Las cuentas que ya tienen la contraseña hasheada se dejan como están, así que
volver a correr el script no hace daño.
"""

from BL.seguridad import generar_hash, es_hash
from DAL.repositorio import cargar_usuarios, guardar_usuarios


def main():
    """Recorre los usuarios y hashea las contraseñas que estén en texto plano"""
    usuarios = cargar_usuarios()

    if not usuarios:
        print("No hay usuarios registrados. No hay nada que migrar.")
        return

    convertidos = 0
    for u in usuarios:
        if es_hash(u.contrasena):
            print(f"  {u.usuario}: ya estaba hasheada, se deja igual.")
            continue

        u.contrasena = generar_hash(u.contrasena)
        convertidos += 1
        print(f"  {u.usuario}: contraseña convertida a hash.")

    if convertidos == 0:
        print("Todas las contraseñas ya estaban hasheadas.")
        return

    guardar_usuarios(usuarios)
    print(f"\nListo: se migraron {convertidos} contraseña(s) de {len(usuarios)} usuario(s).")


if __name__ == "__main__":
    main()
