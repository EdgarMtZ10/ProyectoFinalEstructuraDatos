"""Clase Servicio del dominio de la clínica.

Representa un servicio facturable (como una consulta)
Corresponde a la tabla Servicios en SQL
"""


class Servicio:
    """Representa un servicio del catálogo que se puede facturar a un paciente"""

    def __init__(self, id_servicio, nombre, precio, descripcion="", activo=True):
        """Crea un servicio validando nombre y precio"""
        # El nombre no puede venir vacío
        if not nombre or not nombre.strip():
            raise ValueError("El nombre del servicio es obligatorio.")

        # El precio debe ser un número (int o float) y no puede ser negativo
        if not isinstance(precio, (int, float)) or precio < 0:
            raise ValueError("El precio debe ser un número mayor o igual a 0.")

        self.id_servicio = id_servicio
        self.nombre = nombre
        self.descripcion = descripcion
        self.precio = precio
        self.activo = activo

    def cambiar_estado(self, activo: bool):
        """Activa o desactiva el servicio (para que deje de ofrecerse sin borrarlo)"""
        self.activo = activo

    def to_dict(self) -> dict:
        """Convierte el servicio a diccionario"""
        return {
            "id_servicio": self.id_servicio,
            "nombre": self.nombre,
            "descripcion": self.descripcion,
            "precio": self.precio,
            "activo": self.activo
        }

    @classmethod
    def from_dict(cls, data):
        """Crea un Servicio a partir de un diccionario"""
        return cls(
            id_servicio=data["id_servicio"],
            nombre=data["nombre"],
            precio=data["precio"],
            descripcion=data.get("descripcion", ""),
            activo=data.get("activo", True)
        )

    def __str__(self) -> str:
        estado = "Activo" if self.activo else "Inactivo"
        return f"[{self.id_servicio}] {self.nombre} - ₡{self.precio:,.2f} | {estado}"