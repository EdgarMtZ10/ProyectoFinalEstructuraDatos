"""Clase Especialidad del dominio de la clínica"""


class Especialidad:
    """Representa una especialidad médica"""

    def __init__(self, id_especialidad, nombre, activo=True):
        """Crea una especialidad validando sus datos"""
        if not isinstance(id_especialidad, int) or id_especialidad <= 0:
            raise ValueError("El id_especialidad debe ser un entero positivo.")
        if not nombre.strip():
            raise ValueError("El nombre de la especialidad no puede estar vacío.")

        self.id_especialidad = id_especialidad
        self.nombre = nombre.strip()
        # activo=False significa que la especialidad fue eliminada (borrado lógico)
        self.activo = activo

    def to_dict(self) -> dict:
        """Convierte la especialidad a diccionario para guardar en JSON"""
        return {
            "id_especialidad": self.id_especialidad,
            "nombre": self.nombre,
            "activo": self.activo
        }

    @classmethod
    def from_dict(cls, data):
        """Crea una Especialidad a partir de un diccionario leído del JSON"""
        return cls(
            id_especialidad=data["id_especialidad"],
            nombre=data["nombre"],
            activo=data.get("activo", True)
        )

    def __str__(self) -> str:
        estado = "" if self.activo else " (eliminada)"
        return f"[{self.id_especialidad}] {self.nombre}{estado}"
