"""Constantes globales del sistema de clínica."""

# Horario de atención
HORA_APERTURA = "07:00"
HORA_CIERRE = "22:00"

# Duración de cada slot de cita en minutos
DURACION_SLOT_MIN = 30

# Días laborales: lunes (0) a sábado (5); se excluye domingo (6)
DIAS_LABORALES = [0, 1, 2, 3, 4, 5]

# Anticipación máxima de reserva en días
MAX_DIAS_ANTICIPACION = 30

# Estados válidos de una cita
ESTADO_RESERVADA = "Reservada"
ESTADO_CANCELADA = "Cancelada"
ESTADO_COMPLETADA = "Completada"

ESTADOS_CITA = [ESTADO_RESERVADA, ESTADO_CANCELADA, ESTADO_COMPLETADA]

# Formato de fecha y hora en JSON y en memoria
FORMATO_FECHA = "%Y-%m-%d"
FORMATO_HORA = "%H:%M"

ESTADO_FACTURA_PENDIENTE = "Pendiente"

ESTADO_FACTURA_PAGADA = "Pagada"

ESTADO_FACTURA_ANULADA = "Anulada"

ESTADOS_FACTURA = [ESTADO_FACTURA_PENDIENTE, ESTADO_FACTURA_PAGADA,
                   ESTADO_FACTURA_ANULADA]

PORCENTAJE_IVA = 13

# Anticipación mínima para cancelar o reprogramar una cita en días
MIN_DIAS_ANTICIPACION_CAMBIO = 2