"""
Representa una cuenta de acceso al sistema, ya sea de un cliente
o de un empleado. Corresponde a la colección "usuarios" en MongoDB
"""

ROLES_VALIDOS = ["Cliente", "Administrador", "Recepcionista", "Medico"]


class Usuario:
    """Representa una cuenta de acceso al sistema"""

    def __init__(self, usuario, contrasena, rol, referencia=None, activo=True):
        """Crea un usuario validando que el rol sea uno de los permitidos"""
        if not usuario or not usuario.strip():
            raise ValueError("El nombre de usuario es obligatorio.")
        if not contrasena or not contrasena.strip():
            raise ValueError("La contraseña es obligatoria.")
        if rol not in ROLES_VALIDOS:
            raise ValueError(f"Rol inválido. Debe ser uno de: {ROLES_VALIDOS}.")

        self.usuario = usuario
        self.contrasena = contrasena
        self.rol = rol
        # Identificación (si es cliente) o código de médico (si es médico)
        self.referencia = referencia
        self.activo = activo

    def es_cliente(self) -> bool:
        """Indica si esta cuenta corresponde a un cliente (no a un empleado)"""
        return self.rol == "Cliente"

    def to_dict(self) -> dict:
        """Convierte el usuario a diccionario (formato camelCase de la colección)"""
        return {
            "usuario": self.usuario,
            "contrasena": self.contrasena,
            "rol": self.rol,
            "referencia": self.referencia,
            "activo": self.activo
        }

    @classmethod
    def from_dict(cls, data):
        """Crea un Usuario a partir de un diccionario de MongoDB"""
        return cls(
            usuario=data["usuario"],
            contrasena=data["contrasena"],
            rol=data["rol"],
            referencia=data.get("referencia"),
            activo=data.get("activo", True)
        )

    def __str__(self) -> str:
        estado = "Activo" if self.activo else "Inactivo"
        return f"{self.usuario} | Rol: {self.rol} | {estado}"