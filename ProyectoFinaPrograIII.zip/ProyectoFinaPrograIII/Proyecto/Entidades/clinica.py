"""Clase Clinica del dominio: datos generales de la clínica.
Corresponde a la colección "clinica" en MongoDB"""

DIAS_VALIDOS = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]


class Clinica:
    """Representa los datos generales de la clínica"""

    def __init__(self, nombre, direccion, telefono, correo,
                 hora_apertura, hora_cierre, dias_laborales=None):
        """Crea la clínica validando sus datos"""
        if not nombre.strip():
            raise ValueError("El nombre de la clínica no puede estar vacío.")
        if not direccion.strip():
            raise ValueError("La dirección no puede estar vacía.")
        if not telefono.strip():
            raise ValueError("El teléfono no puede estar vacío.")
        if "@" not in correo:
            raise ValueError("El correo debe contener '@'.")

        self.nombre = nombre.strip()
        self.direccion = direccion.strip()
        self.telefono = telefono.strip()
        self.correo = correo.strip()
        self.hora_apertura = hora_apertura
        self.hora_cierre = hora_cierre
        self.dias_laborales = dias_laborales if dias_laborales is not None else []

    def esta_abierta(self, dia: str) -> bool:
        """Indica si la clínica trabaja ese día"""
        return dia in self.dias_laborales

    def to_dict(self) -> dict:
        """Convierte la clínica a diccionario"""
        return {
            "nombre": self.nombre,
            "direccion": self.direccion,
            "telefono": self.telefono,
            "correo": self.correo,
            "hora_apertura": self.hora_apertura,
            "hora_cierre": self.hora_cierre,
            "dias_laborales": self.dias_laborales
        }

    @classmethod
    def from_dict(cls, data):
        """Crea una Clinica a partir de un diccionario"""
        return cls(
            nombre=data["nombre"],
            direccion=data["direccion"],
            telefono=data["telefono"],
            correo=data["correo"],
            hora_apertura=data["hora_apertura"],
            hora_cierre=data["hora_cierre"],
            dias_laborales=data.get("dias_laborales", [])
        )

    def __str__(self) -> str:
        dias = ", ".join(self.dias_laborales) if self.dias_laborales else "Sin definir"
        return (
            f"{self.nombre}\n"
            f"  Dirección: {self.direccion}\n"
            f"  Teléfono: {self.telefono}\n"
            f"  Correo: {self.correo}\n"
            f"  Horario: {self.hora_apertura} - {self.hora_cierre}\n"
            f"  Días laborales: {dias}"
        )
