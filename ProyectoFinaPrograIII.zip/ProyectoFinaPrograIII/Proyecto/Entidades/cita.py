"""Clase Cita del dominio de la clínica"""

from Entidades.constantes import ESTADOS_CITA


class Cita:
    """Representa una cita médica reservada por un paciente"""

    def __init__(self, id_cita, identificacion_paciente, codigo_medico,
                 id_horario, fecha, hora, estado="Reservada"):
        """Crea una cita validando el estado y el id de horario"""
        if not isinstance(id_horario, int) or id_horario <= 0:
            raise ValueError("El id_horario debe ser un entero positivo.")
        if estado not in ESTADOS_CITA:
            raise ValueError(f"Estado inválido. Debe ser uno de: {ESTADOS_CITA}.")

        self.id_cita = id_cita
        self.identificacion_paciente = identificacion_paciente
        self.codigo_medico = codigo_medico
        self.id_horario = id_horario
        self.fecha = fecha
        self.hora = hora
        self.estado = estado

    def cambiar_estado(self, nuevo_estado):
        """Actualiza el estado de la cita validando que sea un valor permitido"""
        if nuevo_estado not in ESTADOS_CITA:
            raise ValueError(f"Estado inválido. Debe ser uno de: {ESTADOS_CITA}.")
        self.estado = nuevo_estado

    def to_dict(self) -> dict:
        """Convierte la cita a diccionario para guardar en JSON"""
        return {
            "id_cita": self.id_cita,
            "identificacion_paciente": self.identificacion_paciente,
            "codigo_medico": self.codigo_medico,
            "id_horario": self.id_horario,
            "fecha": self.fecha,
            "hora": self.hora,
            "estado": self.estado
        }

    @classmethod
    def from_dict(cls, data):
        """Crea una Cita a partir de un diccionario leído del JSON"""
        return cls(
            id_cita=data["id_cita"],
            identificacion_paciente=data["identificacion_paciente"],
            codigo_medico=data["codigo_medico"],
            id_horario=data["id_horario"],
            fecha=data["fecha"],
            hora=data["hora"],
            estado=data.get("estado", "Reservada")
        )

    def __str__(self) -> str:
        return (f"Cita [{self.id_cita}] | Paciente: {self.identificacion_paciente} | "
                f"Médico: {self.codigo_medico} | {self.fecha} {self.hora} | {self.estado}")
