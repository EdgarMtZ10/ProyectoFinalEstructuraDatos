"""Clase Horario (slot de 30 minutos) del dominio de la clínica"""

from datetime import datetime
from Entidades.constantes import (
    HORA_APERTURA, HORA_CIERRE, DURACION_SLOT_MIN,
    DIAS_LABORALES, FORMATO_FECHA, FORMATO_HORA
)


class Horario:
    """Representa un slot de atención de 30 minutos de un médico"""

    def __init__(self, id_horario, codigo_medico, fecha, hora_inicio, hora_fin,
                 disponible=True, activo=True):
        """Crea un horario con los datos del slot"""
        self.id_horario = id_horario
        self.codigo_medico = codigo_medico
        self.fecha = fecha
        self.hora_inicio = hora_inicio
        self.hora_fin = hora_fin
        self.disponible = disponible
        # activo=False significa que el slot fue eliminado (borrado lógico).
        # Es distinto de disponible=False, que significa que está ocupado.
        self.activo = activo

    def es_valido(self):
        """Verifica que el horario cumple todas las reglas del sistema"""
        # Validar fecha
        try:
            fecha_dt = datetime.strptime(self.fecha, FORMATO_FECHA)
        except ValueError:
            return False, "La fecha no tiene el formato correcto (YYYY-MM-DD)."

        if fecha_dt.weekday() not in DIAS_LABORALES:
            return False, "La fecha cae en domingo, no es un día laboral."

        # Validar horas
        try:
            inicio_dt = datetime.strptime(self.hora_inicio, FORMATO_HORA)
            fin_dt = datetime.strptime(self.hora_fin, FORMATO_HORA)
            apertura_dt = datetime.strptime(HORA_APERTURA, FORMATO_HORA)
            cierre_dt = datetime.strptime(HORA_CIERRE, FORMATO_HORA)
        except ValueError:
            return False, "Las horas no tienen el formato correcto (HH:MM)."

        if inicio_dt < apertura_dt:
            return False, f"La hora de inicio es anterior a la apertura ({HORA_APERTURA})."

        if fin_dt > cierre_dt:
            return False, f"La hora de fin supera el cierre ({HORA_CIERRE})."

        # Validar duración exacta de 30 minutos
        diferencia = int((fin_dt - inicio_dt).total_seconds() / 60)
        if diferencia != DURACION_SLOT_MIN:
            return False, f"La duración del slot debe ser exactamente {DURACION_SLOT_MIN} minutos."

        # Validar que inicio esté alineado a slot (minutos en 00 o 30)
        if inicio_dt.minute not in (0, 30):
            return False, "La hora de inicio debe estar alineada a slot (minutos 00 o 30)."

        return True, "Horario válido."

    def cambiar_disponibilidad(self, disponible):
        """Actualiza la disponibilidad del slot"""
        self.disponible = disponible

    def to_dict(self) -> dict:
        """Convierte el horario a diccionario para guardar en JSON"""
        return {
            "id_horario": self.id_horario,
            "codigo_medico": self.codigo_medico,
            "fecha": self.fecha,
            "hora_inicio": self.hora_inicio,
            "hora_fin": self.hora_fin,
            "disponible": self.disponible,
            "activo": self.activo
        }

    @classmethod
    def from_dict(cls, data):
        """Crea un Horario a partir de un diccionario leído del JSON"""
        return cls(
            id_horario=data["id_horario"],
            codigo_medico=data["codigo_medico"],
            fecha=data["fecha"],
            hora_inicio=data["hora_inicio"],
            hora_fin=data["hora_fin"],
            disponible=data.get("disponible", True),
            activo=data.get("activo", True)
        )

    def __str__(self) -> str:
        estado = "Disponible" if self.disponible else "No disponible"
        return f"[{self.id_horario}] Médico {self.codigo_medico} | {self.fecha} {self.hora_inicio}-{self.hora_fin} | {estado}"
