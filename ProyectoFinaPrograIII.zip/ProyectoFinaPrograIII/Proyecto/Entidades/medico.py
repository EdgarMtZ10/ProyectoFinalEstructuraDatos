"""Clase Medico del dominio de la clínica"""

from Entidades.persona import Persona, _validar_no_vacio


class Medico(Persona):
    """Representa a un médico de la clínica"""

    def __init__(self, codigo, identificacion, nombre, apellido1, apellido2,
                 telefono_personal, correo_personal,
                 telefono_clinica, correo_clinica,
                 especialidades=None, activo=True):
        """Crea un médico validando sus datos.
        telefono_personal y correo_personal se usan como telefono/correo base de Persona."""
        _validar_no_vacio(codigo, "codigo")

        super().__init__(identificacion, nombre, apellido1, apellido2,
                         telefono_personal, correo_personal)

        self.codigo = codigo.strip()
        self.telefono_clinica = telefono_clinica.strip()
        self.correo_clinica = correo_clinica.strip()
        self.especialidades = especialidades if especialidades is not None else []
        # activo=False significa que el médico fue eliminado (borrado lógico)
        self.activo = activo

    def agregar_especialidad(self, id_especialidad):
        """Agrega una especialidad al médico si no está ya registrada"""
        if id_especialidad not in self.especialidades:
            self.especialidades.append(id_especialidad)

    def vista_publica(self) -> dict:
        """Retorna los datos públicos del médico, sin información de contacto personal"""
        return {
            "codigo": self.codigo,
            "nombre_completo": self.obtener_nombre_completo(),
            "telefono_clinica": self.telefono_clinica,
            "correo_clinica": self.correo_clinica,
            "especialidades": self.especialidades
        }

    def vista_completa(self) -> dict:
        """Retorna todos los datos del médico incluyendo contacto personal"""
        return {
            "codigo": self.codigo,
            "identificacion": self.identificacion,
            "nombre_completo": self.obtener_nombre_completo(),
            "telefono_personal": self.telefono,
            "correo_personal": self.correo,
            "telefono_clinica": self.telefono_clinica,
            "correo_clinica": self.correo_clinica,
            "especialidades": self.especialidades
        }

    def to_dict(self) -> dict:
        """Convierte el médico a diccionario para guardar en JSON"""
        return {
            "codigo": self.codigo,
            "identificacion": self.identificacion,
            "nombre": self.nombre,
            "apellido1": self.apellido1,
            "apellido2": self.apellido2,
            "telefono_personal": self.telefono,
            "correo_personal": self.correo,
            "telefono_clinica": self.telefono_clinica,
            "correo_clinica": self.correo_clinica,
            "especialidades": self.especialidades,
            "activo": self.activo
        }

    @classmethod
    def from_dict(cls, data):
        """Crea un Medico a partir de un diccionario leído del JSON"""
        return cls(
            codigo=data["codigo"],
            identificacion=data["identificacion"],
            nombre=data["nombre"],
            apellido1=data["apellido1"],
            apellido2=data.get("apellido2", ""),
            telefono_personal=data["telefono_personal"],
            correo_personal=data["correo_personal"],
            telefono_clinica=data["telefono_clinica"],
            correo_clinica=data["correo_clinica"],
            especialidades=data.get("especialidades", []),
            activo=data.get("activo", True)
        )
