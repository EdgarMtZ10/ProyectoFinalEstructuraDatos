"""Clase Factura de la clínica.

Representa el encabezado de una factura generada al cobrar una cita.
El detalle está en la clase DetalleFactura.
Corresponde a la tabla Facturas en SQL
"""

from Entidades.constantes import ESTADOS_FACTURA, ESTADO_FACTURA_PENDIENTE, PORCENTAJE_IVA


class Factura:
    """Representa el encabezado de una factura: subtotal, impuesto, total y estado"""

    def __init__(self, id_factura, id_cita, identificacion_paciente,
                 subtotal=0.0, estado=ESTADO_FACTURA_PENDIENTE, metodo_pago=None):
        """Crea una factura. El impuesto y el total se calculan a partir del subtotal"""
        if not isinstance(subtotal, (int, float)) or subtotal < 0:
            raise ValueError("El subtotal debe ser un número mayor o igual a 0.")
        if estado not in ESTADOS_FACTURA:
            raise ValueError(f"Estado inválido. Debe ser uno de: {ESTADOS_FACTURA}.")

        self.id_factura = id_factura
        self.id_cita = id_cita
        self.identificacion_paciente = identificacion_paciente
        self.subtotal = subtotal
        self.estado = estado
        self.metodo_pago = metodo_pago

    @property
    def impuesto(self) -> float:
        """Calcula el IVA a partir del subtotal """
        return round(self.subtotal * (PORCENTAJE_IVA / 100), 2)

    @property
    def total(self) -> float:
        """Calcula el total a pagar: subtotal + impuesto"""
        return round(self.subtotal + self.impuesto, 2)

    def agregar_monto(self, monto_linea: float):
        """Suma el monto de una línea de servicio al subtotal de la factura
        (se llama una vez por cada DetalleFactura que se agregue)"""
        if not isinstance(monto_linea, (int, float)) or monto_linea < 0:
            raise ValueError("El monto de la línea debe ser un número mayor o igual a 0.")
        self.subtotal = round(self.subtotal + monto_linea, 2)

    def marcar_pagada(self, metodo_pago: str):
        """Marca la factura como pagada y registra el método de pago"""
        if not metodo_pago or not metodo_pago.strip():
            raise ValueError("Debe indicar el método de pago.")
        self.estado = "Pagada"
        self.metodo_pago = metodo_pago

    def marcar_anulada(self):
        """Anula la factura. Una factura anulada ya no se puede pagar"""
        if self.estado == "Pagada":
            raise ValueError("No se puede anular una factura que ya fue pagada.")
        self.estado = "Anulada"

    def to_dict(self) -> dict:
        """Convierte la factura a diccionario, incluyendo los montos calculados"""
        return {
            "id_factura": self.id_factura,
            "id_cita": self.id_cita,
            "identificacion_paciente": self.identificacion_paciente,
            "subtotal": self.subtotal,
            "impuesto": self.impuesto,
            "total": self.total,
            "estado": self.estado,
            "metodo_pago": self.metodo_pago
        }

    @classmethod
    def from_dict(cls, data):
        """Crea una Factura a partir de un diccionario"""
        return cls(
            id_factura=data["id_factura"],
            id_cita=data["id_cita"],
            identificacion_paciente=data["identificacion_paciente"],
            subtotal=data.get("subtotal", 0.0),
            estado=data.get("estado", ESTADO_FACTURA_PENDIENTE),
            metodo_pago=data.get("metodo_pago")
        )

    def __str__(self) -> str:
        return (f"Factura [{self.id_factura}] | Cita: {self.id_cita} | "
                f"Subtotal: ₡{self.subtotal:,.2f} | IVA: ₡{self.impuesto:,.2f} | "
                f"Total: ₡{self.total:,.2f} | {self.estado}")