"""Clase DetalleFactura de la clínica.

Representa una línea de una factura: un servicio específico, su cantidad
y su subtotal de línea. Una factura puede tener varias líneas (varios servicios
cobrados en la misma cita).
Corresponde a la tabla DetalleFactura en SQL
"""


class DetalleFactura:
    """Representa una línea de servicio dentro de una factura"""

    def __init__(self, id_detalle, id_factura, id_servicio, cantidad, precio_unitario):
        """Crea una línea de detalle, calculando el subtotal de la línea automáticamente"""
        if not isinstance(cantidad, int) or cantidad <= 0:
            raise ValueError("La cantidad debe ser un entero mayor a 0.")
        if not isinstance(precio_unitario, (int, float)) or precio_unitario < 0:
            raise ValueError("El precio unitario debe ser un número mayor o igual a 0.")

        self.id_detalle = id_detalle
        self.id_factura = id_factura
        self.id_servicio = id_servicio
        self.cantidad = cantidad
        self.precio_unitario = precio_unitario

    @property
    def subtotal_linea(self) -> float:
        """Calcula el subtotal de esta línea (cantidad * precio unitario).
        Al igual que en Factura, se deriva en vez de guardarse aparte."""
        return round(self.cantidad * self.precio_unitario, 2)

    def to_dict(self) -> dict:
        """Convierte la línea a diccionario"""
        return {
            "id_detalle": self.id_detalle,
            "id_factura": self.id_factura,
            "id_servicio": self.id_servicio,
            "cantidad": self.cantidad,
            "precio_unitario": self.precio_unitario,
            "subtotal_linea": self.subtotal_linea
        }

    @classmethod
    def from_dict(cls, data):
        """Crea un DetalleFactura a partir de un diccionario (por ejemplo, una fila de SQL Server)"""
        return cls(
            id_detalle=data["id_detalle"],
            id_factura=data["id_factura"],
            id_servicio=data["id_servicio"],
            cantidad=data["cantidad"],
            precio_unitario=data["precio_unitario"]
        )

    def __str__(self) -> str:
        return (f"Detalle [{self.id_detalle}] | Servicio: {self.id_servicio} | "
                f"Cant: {self.cantidad} x ₡{self.precio_unitario:,.2f} = "
                f"₡{self.subtotal_linea:,.2f}")