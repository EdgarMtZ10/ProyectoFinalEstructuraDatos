"""Clase base Persona del dominio de la clínica"""


def _validar_no_vacio(valor, nombre_campo):
    """Valida que el campo no esté vacío"""
    if not valor.strip():
        raise ValueError(f"El campo '{nombre_campo}' no puede estar vacío.")


def _validar_correo(correo):
    """Valida que el correo tenga @ y un punto después"""
    if "@" not in correo:
        raise ValueError("El correo debe contener '@'.")
    parte_dominio = correo.split("@")[1]
    if "." not in parte_dominio:
        raise ValueError("El correo debe contener un '.' después del '@'.")


def _validar_telefono(telefono):
    """Valida que el teléfono tenga exactamente 8 dígitos numéricos"""
    if not telefono.isdigit() or len(telefono) != 8:
        raise ValueError("El teléfono debe tener exactamente 8 dígitos numéricos.")


class Persona:
    """Representa a una persona con datos de contacto básicos"""

    def __init__(self, identificacion, nombre, apellido1, apellido2, telefono, correo):
        """Crea una persona validando sus datos"""
        _validar_no_vacio(identificacion, "identificacion")
        _validar_no_vacio(nombre, "nombre")
        _validar_no_vacio(apellido1, "apellido1")
        _validar_correo(correo)
        _validar_telefono(telefono)

        self.identificacion = identificacion.strip()
        self.nombre = nombre.strip()
        self.apellido1 = apellido1.strip()
        self.apellido2 = apellido2.strip()
        self.telefono = telefono.strip()
        self.correo = correo.strip()

    def obtener_nombre_completo(self) -> str:
        """Retorna el nombre completo"""
        return f"{self.nombre} {self.apellido1} {self.apellido2}"

    def __str__(self) -> str:
        return f"{self.obtener_nombre_completo()} | ID: {self.identificacion} | Tel: {self.telefono} | Correo: {self.correo}"
