"""Clase Paciente del dominio de la clínica"""

from Entidades.persona import Persona, _validar_no_vacio


class Paciente(Persona):
    """Representa a un paciente de la clínica"""

    def __init__(self, identificacion, nacionalidad, nombre, apellido1,
                 apellido2, telefono, correo, padecimientos=None, tratamientos=None,
                 activo=True):
        """Crea un paciente validando sus datos"""
        super().__init__(identificacion, nombre, apellido1, apellido2, telefono, correo)
        _validar_no_vacio(nacionalidad, "nacionalidad")

        self.nacionalidad = nacionalidad.strip()
        self.padecimientos = padecimientos if padecimientos is not None else []
        self.tratamientos = tratamientos if tratamientos is not None else []
        # activo=False significa que el paciente fue eliminado (borrado lógico)
        self.activo = activo

    def agregar_padecimiento(self, padecimiento):
        """Agrega un padecimiento a la lista del paciente"""
        self.padecimientos.append(padecimiento)

    def agregar_tratamiento(self, tratamiento):
        """Agrega un tratamiento a la lista del paciente"""
        self.tratamientos.append(tratamiento)

    def mostrar_datos(self) -> str:
        """Retorna los datos del paciente en formato legible"""
        padecimientos = ", ".join(self.padecimientos) if self.padecimientos else "Ninguno"
        tratamientos = ", ".join(self.tratamientos) if self.tratamientos else "Ninguno"
        return (
            f"Paciente: {self.obtener_nombre_completo()}\n"
            f"  ID: {self.identificacion}\n"
            f"  Nacionalidad: {self.nacionalidad}\n"
            f"  Teléfono: {self.telefono}\n"
            f"  Correo: {self.correo}\n"
            f"  Padecimientos: {padecimientos}\n"
            f"  Tratamientos: {tratamientos}"
        )

    def to_dict(self) -> dict:
        """Convierte el paciente a diccionario para guardar en JSON"""
        return {
            "identificacion": self.identificacion,
            "nacionalidad": self.nacionalidad,
            "nombre": self.nombre,
            "apellido1": self.apellido1,
            "apellido2": self.apellido2,
            "telefono": self.telefono,
            "correo": self.correo,
            "padecimientos": self.padecimientos,
            "tratamientos": self.tratamientos,
            "activo": self.activo
        }

    @classmethod
    def from_dict(cls, data):
        """Crea un Paciente a partir de un diccionario leído del JSON"""
        return cls(
            identificacion=data["identificacion"],
            nacionalidad=data["nacionalidad"],
            nombre=data["nombre"],
            apellido1=data["apellido1"],
            apellido2=data.get("apellido2", ""),
            telefono=data["telefono"],
            correo=data["correo"],
            padecimientos=data.get("padecimientos", []),
            tratamientos=data.get("tratamientos", []),
            activo=data.get("activo", True)
        )
