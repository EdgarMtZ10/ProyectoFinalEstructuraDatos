PROYECTO CLINICA SALUD Y BIENESTAR
==================================

Como ejecutar
-------------

1. Bases de datos: MongoDB y SQL Server deben estar corriendo.

2. Cargar los datos:

   python cargar_datos_demo.py

   Borra todo y carga el juego de datos completo de la demostracion.
   (Para cargar solo los datos iniciales desde los JSON: python cargar_datos_mongo.py
    y el script Datos/sql/script.sql en SQL Server.)

3. Servidor de Python (socket, siempre primero):

   python ServidorAPI.py

4. Proyecto web (en otra terminal):

   cd ProyectoClinicaWeb
   dotnet run

   Queda en http://localhost:5260

La aplicacion de consola es aparte y se ejecuta con: python Principal.py


Cuentas de la demostracion
--------------------------

Todas usan la contrasena: demo123

  Empleados
    admin, admin2          Administrador
    recepcion, recepcion2, recepcion3   Recepcionista
    dr.ramirez, dr.quesada, dr.mora,
    dr.nunez, dr.fonseca, dr.castro     Medico
    recepcion.old          INACTIVO - no puede ingresar

  Clientes
    El usuario es la identificacion del paciente. Por ejemplo:
      102340567   Maria Jimenez Solis
      118450023   Roberto Vargas Lopez
      205340112   Ana Rodriguez Castro
      119260680   Emanuel Torres Nunez
      401230456   Sofia Herrera Blanco
    Cada cliente tiene entre 16 y 18 citas, con completadas, reservadas y
    canceladas, y facturas pagadas y pendientes.

    INACTIVOS (no pueden ingresar): 208990334, 114560889, 302780991


Que hay cargado
---------------

  MongoDB
    12 especialidades  (2 inactivas)
    14 medicos         (12 activos, 2 inactivos)
    30 pacientes       (27 activos, 3 inactivos)
    42 usuarios        (4 inactivos)
    2880 horarios      6 semanas: 2 pasadas, la actual y 3 siguientes
    datos de la clinica

  SQL Server
    12 servicios       (2 descontinuados)
    470 citas          260 completadas, 170 reservadas, 40 canceladas
    245 facturas       164 pagadas (Efectivo, Tarjeta y Sinpe) y 81 pendientes


Que se puede mostrar con estos datos
------------------------------------

  - Los tres roles de empleado y los clientes, cada uno con su menu.
  - Cuentas inactivas que no pueden ingresar.
  - Medicos inactivos (M013, M014) que no aparecen al agendar.
  - Especialidades inactivas y servicios descontinuados.
  - Cinco medicos comparten Medicina General: al buscar por esa especialidad
    hay que elegir entre varios, como pide el enunciado.
  - Agendas semanales con citas asignadas y espacios libres, con los datos
    del paciente en cada cita.
  - Citas en los tres estados y facturas pagadas y pendientes.
  - Solo se pueden cobrar las citas del dia de hoy: el juego de datos deja 14
    citas con la fecha actual, 4 ya cobradas y 10 sin cobrar, para hacerlo en
    vivo. En las citas de otros dias el boton Cobrar aparece desactivado.
  - Una cita ya cobrada no se puede volver a cobrar, y una sin cobrar no deja
    abrir la factura: el boton que no aplica queda desactivado.
  - Hay citas para el dia siguiente: al intentar cancelarlas el sistema avisa
    que faltan menos de 2 dias de anticipacion.
  - Navegacion de la agenda hacia semanas anteriores y siguientes.
