"""Servidor de sockets que expone la API de la clínica.

Escucha conexiones y atiende cada una en un hilo aparte, para que varios
clientes (por ejemplo el ProyectoClinicaWeb) puedan consultar al mismo tiempo.
"""

import os
import socket
import threading

from API.protocolo import (
    recibir_mensaje, enviar_respuesta, leer_peticion, respuesta_error
)
from API.controlador import atender

# Datos del servidor (se pueden cambiar con variables de entorno)
HOST = os.environ.get("API_HOST", "localhost")
PUERTO = int(os.environ.get("API_PUERTO", "8000"))

# Cantidad de conexiones que pueden quedar en espera
MAX_EN_ESPERA = 10


def atender_cliente(conexion, direccion) -> None:
    """Atiende una conexión: lee la petición, ejecuta la acción y responde.
    Esta función es la que corre dentro de cada hilo."""
    nombre_hilo = threading.current_thread().name
    print(f"[{nombre_hilo}] Conexión establecida desde {direccion}")

    try:
        texto = recibir_mensaje(conexion)

        try:
            accion, datos = leer_peticion(texto)
        except ValueError as error:
            enviar_respuesta(conexion, respuesta_error(str(error)))
            return

        print(f"[{nombre_hilo}] Acción solicitada: {accion}")
        respuesta = atender(accion, datos)
        enviar_respuesta(conexion, respuesta)

    except Exception as error:
        # Si algo falla se avisa al cliente, pero el servidor sigue de pie
        print(f"[{nombre_hilo}] Error: {error}")
        try:
            enviar_respuesta(conexion, respuesta_error(f"Error interno: {error}"))
        except OSError:
            pass

    finally:
        conexion.close()
        print(f"[{nombre_hilo}] Conexión cerrada con {direccion}")


def iniciar(host: str = HOST, puerto: int = PUERTO) -> None:
    """Levanta el servidor y queda escuchando conexiones hasta que se detenga"""
    sock_servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Permite reusar el puerto si el servidor se reinicia
    sock_servidor.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock_servidor.bind((host, puerto))
    sock_servidor.listen(MAX_EN_ESPERA)

    print(f"Servidor de la clínica escuchando en {host}:{puerto}")
    print("Presione Ctrl+C para detenerlo.")

    try:
        while True:
            conexion, direccion = sock_servidor.accept()

            # Un hilo por cliente: mientras uno se atiende, se pueden aceptar otros
            hilo = threading.Thread(
                target=atender_cliente,
                args=(conexion, direccion),
                daemon=True
            )
            hilo.start()

    except KeyboardInterrupt:
        print("\nDeteniendo el servidor...")

    finally:
        sock_servidor.close()
        print("Servidor detenido.")
