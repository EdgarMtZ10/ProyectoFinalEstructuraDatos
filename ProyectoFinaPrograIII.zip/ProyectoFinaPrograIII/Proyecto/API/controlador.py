"""Controlador de acciones de la API.

Traduce cada acción recibida por el socket a una llamada a la capa BL
y devuelve el resultado ya convertido a diccionarios listos para JSON.

Sobre los hilos:
Cada petición se atiende en su propio hilo y crea sus propios servicios,
así que ninguno comparte estado con otro. Las acciones que escriben datos
y las que usan SQL Server se ejecutan dentro de un candado (Lock) porque
la conexión de pyodbc es una sola y porque al guardar en MongoDB se
reemplaza la colección completa. Las consultas que solo leen de MongoDB
no usan el candado, de modo que sí pueden atenderse al mismo tiempo.
"""

import threading

from BL.servicio_especialidades import ServicioEspecialidades
from BL.servicio_medicos import ServicioMedicos
from BL.servicio_horarios import ServicioHorarios
from BL.servicio_pacientes import ServicioPacientes
from BL.servicio_citas import ServicioCitas
from BL.servicio_busquedas import ServicioBusquedas
from BL.servicio_facturacion import ServicioFacturacion
from API.protocolo import respuesta_ok, respuesta_error
from BL.servicio_usuario import ServicioUsuarios
from BL.servicio_servicios import ServicioServicios
from BL.servicio_clinica import ServicioClinica

# Candado que serializa las operaciones de escritura y las de SQL Server
_candado = threading.Lock()


class _Servicios:
    """Arma los servicios de BL que necesita una petición.
    Los de MongoDB se crean siempre; los de SQL Server solo si se piden."""

    def __init__(self):
        """Crea los servicios que trabajan sobre MongoDB"""
        self.especialidades = ServicioEspecialidades()
        self.medicos = ServicioMedicos(self.especialidades)
        self.horarios = ServicioHorarios(self.medicos)
        self.pacientes = ServicioPacientes()
        self.busquedas = ServicioBusquedas(self.medicos, self.especialidades, self.horarios)
        self.usuarios = ServicioUsuarios()
        self.clinica = ServicioClinica()
        self._citas = None
        self._servicios = None
        self._facturacion = None

    @property
    def citas(self):
        """Crea el servicio de citas la primera vez que se usa (lee de SQL Server)"""
        if self._citas is None:
            self._citas = ServicioCitas(self.horarios, self.pacientes, self.medicos)
        return self._citas

    @property
    def servicios(self):
        """Crea el servicio del catálogo la primera vez que se usa (lee de SQL Server)"""
        if self._servicios is None:
            self._servicios = ServicioServicios()
        return self._servicios

    @property
    def facturacion(self):
        """Crea el servicio de facturación la primera vez que se usa"""
        if self._facturacion is None:
            self._facturacion = ServicioFacturacion(self.citas)
        return self._facturacion


def _lista_a_dicts(elementos) -> list:
    """Convierte una lista de entidades a una lista de diccionarios"""
    return [e.to_dict() for e in elementos]


def _usuario_publico(usuario) -> dict:
    """Convierte un usuario a diccionario SIN la contraseña"""
    datos = usuario.to_dict()
    datos.pop("contrasena", None)
    return datos


def _resultado(tupla) -> dict:
    """Convierte el (exito, mensaje, entidad) que devuelven los servicios
    en una respuesta de la API"""
    exito, mensaje, entidad = tupla
    if not exito:
        return respuesta_error(mensaje)
    datos = entidad.to_dict() if hasattr(entidad, "to_dict") else entidad
    return respuesta_ok(datos, mensaje)


# ---------------------------------------------------------------------------
# Acciones de consulta (solo MongoDB, se pueden atender en paralelo)
# ---------------------------------------------------------------------------

def _ping(datos):
    """Comprueba que el servidor esté respondiendo"""
    return respuesta_ok("pong", "Servidor activo.")


def _listar_especialidades(datos):
    """Retorna todas las especialidades"""
    servicios = _Servicios()
    incluir = datos.get("incluir_inactivos", False)
    return respuesta_ok(_lista_a_dicts(servicios.especialidades.listar(incluir)))


def _listar_medicos(datos):
    """Retorna todos los médicos"""
    servicios = _Servicios()
    incluir = datos.get("incluir_inactivos", False)
    return respuesta_ok(_lista_a_dicts(servicios.medicos.listar(incluir)))


def _obtener_medico(datos):
    """Retorna un médico por su código"""
    servicios = _Servicios()
    medico = servicios.medicos.buscar_por_codigo(datos.get("codigo", ""))
    if medico is None:
        return respuesta_error("No se encontró el médico indicado.")
    return respuesta_ok(medico.to_dict())


def _buscar_medicos(datos):
    """Busca médicos por nombre, apellido, especialidades y/o disponibilidad"""
    servicios = _Servicios()
    resultados = servicios.busquedas.buscar_medicos(
        nombre=datos.get("nombre"),
        apellido=datos.get("apellido"),
        identificacion=datos.get("identificacion"),
        ids_especialidad=datos.get("ids_especialidad"),
        fecha_disponible=datos.get("fecha_disponible")
    )
    return respuesta_ok(resultados)


def _listar_pacientes(datos):
    """Retorna todos los pacientes"""
    servicios = _Servicios()
    incluir = datos.get("incluir_inactivos", False)
    return respuesta_ok(_lista_a_dicts(servicios.pacientes.listar(incluir)))


def _obtener_paciente(datos):
    """Retorna un paciente por su identificación"""
    servicios = _Servicios()
    paciente = servicios.pacientes.buscar_por_identificacion(datos.get("identificacion", ""))
    if paciente is None:
        return respuesta_error("No se encontró el paciente indicado.")
    return respuesta_ok(paciente.to_dict())


def _listar_horarios(datos):
    """Retorna los horarios de un médico, opcionalmente filtrados por fecha"""
    servicios = _Servicios()
    slots = servicios.horarios.slots_de_medico(
        datos.get("codigo_medico", ""), datos.get("fecha")
    )
    return respuesta_ok(_lista_a_dicts(slots))


def _horarios_disponibles(datos):
    """Retorna los horarios disponibles de un médico"""
    servicios = _Servicios()
    slots = servicios.horarios.slots_disponibles(
        datos.get("codigo_medico", ""), datos.get("fecha")
    )
    return respuesta_ok(_lista_a_dicts(slots))


# ---------------------------------------------------------------------------
# Acciones de escritura sobre MongoDB
# ---------------------------------------------------------------------------

def _registrar_paciente(datos):
    """Registra un paciente nuevo y le crea su cuenta de cliente.

    El nombre de usuario de la cuenta es la identificacion del paciente, y la
    contrasena viene en los datos. Se guarda hasheada (lo hace el servicio de
    usuarios), nunca en texto plano.
    """
    servicios = _Servicios()

    identificacion = datos.get("identificacion", "")
    contrasena = datos.get("contrasena", "")

    if not contrasena or not contrasena.strip():
        return respuesta_error("La contrasena es obligatoria para crear la cuenta.")

    # Se revisa el nombre de usuario ANTES de crear al paciente, para no
    # dejarlo registrado sin poder entrar al sistema
    if servicios.usuarios.obtener(identificacion) is not None:
        return respuesta_error(f"Ya existe una cuenta registrada con la identificacion '{identificacion}'.")

    exito, mensaje, paciente = servicios.pacientes.registrar(datos)
    if not exito:
        return respuesta_error(mensaje)

    datos_usuario = {
        "usuario": identificacion,
        "contrasena": contrasena,
        "rol": "Cliente",
        "referencia": identificacion
    }
    exito_cuenta, mensaje_cuenta, _ = servicios.usuarios.registrar(datos_usuario)

    if not exito_cuenta:
        # Si la cuenta no se pudo crear, se da de baja al paciente para no
        # dejarlo activo pero sin forma de ingresar
        servicios.pacientes.eliminar(identificacion)
        return respuesta_error(mensaje_cuenta)

    return respuesta_ok(paciente.to_dict(), "Paciente y cuenta creados correctamente.")

def _login_cliente(datos):
    """Valida el login de un cliente"""
    servicios = _Servicios()
    exito, mensaje, usuario = servicios.usuarios.login_cliente(
        datos.get("usuario", ""), datos.get("contrasena", "")
    )
    if not exito:
        return respuesta_error(mensaje)
    return respuesta_ok(_usuario_publico(usuario), mensaje)


def _login_empleado(datos):
    """Valida el login de un empleado"""
    servicios = _Servicios()
    exito, mensaje, usuario = servicios.usuarios.login_empleado(
        datos.get("usuario", ""), datos.get("contrasena", "")
    )
    if not exito:
        return respuesta_error(mensaje)
    return respuesta_ok(_usuario_publico(usuario), mensaje)


def _modificar_paciente(datos):
    """Modifica los datos de un paciente"""
    servicios = _Servicios()
    identificacion = datos.get("identificacion", "")
    cambios = datos.get("cambios", {})
    return _resultado(servicios.pacientes.modificar(identificacion, cambios))


def _registrar_medico(datos):
    """Registra un médico nuevo"""
    servicios = _Servicios()
    return _resultado(servicios.medicos.registrar(datos))


def _modificar_medico(datos):
    """Modifica los datos de un médico"""
    servicios = _Servicios()
    codigo = datos.get("codigo", "")
    cambios = datos.get("cambios", {})
    return _resultado(servicios.medicos.modificar(codigo, cambios))


def _asignar_especialidades(datos):
    """Asigna especialidades a un médico"""
    servicios = _Servicios()
    codigo = datos.get("codigo", "")
    ids = datos.get("ids_especialidad", [])
    return _resultado(servicios.medicos.asignar_especialidades(codigo, ids))


def _registrar_especialidad(datos):
    """Registra una especialidad nueva"""
    servicios = _Servicios()
    return _resultado(servicios.especialidades.registrar(datos.get("nombre", "")))


def _modificar_especialidad(datos):
    """Cambia el nombre de una especialidad"""
    servicios = _Servicios()
    id_especialidad = datos.get("id_especialidad")
    nombre = datos.get("nombre", "")
    return _resultado(servicios.especialidades.modificar(id_especialidad, nombre))


def _generar_horarios(datos):
    """Genera slots de 30 minutos para un médico en una fecha"""
    servicios = _Servicios()
    exito, mensaje, nuevos = servicios.horarios.generar_disponibilidad(
        datos.get("codigo_medico", ""),
        datos.get("fecha", ""),
        datos.get("hora_inicio", ""),
        datos.get("hora_fin", "")
    )
    if not exito:
        return respuesta_error(mensaje)
    return respuesta_ok(_lista_a_dicts(nuevos), mensaje)


def _marcar_no_disponible(datos):
    """Marca como no disponible un slot o todos los de una fecha"""
    servicios = _Servicios()
    exito, mensaje, afectados = servicios.horarios.marcar_no_disponible(
        datos.get("codigo_medico", ""),
        datos.get("fecha", ""),
        datos.get("hora_inicio")
    )
    if not exito:
        return respuesta_error(mensaje)
    return respuesta_ok({"afectados": afectados}, mensaje)


# ---------------------------------------------------------------------------
# Acciones de citas y facturación (SQL Server)
# ---------------------------------------------------------------------------

def _listar_citas(datos):
    """Retorna citas filtradas por paciente, médico, fecha o estado.
    Sin filtros retorna todas las citas."""
    servicios = _Servicios()
    serv_citas = servicios.citas

    if datos.get("identificacion_paciente"):
        citas = serv_citas.buscar_por_paciente(datos["identificacion_paciente"])
    elif datos.get("codigo_medico"):
        citas = serv_citas.buscar_por_medico(datos["codigo_medico"])
    elif datos.get("fecha"):
        citas = serv_citas.buscar_por_fecha(datos["fecha"])
    elif datos.get("estado"):
        citas = serv_citas.buscar_por_estado(datos["estado"])
    else:
        citas = serv_citas.citas

    return respuesta_ok(_lista_a_dicts(citas))


def _obtener_cita(datos):
    """Retorna una cita por su id"""
    servicios = _Servicios()
    cita = servicios.citas.buscar_por_id(datos.get("id_cita"))
    if cita is None:
        return respuesta_error("No se encontró la cita indicada.")
    return respuesta_ok(cita.to_dict())


def _reservar_cita(datos):
    """Reserva una cita para un paciente en un slot de un médico"""
    servicios = _Servicios()
    return _resultado(servicios.citas.reservar(
        datos.get("identificacion_paciente", ""),
        datos.get("codigo_medico", ""),
        datos.get("id_horario")
    ))


def _cancelar_cita(datos):
    """Cancela una cita y libera su slot"""
    servicios = _Servicios()
    return _resultado(servicios.citas.cancelar(datos.get("id_cita")))


def _reprogramar_cita(datos):
    """Cambia una cita a otro slot del mismo médico"""
    servicios = _Servicios()
    return _resultado(servicios.citas.reprogramar(
        datos.get("id_cita"), datos.get("id_horario")
    ))


def _listar_servicios(datos):
    """Retorna el catálogo de servicios activos"""
    servicios = _Servicios()
    solo_activos = datos.get("solo_activos", False)
    return respuesta_ok(_lista_a_dicts(servicios.servicios.listar(solo_activos)))


def _generar_factura(datos):
    """Genera la factura de una cita a partir de sus líneas de servicio"""
    servicios = _Servicios()
    exito, mensaje, factura, detalles = servicios.facturacion.generar_factura(
        datos.get("id_cita"), datos.get("lineas", [])
    )
    if not exito:
        return respuesta_error(mensaje)
    return respuesta_ok(
        {"factura": factura.to_dict(), "detalles": _lista_a_dicts(detalles)},
        mensaje
    )


def _obtener_factura(datos):
    """Retorna la factura de una cita con sus líneas"""
    servicios = _Servicios()
    factura, detalles = servicios.facturacion.obtener_detalle_para_mostrar(datos.get("id_cita"))
    if factura is None:
        return respuesta_error("Esa cita todavía no tiene factura.")
    return respuesta_ok({
        "factura": factura.to_dict(),
        "detalles": _lista_a_dicts(detalles)
    })


def _registrar_pago(datos):
    """Registra el pago de la factura de una cita"""
    servicios = _Servicios()
    return _resultado(servicios.facturacion.registrar_pago(
        datos.get("id_cita"), datos.get("metodo_pago", "")
    ))


# ---------------------------------------------------------------------------
# Eliminar y reactivar (borrado lógico: se marca inactivo, no se borra)
# ---------------------------------------------------------------------------

def _eliminar_paciente(datos):
    """Elimina (desactiva) un paciente"""
    servicios = _Servicios()
    return _resultado(servicios.pacientes.eliminar(datos.get("identificacion", "")))


def _reactivar_paciente(datos):
    """Reactiva un paciente eliminado"""
    servicios = _Servicios()
    return _resultado(servicios.pacientes.reactivar(datos.get("identificacion", "")))


def _eliminar_medico(datos):
    """Elimina (desactiva) un médico"""
    servicios = _Servicios()
    return _resultado(servicios.medicos.eliminar(datos.get("codigo", "")))


def _reactivar_medico(datos):
    """Reactiva un médico eliminado"""
    servicios = _Servicios()
    return _resultado(servicios.medicos.reactivar(datos.get("codigo", "")))


def _obtener_especialidad(datos):
    """Retorna una especialidad por su id"""
    servicios = _Servicios()
    especialidad = servicios.especialidades.obtener(datos.get("id_especialidad"))
    if especialidad is None:
        return respuesta_error("No se encontró la especialidad indicada.")
    return respuesta_ok(especialidad.to_dict())


def _eliminar_especialidad(datos):
    """Elimina (desactiva) una especialidad"""
    servicios = _Servicios()
    return _resultado(servicios.especialidades.eliminar(datos.get("id_especialidad")))


def _reactivar_especialidad(datos):
    """Reactiva una especialidad eliminada"""
    servicios = _Servicios()
    return _resultado(servicios.especialidades.reactivar(datos.get("id_especialidad")))


def _obtener_horario(datos):
    """Retorna un slot de horario por su id"""
    servicios = _Servicios()
    slot = servicios.horarios.buscar_slot(datos.get("id_horario"))
    if slot is None:
        return respuesta_error("No se encontró el slot indicado.")
    return respuesta_ok(slot.to_dict())


def _eliminar_horario(datos):
    """Elimina (desactiva) un slot de horario que no esté reservado"""
    servicios = _Servicios()
    return _resultado(servicios.horarios.eliminar_slot(datos.get("id_horario")))


# ---------------------------------------------------------------------------
# Catálogo de servicios (SQL Server)
# ---------------------------------------------------------------------------

def _obtener_servicio(datos):
    """Retorna un servicio del catálogo por su id"""
    servicios = _Servicios()
    servicio = servicios.servicios.obtener(datos.get("id_servicio"))
    if servicio is None:
        return respuesta_error("No se encontró el servicio indicado.")
    return respuesta_ok(servicio.to_dict())


def _registrar_servicio(datos):
    """Registra un servicio nuevo en el catálogo"""
    servicios = _Servicios()
    return _resultado(servicios.servicios.registrar(datos))


def _modificar_servicio(datos):
    """Modifica un servicio del catálogo"""
    servicios = _Servicios()
    return _resultado(servicios.servicios.modificar(
        datos.get("id_servicio"), datos.get("cambios", {})
    ))


def _eliminar_servicio(datos):
    """Elimina (desactiva) un servicio del catálogo"""
    servicios = _Servicios()
    return _resultado(servicios.servicios.eliminar(datos.get("id_servicio")))


def _reactivar_servicio(datos):
    """Reactiva un servicio eliminado"""
    servicios = _Servicios()
    return _resultado(servicios.servicios.reactivar(datos.get("id_servicio")))


def _anular_factura(datos):
    """Anula la factura de una cita"""
    servicios = _Servicios()
    return _resultado(servicios.facturacion.anular_factura(datos.get("id_cita")))


# ---------------------------------------------------------------------------
# Usuarios (MongoDB). Las respuestas nunca incluyen la contraseña.
# ---------------------------------------------------------------------------

def _listar_usuarios(datos):
    """Retorna los usuarios del sistema"""
    servicios = _Servicios()
    incluir = datos.get("incluir_inactivos", False)
    return respuesta_ok([_usuario_publico(u) for u in servicios.usuarios.listar(incluir)])


def _obtener_usuario(datos):
    """Retorna un usuario por su nombre de usuario"""
    servicios = _Servicios()
    usuario = servicios.usuarios.obtener(datos.get("usuario", ""))
    if usuario is None:
        return respuesta_error("No se encontró el usuario indicado.")
    return respuesta_ok(_usuario_publico(usuario))


def _registrar_usuario(datos):
    """Registra una cuenta nueva"""
    servicios = _Servicios()
    exito, mensaje, usuario = servicios.usuarios.registrar(datos)
    if not exito:
        return respuesta_error(mensaje)
    return respuesta_ok(_usuario_publico(usuario), mensaje)


def _modificar_usuario(datos):
    """Modifica la contraseña, el rol o la referencia de una cuenta"""
    servicios = _Servicios()
    exito, mensaje, usuario = servicios.usuarios.modificar(
        datos.get("usuario", ""), datos.get("cambios", {})
    )
    if not exito:
        return respuesta_error(mensaje)
    return respuesta_ok(_usuario_publico(usuario), mensaje)


def _eliminar_usuario(datos):
    """Elimina (desactiva) una cuenta"""
    servicios = _Servicios()
    exito, mensaje, usuario = servicios.usuarios.eliminar(datos.get("usuario", ""))
    if not exito:
        return respuesta_error(mensaje)
    return respuesta_ok(_usuario_publico(usuario), mensaje)


def _reactivar_usuario(datos):
    """Reactiva una cuenta eliminada"""
    servicios = _Servicios()
    exito, mensaje, usuario = servicios.usuarios.reactivar(datos.get("usuario", ""))
    if not exito:
        return respuesta_error(mensaje)
    return respuesta_ok(_usuario_publico(usuario), mensaje)


def _cambiar_contrasena(datos):
    """Cambia la contraseña de una cuenta validando la actual"""
    servicios = _Servicios()
    exito, mensaje, usuario = servicios.usuarios.cambiar_contrasena(
        datos.get("usuario", ""),
        datos.get("contrasena_actual", ""),
        datos.get("contrasena_nueva", "")
    )
    if not exito:
        return respuesta_error(mensaje)
    return respuesta_ok(_usuario_publico(usuario), mensaje)


# ---------------------------------------------------------------------------
# Datos de la clínica (MongoDB)
# ---------------------------------------------------------------------------

def _obtener_clinica(datos):
    """Retorna los datos generales de la clínica"""
    servicios = _Servicios()
    clinica = servicios.clinica.obtener()
    if clinica is None:
        return respuesta_error("Todavía no se han registrado los datos de la clínica.")
    return respuesta_ok(clinica.to_dict())


def _registrar_clinica(datos):
    """Registra los datos generales de la clínica"""
    servicios = _Servicios()
    return _resultado(servicios.clinica.registrar(datos))


def _modificar_clinica(datos):
    """Modifica los datos generales de la clínica.
    Si todavía no hay datos registrados, los registra por primera vez."""
    servicios = _Servicios()
    cambios = datos.get("cambios", datos)

    if servicios.clinica.obtener() is None:
        return _resultado(servicios.clinica.registrar(cambios))

    return _resultado(servicios.clinica.modificar(cambios))


def _eliminar_clinica(datos):
    """Borra los datos generales de la clínica"""
    servicios = _Servicios()
    return _resultado(servicios.clinica.eliminar())


# ---------------------------------------------------------------------------
# Catálogo de acciones
# necesita_candado indica si la acción debe ejecutarse de forma exclusiva
# ---------------------------------------------------------------------------

ACCIONES = {
    # Consultas de MongoDB (se pueden atender en paralelo)
    "ping":                   (_ping, False),
    "listar_especialidades":  (_listar_especialidades, False),
    "listar_medicos":         (_listar_medicos, False),
    "obtener_medico":         (_obtener_medico, False),
    "buscar_medicos":         (_buscar_medicos, False),
    "listar_pacientes":       (_listar_pacientes, False),
    "obtener_paciente":       (_obtener_paciente, False),
    "listar_horarios":        (_listar_horarios, False),
    "horarios_disponibles":   (_horarios_disponibles, False),

    # Escrituras en MongoDB
    "login_cliente":          (_login_cliente, False),
    "login_empleado":         (_login_empleado, False),
    "registrar_paciente":     (_registrar_paciente, True),
    "modificar_paciente":     (_modificar_paciente, True),
    "registrar_medico":       (_registrar_medico, True),
    "modificar_medico":       (_modificar_medico, True),
    "asignar_especialidades": (_asignar_especialidades, True),
    "registrar_especialidad": (_registrar_especialidad, True),
    "modificar_especialidad": (_modificar_especialidad, True),
    "generar_horarios":       (_generar_horarios, True),
    "marcar_no_disponible":   (_marcar_no_disponible, True),

    # Consultas puntuales que faltaban
    "obtener_especialidad":   (_obtener_especialidad, False),
    "obtener_horario":        (_obtener_horario, False),

    # Eliminar y reactivar (borrado lógico)
    "eliminar_paciente":      (_eliminar_paciente, True),
    "reactivar_paciente":     (_reactivar_paciente, True),
    "eliminar_medico":        (_eliminar_medico, True),
    "reactivar_medico":       (_reactivar_medico, True),
    "eliminar_especialidad":  (_eliminar_especialidad, True),
    "reactivar_especialidad": (_reactivar_especialidad, True),
    "eliminar_horario":       (_eliminar_horario, True),

    # Usuarios
    "listar_usuarios":        (_listar_usuarios, False),
    "obtener_usuario":        (_obtener_usuario, False),
    "registrar_usuario":      (_registrar_usuario, True),
    "modificar_usuario":      (_modificar_usuario, True),
    "eliminar_usuario":       (_eliminar_usuario, True),
    "reactivar_usuario":      (_reactivar_usuario, True),
    "cambiar_contrasena":     (_cambiar_contrasena, True),

    # Datos de la clínica
    "obtener_clinica":        (_obtener_clinica, False),
    "registrar_clinica":      (_registrar_clinica, True),
    "modificar_clinica":      (_modificar_clinica, True),
    "eliminar_clinica":       (_eliminar_clinica, True),

    # Citas y facturación (SQL Server)
    "listar_citas":           (_listar_citas, True),
    "obtener_cita":           (_obtener_cita, True),
    "reservar_cita":          (_reservar_cita, True),
    "cancelar_cita":          (_cancelar_cita, True),
    "reprogramar_cita":       (_reprogramar_cita, True),
    "listar_servicios":       (_listar_servicios, True),
    "obtener_servicio":       (_obtener_servicio, True),
    "registrar_servicio":     (_registrar_servicio, True),
    "modificar_servicio":     (_modificar_servicio, True),
    "eliminar_servicio":      (_eliminar_servicio, True),
    "reactivar_servicio":     (_reactivar_servicio, True),
    "generar_factura":        (_generar_factura, True),
    "obtener_factura":        (_obtener_factura, True),
    "registrar_pago":         (_registrar_pago, True),
    "anular_factura":         (_anular_factura, True),
}


def atender(accion: str, datos: dict) -> dict:
    """Ejecuta la acción solicitada y retorna la respuesta de la API"""
    if accion not in ACCIONES:
        return respuesta_error(f"La acción '{accion}' no existe.")

    funcion, necesita_candado = ACCIONES[accion]

    try:
        if necesita_candado:
            with _candado:
                return funcion(datos)
        return funcion(datos)
    except Exception as error:
        # Ninguna falla de una petición debe tumbar el servidor
        return respuesta_error(f"Error al procesar '{accion}': {error}")
