"""Protocolo de mensajes de la API por sockets.

Cada petición y cada respuesta es un objeto JSON en una sola línea,
terminado con un salto de línea ("\\n"), codificado en UTF-8.

Petición:
    {"accion": "listar_medicos", "datos": {}}

Respuesta correcta:
    {"ok": true, "mensaje": "", "datos": [...]}

Respuesta con error:
    {"ok": false, "mensaje": "No se encontró el médico.", "datos": null}
"""

import json

# Tamaño de cada pedazo que se lee del socket
TAMANO_BUFFER = 4096

# Fin de mensaje
FIN_DE_LINEA = "\n"


def recibir_mensaje(conexion) -> str:
    """Lee del socket hasta encontrar un salto de línea y retorna el texto recibido.
    Retorna cadena vacía si el cliente cierra la conexión sin enviar nada."""
    partes = []

    while True:
        pedazo = conexion.recv(TAMANO_BUFFER)
        if not pedazo:
            break

        texto = pedazo.decode("utf-8")
        partes.append(texto)

        if FIN_DE_LINEA in texto:
            break

    mensaje = "".join(partes)
    return mensaje.split(FIN_DE_LINEA)[0].strip()


def enviar_respuesta(conexion, respuesta: dict) -> None:
    """Envía un diccionario como JSON por el socket, terminado en salto de línea"""
    texto = json.dumps(respuesta, ensure_ascii=False) + FIN_DE_LINEA
    conexion.sendall(texto.encode("utf-8"))


def leer_peticion(texto: str) -> tuple:
    """Interpreta el texto recibido como una petición JSON.
    Retorna (accion, datos). Lanza ValueError si el mensaje no es válido."""
    if not texto:
        raise ValueError("No se recibió ningún mensaje.")

    try:
        peticion = json.loads(texto)
    except json.JSONDecodeError:
        raise ValueError("El mensaje recibido no es un JSON válido.")

    if not isinstance(peticion, dict):
        raise ValueError("El mensaje debe ser un objeto JSON.")

    accion = peticion.get("accion")
    if not accion:
        raise ValueError("La petición debe incluir el campo 'accion'.")

    datos = peticion.get("datos", {})
    if datos is None:
        datos = {}
    if not isinstance(datos, dict):
        raise ValueError("El campo 'datos' debe ser un objeto JSON.")

    return accion, datos


def respuesta_ok(datos=None, mensaje: str = "") -> dict:
    """Construye una respuesta correcta"""
    return {"ok": True, "mensaje": mensaje, "datos": datos}


def respuesta_error(mensaje: str) -> dict:
    """Construye una respuesta de error"""
    return {"ok": False, "mensaje": mensaje, "datos": None}
