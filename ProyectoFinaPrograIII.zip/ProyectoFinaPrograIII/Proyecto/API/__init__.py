"""Capa de API por sockets del sistema de clínica"""
