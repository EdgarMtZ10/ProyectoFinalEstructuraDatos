"""Menú de gestión de pacientes"""

from UI.utilidades_consola import leer_texto, leer_entero, mostrar_error, mostrar_exito


def ejecutar(servicios):
    """Ejecuta el bucle del menú de pacientes"""
    serv = servicios["pacientes"]
    while True:
        _mostrar_menu()
        opcion = leer_entero("  Opción: ", minimo=0, maximo=2)
        if opcion == 1:
            _registrar(serv)
        elif opcion == 2:
            _modificar(serv)
        elif opcion == 0:
            break


def _mostrar_menu():
    """Imprime las opciones del menú"""
    print("\n" + "-" * 35)
    print("   GESTIÓN DE PACIENTES")
    print("-" * 35)
    print("  1. Registrar paciente")
    print("  2. Modificar paciente")
    print("  0. Volver al menú principal")
    print("-" * 35)


def _registrar(serv):
    """Captura datos y registra un nuevo paciente; permite reintentar ante error"""
    print("\n  -- Registrar Paciente --")
    while True:
        datos = _capturar_datos()
        ok, msg, _ = serv.registrar(datos)
        if ok:
            mostrar_exito(msg)
            break
        mostrar_error(msg)
        if not _confirmar_reintentar():
            break


def _modificar(serv):
    """Busca un paciente y permite modificar sus campos"""
    print("\n  -- Modificar Paciente --")
    identificacion = leer_texto("  Identificación del paciente: ")
    paciente = serv.buscar_por_identificacion(identificacion)
    if paciente is None:
        mostrar_error(f"No se encontró un paciente con identificación '{identificacion}'.")
        return

    print(f"\n  Datos actuales — {paciente.obtener_nombre_completo()}:")
    print(paciente.mostrar_datos())
    print("\n  (Enter para mantener el valor actual)")

    cambios = _capturar_cambios(paciente)
    if not cambios:
        print("  No se realizaron cambios.")
        return

    ok, msg, _ = serv.modificar(identificacion, cambios)
    if ok:
        mostrar_exito(msg)
    else:
        mostrar_error(msg)


def _capturar_datos():
    """Solicita todos los campos de un nuevo paciente"""
    print("  (Deje en blanco los campos opcionales)")
    return {
        "identificacion": leer_texto("  Identificación: "),
        "nombre":         leer_texto("  Nombre: "),
        "apellido1":      leer_texto("  Primer apellido: "),
        "apellido2":      leer_texto("  Segundo apellido (opcional): ", obligatorio=False),
        "telefono":       leer_texto("  Teléfono: "),
        "correo":         leer_texto("  Correo: "),
        "nacionalidad":   leer_texto("  Nacionalidad: "),
        "padecimientos":  _leer_lista("  Padecimientos (separados por coma, Enter = ninguno): "),
        "tratamientos":   _leer_lista("  Tratamientos (separados por coma, Enter = ninguno): "),
    }


def _capturar_cambios(paciente):
    """Solicita los nuevos valores; Enter mantiene el actual"""
    cambios = {}

    valor = input(f"  Nombre [{paciente.nombre}]: ").strip()
    if valor:
        cambios["nombre"] = valor

    valor = input(f"  Primer apellido [{paciente.apellido1}]: ").strip()
    if valor:
        cambios["apellido1"] = valor

    valor = input(f"  Segundo apellido [{paciente.apellido2}]: ").strip()
    if valor:
        cambios["apellido2"] = valor

    valor = input(f"  Teléfono [{paciente.telefono}]: ").strip()
    if valor:
        cambios["telefono"] = valor

    valor = input(f"  Correo [{paciente.correo}]: ").strip()
    if valor:
        cambios["correo"] = valor

    valor = input(f"  Nacionalidad [{paciente.nacionalidad}]: ").strip()
    if valor:
        cambios["nacionalidad"] = valor

    return cambios


def _leer_lista(prompt):
    """Lee valores separados por coma y retorna una lista limpia"""
    entrada = input(f"  {prompt}").strip()
    if not entrada:
        return []
    return [v.strip() for v in entrada.split(",") if v.strip()]


def _confirmar_reintentar():
    """Retorna True si el usuario quiere intentar de nuevo"""
    resp = input("  ¿Desea intentar con datos diferentes? (s/n): ").strip().lower()
    return resp == "s"
