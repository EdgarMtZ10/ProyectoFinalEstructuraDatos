"""Menú de gestión de médicos, especialidades y horarios"""

from UI.utilidades_consola import (
    leer_texto, leer_entero, leer_fecha, leer_hora, mostrar_error, mostrar_exito
)


def ejecutar(servicios):
    """Ejecuta el bucle del menú de médicos / especialidades / horarios"""
    serv_med  = servicios["medicos"]
    serv_esp  = servicios["especialidades"]
    serv_hor  = servicios["horarios"]
    while True:
        _mostrar_menu()
        opcion = leer_entero("  Opción: ", minimo=0, maximo=7)
        if opcion == 1:
            _registrar_medico(serv_med, serv_esp)
        elif opcion == 2:
            _modificar_medico(serv_med)
        elif opcion == 3:
            _registrar_especialidad(serv_esp)
        elif opcion == 4:
            _modificar_especialidad(serv_esp)
        elif opcion == 5:
            _asignar_especialidades(serv_med, serv_esp)
        elif opcion == 6:
            _generar_disponibilidad(serv_hor)
        elif opcion == 7:
            _marcar_no_disponible(serv_hor)
        elif opcion == 0:
            break


def _mostrar_menu():
    """Imprime las opciones del menú"""
    print("\n" + "-" * 45)
    print("   MÉDICOS / ESPECIALIDADES / HORARIOS")
    print("-" * 45)
    print("  1. Registrar médico")
    print("  2. Modificar médico")
    print("  3. Registrar especialidad")
    print("  4. Modificar especialidad")
    print("  5. Asignar especialidades a médico")
    print("  6. Generar disponibilidad (horarios)")
    print("  7. Marcar slot como no disponible")
    print("  0. Volver al menú principal")
    print("-" * 45)


# ── Médicos ──────────────────────────────────────────────

def _registrar_medico(serv_med, serv_esp):
    """Captura datos y registra un nuevo médico; permite reintentar ante error"""
    print("\n  -- Registrar Médico --")
    _listar_especialidades(serv_esp)
    while True:
        datos = _capturar_datos_medico(serv_esp)
        ok, msg, _ = serv_med.registrar(datos)
        if ok:
            mostrar_exito(msg)
            break
        mostrar_error(msg)
        if not _confirmar_reintentar():
            break


def _modificar_medico(serv_med):
    """Busca un médico y permite modificar sus campos"""
    print("\n  -- Modificar Médico --")
    codigo = leer_texto("  Código del médico: ")
    medico = serv_med.buscar_por_codigo(codigo)
    if medico is None:
        mostrar_error(f"No se encontró un médico con código '{codigo}'.")
        return

    print(f"\n  Datos actuales — {medico.obtener_nombre_completo()} ({medico.codigo}):")
    _mostrar_medico(medico)
    print("\n  (Enter para mantener el valor actual)")

    cambios = _capturar_cambios_medico(medico)
    if not cambios:
        print("  No se realizaron cambios.")
        return

    ok, msg, _ = serv_med.modificar(codigo, cambios)
    if ok:
        mostrar_exito(msg)
    else:
        mostrar_error(msg)


# ── Especialidades ────────────────────────────────────────

def _registrar_especialidad(serv_esp):
    """Registra una nueva especialidad"""
    print("\n  -- Registrar Especialidad --")
    while True:
        nombre = leer_texto("  Nombre de la especialidad: ")
        ok, msg, _ = serv_esp.registrar(nombre)
        if ok:
            mostrar_exito(msg)
            break
        mostrar_error(msg)
        if not _confirmar_reintentar():
            break


def _modificar_especialidad(serv_esp):
    """Modifica el nombre de una especialidad"""
    print("\n  -- Modificar Especialidad --")
    _listar_especialidades(serv_esp)
    id_esp = leer_entero("  ID de la especialidad: ", minimo=1)
    nombre = leer_texto("  Nuevo nombre: ")
    ok, msg, _ = serv_esp.modificar(id_esp, nombre)
    if ok:
        mostrar_exito(msg)
    else:
        mostrar_error(msg)


def _asignar_especialidades(serv_med, serv_esp):
    """Agrega especialidades a un médico existente"""
    print("\n  -- Asignar Especialidades --")
    codigo = leer_texto("  Código del médico: ")
    medico = serv_med.buscar_por_codigo(codigo)
    if medico is None:
        mostrar_error(f"No se encontró un médico con código '{codigo}'.")
        return

    _listar_especialidades(serv_esp)
    ids = _leer_ids_especialidad()
    if not ids:
        mostrar_error("Debe ingresar al menos un ID de especialidad.")
        return

    ok, msg, _ = serv_med.asignar_especialidades(codigo, ids)
    if ok:
        mostrar_exito(msg)
    else:
        mostrar_error(msg)


# ── Horarios ──────────────────────────────────────────────

def _generar_disponibilidad(serv_hor):
    """Genera slots de 30 min para un médico en una fecha y rango de horas"""
    print("\n  -- Generar Disponibilidad --")
    codigo     = leer_texto("  Código del médico: ")
    fecha      = leer_fecha("  Fecha (YYYY-MM-DD): ")
    hora_inicio = leer_hora("  Hora inicio (HH:MM, alineada a :00 o :30): ")
    hora_fin    = leer_hora("  Hora fin   (HH:MM, alineada a :00 o :30): ")

    ok, msg, _ = serv_hor.generar_disponibilidad(codigo, fecha, hora_inicio, hora_fin)
    if ok:
        mostrar_exito(msg)
    else:
        mostrar_error(msg)


def _marcar_no_disponible(serv_hor):
    """Marca uno o todos los slots de un médico en una fecha como no disponibles"""
    print("\n  -- Marcar No Disponible --")
    codigo = leer_texto("  Código del médico: ")
    fecha  = leer_fecha("  Fecha (YYYY-MM-DD): ")

    print("  ¿Desea bloquear un slot específico o todo el día?")
    print("  1. Slot específico")
    print("  2. Todo el día")
    opcion = leer_entero("  Opción: ", minimo=1, maximo=2)

    hora_inicio = None
    if opcion == 1:
        hora_inicio = leer_hora("  Hora inicio del slot (HH:MM): ")

    ok, msg, _ = serv_hor.marcar_no_disponible(codigo, fecha, hora_inicio)
    if ok:
        mostrar_exito(msg)
    else:
        mostrar_error(msg)


# ── Helpers ───────────────────────────────────────────────

def _capturar_datos_medico(serv_esp):
    """Solicita todos los campos de un nuevo médico"""
    print("  (Deje en blanco los campos opcionales)")
    datos = {
        "codigo":            leer_texto("  Código del médico: "),
        "identificacion":    leer_texto("  Identificación: "),
        "nombre":            leer_texto("  Nombre: "),
        "apellido1":         leer_texto("  Primer apellido: "),
        "apellido2":         leer_texto("  Segundo apellido (opcional): ", obligatorio=False),
        "telefono_personal": leer_texto("  Teléfono personal: "),
        "correo_personal":   leer_texto("  Correo personal: "),
        "telefono_clinica":  leer_texto("  Teléfono clínica: "),
        "correo_clinica":    leer_texto("  Correo clínica: "),
        "especialidades":    _leer_ids_especialidad(),
    }
    return datos


def _capturar_cambios_medico(medico):
    """Solicita los nuevos valores del médico; Enter mantiene el actual"""
    cambios = {}

    valor = input(f"  Nombre [{medico.nombre}]: ").strip()
    if valor:
        cambios["nombre"] = valor

    valor = input(f"  Primer apellido [{medico.apellido1}]: ").strip()
    if valor:
        cambios["apellido1"] = valor

    valor = input(f"  Segundo apellido [{medico.apellido2}]: ").strip()
    if valor:
        cambios["apellido2"] = valor

    valor = input(f"  Teléfono personal [{medico.telefono}]: ").strip()
    if valor:
        cambios["telefono_personal"] = valor

    valor = input(f"  Correo personal [{medico.correo}]: ").strip()
    if valor:
        cambios["correo_personal"] = valor

    valor = input(f"  Teléfono clínica [{medico.telefono_clinica}]: ").strip()
    if valor:
        cambios["telefono_clinica"] = valor

    valor = input(f"  Correo clínica [{medico.correo_clinica}]: ").strip()
    if valor:
        cambios["correo_clinica"] = valor

    return cambios


def _listar_especialidades(serv_esp):
    """Imprime la lista de especialidades disponibles"""
    especialidades = serv_esp.listar()
    if not especialidades:
        print("  (No hay especialidades registradas)")
        return
    print("\n  Especialidades disponibles:")
    for esp in especialidades:
        print(f"    [{esp.id_especialidad}] {esp.nombre}")


def _leer_ids_especialidad():
    """Lee IDs de especialidad separados por coma y retorna lista de enteros"""
    entrada = input("  IDs de especialidad (separados por coma): ").strip()
    if not entrada:
        return []
    ids = []
    for parte in entrada.split(","):
        parte = parte.strip()
        if parte.isdigit():
            ids.append(int(parte))
    return ids


def _mostrar_medico(medico):
    """Imprime los datos de un médico en pantalla"""
    print(f"    Teléfono personal: {medico.telefono}")
    print(f"    Correo personal:   {medico.correo}")
    print(f"    Teléfono clínica:  {medico.telefono_clinica}")
    print(f"    Correo clínica:    {medico.correo_clinica}")
    print(f"    Especialidades:    {medico.especialidades}")


def _confirmar_reintentar():
    """Retorna True si el usuario quiere intentar de nuevo"""
    resp = input("  ¿Desea intentar con datos diferentes? (s/n): ").strip().lower()
    return resp == "s"
