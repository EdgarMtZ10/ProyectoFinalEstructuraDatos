"""Utilidades de consola: lectura validada y mensajes"""

from datetime import datetime
from Entidades.constantes import FORMATO_FECHA, FORMATO_HORA


def leer_texto(prompt: str, obligatorio: bool = True) -> str:
    """Solicita un texto al usuario, reintentando si es obligatorio y viene vacío"""
    while True:
        valor = input(prompt).strip()
        if valor or not obligatorio:
            return valor
        mostrar_error("Este campo es obligatorio. Intente de nuevo.")


def leer_entero(prompt: str, minimo=None, maximo=None) -> int:
    """Solicita un entero al usuario, reintentando si no es válido o está fuera de rango"""
    while True:
        entrada = input(prompt).strip()
        if not entrada.lstrip("-").isdigit():
            mostrar_error("Ingrese un número entero válido.")
            continue
        numero = int(entrada)
        if minimo is not None and numero < minimo:
            mostrar_error(f"El valor mínimo es {minimo}.")
            continue
        if maximo is not None and numero > maximo:
            mostrar_error(f"El valor máximo es {maximo}.")
            continue
        return numero


def leer_fecha(prompt: str) -> str:
    """Solicita una fecha en formato YYYY-MM-DD, reintentando si no es válida"""
    while True:
        entrada = input(prompt).strip()
        try:
            datetime.strptime(entrada, FORMATO_FECHA)
            return entrada
        except ValueError:
            mostrar_error("Fecha inválida. Use el formato YYYY-MM-DD (ej: 2025-07-01).")


def leer_hora(prompt: str) -> str:
    """Solicita una hora HH:MM alineada a slot de 30 minutos, reintentando si no es válida"""
    while True:
        entrada = input(prompt).strip()
        try:
            hora_dt = datetime.strptime(entrada, FORMATO_HORA)
            if hora_dt.minute not in (0, 30):
                mostrar_error("La hora debe estar alineada a 00 o 30 minutos (ej: 08:00 o 08:30).")
                continue
            return entrada
        except ValueError:
            mostrar_error("Hora inválida. Use el formato HH:MM (ej: 08:00).")


def confirmar(prompt: str) -> bool:
    """Solicita confirmación al usuario (s/n), reintentando hasta obtener respuesta válida"""
    while True:
        respuesta = input(f"{prompt} (s/n): ").strip().lower()
        if respuesta == "s":
            return True
        if respuesta == "n":
            return False
        mostrar_error("Ingrese 's' para sí o 'n' para no.")


def mostrar_error(mensaje: str) -> None:
    """Muestra un mensaje de error en consola"""
    print(f"  [ERROR] {mensaje}")


def mostrar_exito(mensaje: str) -> None:
    """Muestra un mensaje de éxito en consola"""
    print(f"  [OK] {mensaje}")
