"""Impresión de agenda diaria y semanal de un médico"""

from datetime import datetime, timedelta
from Entidades.constantes import FORMATO_FECHA, DIAS_LABORALES
from UI.utilidades_consola import leer_texto, leer_fecha, leer_entero

_NOMBRES_DIA = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]


def imprimir_dia(serv_horarios, serv_citas, codigo_medico: str, fecha: str) -> None:
    """Imprime todos los slots del médico en una fecha con su estado y paciente si aplica"""
    slots = serv_horarios.slots_de_medico(codigo_medico, fecha)

    fecha_dt = datetime.strptime(fecha, FORMATO_FECHA)
    nombre_dia = _NOMBRES_DIA[fecha_dt.weekday()]
    print(f"\n  Agenda de {codigo_medico} — {nombre_dia} {fecha}")
    print("  " + "-" * 42)

    if not slots:
        print("  (Sin slots registrados para este día)")
        return

    for slot in sorted(slots, key=lambda h: h.hora_inicio):
        if slot.disponible:
            estado = "Libre"
            detalle = ""
        else:
            cita = _buscar_cita_por_slot(serv_citas, slot.id_horario)
            if cita is not None:
                estado = f"Ocupado — Paciente: {cita.identificacion_paciente}  [{cita.estado}]"
            else:
                estado = "No disponible"
            detalle = ""
        print(f"  {slot.hora_inicio} – {slot.hora_fin}  |  {estado}{detalle}")


def imprimir_semana(serv_horarios, serv_citas, codigo_medico: str, fecha_inicio: str) -> None:
    """Imprime la agenda del médico para los 6 días laborales desde fecha_inicio"""
    inicio_dt = datetime.strptime(fecha_inicio, FORMATO_FECHA)
    print(f"\n  === Agenda semanal de {codigo_medico} — semana del {fecha_inicio} ===")

    dias_impresos = 0
    cursor = inicio_dt
    while dias_impresos < 6:
        if cursor.weekday() in DIAS_LABORALES:
            fecha_str = cursor.strftime(FORMATO_FECHA)
            imprimir_dia(serv_horarios, serv_citas, codigo_medico, fecha_str)
            dias_impresos += 1
        cursor += timedelta(days=1)


def ejecutar(servicios):
    """Ejecuta el menú de impresión de agenda"""
    serv_hor = servicios["horarios"]
    serv_cit = servicios["citas"]
    while True:
        _mostrar_menu()
        opcion = leer_entero("  Opción: ", minimo=0, maximo=2)
        if opcion == 1:
            codigo = leer_texto("  Código del médico: ")
            fecha  = leer_fecha("  Fecha (YYYY-MM-DD): ")
            imprimir_dia(serv_hor, serv_cit, codigo, fecha)
        elif opcion == 2:
            codigo = leer_texto("  Código del médico: ")
            fecha  = leer_fecha("  Fecha de inicio de la semana (YYYY-MM-DD): ")
            imprimir_semana(serv_hor, serv_cit, codigo, fecha)
        elif opcion == 0:
            break


def _mostrar_menu():
    """Imprime las opciones del menú de agenda"""
    print("\n" + "-" * 38)
    print("   IMPRIMIR AGENDA")
    print("-" * 38)
    print("  1. Agenda del día")
    print("  2. Agenda semanal")
    print("  0. Volver al menú principal")
    print("-" * 38)


def _buscar_cita_por_slot(serv_citas, id_horario):
    """Retorna la cita activa asociada a un slot, o None si no existe"""
    for cita in serv_citas.citas:
        if cita.id_horario == id_horario and cita.estado != "Cancelada":
            return cita
    return None
