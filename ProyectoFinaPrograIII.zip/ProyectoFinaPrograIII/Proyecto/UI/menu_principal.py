"""Menú principal del sistema de gestión de clínica"""

from UI.utilidades_consola import leer_entero, mostrar_error


def mostrar_menu():
    """Muestra las opciones del menú principal"""
    print("\n" + "=" * 45)
    print("   SISTEMA DE GESTIÓN DE CLÍNICA")
    print("=" * 45)
    print("  1. Gestionar pacientes")
    print("  2. Gestionar médicos / especialidades / horarios")
    print("  3. Buscar médicos")
    print("  4. Reservar cita")
    print("  5. Imprimir agenda (día / semana)")
    print("  6. Gestionar citas (verificar / modificar / cancelar)")
    print("  0. Salir")
    print("=" * 45)


def ejecutar(servicios: dict):
    """Ejecuta el bucle principal del menú"""
    while True:
        mostrar_menu()
        opcion = leer_entero("  Seleccione una opción: ", minimo=0, maximo=6)

        if opcion == 1:
            from UI.menu_pacientes import ejecutar as menu_pacientes
            menu_pacientes(servicios)

        elif opcion == 2:
            from UI.menu_medicos import ejecutar as menu_medicos
            menu_medicos(servicios)

        elif opcion == 3:
            from UI.menu_busquedas import ejecutar as menu_busquedas
            menu_busquedas(servicios)

        elif opcion == 4:
            from UI.menu_citas import reservar as menu_reservar
            menu_reservar(servicios)

        elif opcion == 5:
            from UI.impresion_agenda import ejecutar as menu_agenda
            menu_agenda(servicios)

        elif opcion == 6:
            from UI.menu_citas import ejecutar as menu_citas
            menu_citas(servicios)

        elif opcion == 0:
            if _confirmar_salida():
                _persistir_todo(servicios)
                print("\n  Hasta luego.\n")
                break


def _confirmar_salida() -> bool:
    """Pide confirmación antes de salir"""
    respuesta = input("  ¿Está seguro que desea salir? (s/n): ").strip().lower()
    return respuesta == "s"


def _persistir_todo(servicios: dict):
    """Guarda todos los servicios antes de cerrar"""
    for nombre, servicio in servicios.items():
        if hasattr(servicio, "guardar"):
            servicio.guardar()
