"""Menú de gestión de citas (reservar, cancelar, reprogramar, consultar)"""

from UI.utilidades_consola import leer_texto, leer_entero, leer_fecha, mostrar_error, mostrar_exito


def ejecutar(servicios):
    """Ejecuta el bucle del menú de citas"""
    serv = servicios["citas"]
    serv_hor = servicios["horarios"]
    while True:
        _mostrar_menu()
        opcion = leer_entero("  Opción: ", minimo=0, maximo=4)
        if opcion == 1:
            reservar(servicios)
        elif opcion == 2:
            _cancelar(serv)
        elif opcion == 3:
            _reprogramar(serv, serv_hor)
        elif opcion == 4:
            _consultar(serv)
        elif opcion == 0:
            break


def reservar(servicios):
    """Flujo de reserva: selecciona paciente, médico y slot disponible"""
    serv = servicios["citas"]
    serv_hor = servicios["horarios"]
    serv_med = servicios["medicos"]

    print("\n  -- Reservar Cita --")
    identificacion = leer_texto("  Identificación del paciente: ")
    codigo_medico  = leer_texto("  Código del médico: ")

    # Verificar que el médico existe antes de pedir fecha
    medico = serv_med.buscar_por_codigo(codigo_medico)
    if medico is None:
        mostrar_error(f"No se encontró un médico con código '{codigo_medico}'.")
        return

    fecha = leer_fecha("  Fecha de la cita (YYYY-MM-DD): ")
    slots = serv_hor.slots_disponibles(codigo_medico, fecha)

    if not slots:
        mostrar_error(f"No hay slots disponibles para {medico.obtener_nombre_completo()} el {fecha}.")
        return

    print(f"\n  Slots disponibles el {fecha}:")
    for i, slot in enumerate(slots, start=1):
        print(f"    {i}. {slot.hora_inicio} – {slot.hora_fin}  (id: {slot.id_horario})")

    opcion = leer_entero(f"  Seleccione el slot (1-{len(slots)}): ", minimo=1, maximo=len(slots))
    id_horario = slots[opcion - 1].id_horario

    ok, msg, cita = serv.reservar(identificacion, codigo_medico, id_horario)
    if ok:
        mostrar_exito(msg)
        _mostrar_cita(cita, serv_med)
    else:
        mostrar_error(msg)


def _cancelar(serv):
    """Solicita el id de cita y la cancela"""
    print("\n  -- Cancelar Cita --")
    id_cita = leer_entero("  ID de la cita: ", minimo=1)
    ok, msg, _ = serv.cancelar(id_cita)
    if ok:
        mostrar_exito(msg)
    else:
        mostrar_error(msg)


def _reprogramar(serv, serv_hor):
    """Solicita id de cita, muestra slots disponibles del mismo médico y reprograma"""
    print("\n  -- Reprogramar Cita --")
    id_cita = leer_entero("  ID de la cita a reprogramar: ", minimo=1)

    cita = serv.buscar_por_id(id_cita)
    if cita is None:
        mostrar_error(f"No se encontró una cita con id '{id_cita}'.")
        return
    if cita.estado == "Cancelada":
        mostrar_error("No se puede reprogramar una cita cancelada.")
        return

    print(f"\n  Cita actual: {cita.fecha}  {cita.hora}  (médico: {cita.codigo_medico})")
    fecha = leer_fecha("  Nueva fecha (YYYY-MM-DD): ")
    slots = serv_hor.slots_disponibles(cita.codigo_medico, fecha)

    if not slots:
        mostrar_error(f"No hay slots disponibles para el médico {cita.codigo_medico} el {fecha}.")
        return

    print(f"\n  Slots disponibles el {fecha}:")
    for i, slot in enumerate(slots, start=1):
        print(f"    {i}. {slot.hora_inicio} – {slot.hora_fin}  (id: {slot.id_horario})")

    opcion = leer_entero(f"  Seleccione el slot (1-{len(slots)}): ", minimo=1, maximo=len(slots))
    nuevo_id_horario = slots[opcion - 1].id_horario

    ok, msg, _ = serv.reprogramar(id_cita, nuevo_id_horario)
    if ok:
        mostrar_exito(msg)
    else:
        mostrar_error(msg)


def _consultar(serv):
    """Permite consultar citas por paciente, médico, fecha o estado"""
    print("\n  -- Consultar Citas --")
    print("  1. Por paciente")
    print("  2. Por médico")
    print("  3. Por fecha")
    print("  4. Por estado")
    opcion = leer_entero("  Opción: ", minimo=1, maximo=4)

    if opcion == 1:
        identificacion = leer_texto("  Identificación del paciente: ")
        citas = serv.buscar_por_paciente(identificacion)
    elif opcion == 2:
        codigo = leer_texto("  Código del médico: ")
        citas = serv.buscar_por_medico(codigo)
    elif opcion == 3:
        fecha = leer_fecha("  Fecha (YYYY-MM-DD): ")
        citas = serv.buscar_por_fecha(fecha)
    else:
        print("  Estados: Reservada / Cancelada / Completada")
        estado = leer_texto("  Estado: ")
        citas = serv.buscar_por_estado(estado)

    if not citas:
        print("  No se encontraron citas con ese criterio.")
        return

    print(f"\n  {len(citas)} cita(s) encontrada(s):\n")
    for c in citas:
        print(f"  ID {c.id_cita}  |  {c.fecha}  {c.hora}  |  "
              f"Paciente: {c.identificacion_paciente}  |  "
              f"Médico: {c.codigo_medico}  |  Estado: {c.estado}")


# ── Helpers ───────────────────────────────────────────────

def _mostrar_menu():
    """Imprime las opciones del menú"""
    print("\n" + "-" * 38)
    print("   GESTIÓN DE CITAS")
    print("-" * 38)
    print("  1. Reservar cita")
    print("  2. Cancelar cita")
    print("  3. Reprogramar cita")
    print("  4. Consultar citas")
    print("  0. Volver al menú principal")
    print("-" * 38)


def _mostrar_cita(cita, serv_med):
    """Imprime el resumen de una cita recién creada"""
    medico = serv_med.buscar_por_codigo(cita.codigo_medico)
    nombre_medico = medico.obtener_nombre_completo() if medico else cita.codigo_medico
    print(f"\n  Resumen de la cita:")
    print(f"    ID:      {cita.id_cita}")
    print(f"    Fecha:   {cita.fecha}  {cita.hora}")
    print(f"    Médico:  {nombre_medico}")
    print(f"    Estado:  {cita.estado}")
