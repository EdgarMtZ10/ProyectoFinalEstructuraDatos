"""Menú de búsqueda de médicos y consulta de disponibilidad"""

from UI.utilidades_consola import leer_texto, leer_entero, leer_fecha, mostrar_error


def ejecutar(servicios):
    """Ejecuta el bucle del menú de búsquedas"""
    serv = servicios["busquedas"]
    while True:
        _mostrar_menu()
        opcion = leer_entero("  Opción: ", minimo=0, maximo=1)
        if opcion == 1:
            _buscar_medicos(serv)
        elif opcion == 0:
            break


def _mostrar_menu():
    """Imprime las opciones del menú"""
    print("\n" + "-" * 38)
    print("   BÚSQUEDA DE MÉDICOS")
    print("-" * 38)
    print("  1. Buscar médicos")
    print("  0. Volver al menú principal")
    print("-" * 38)


def _buscar_medicos(serv):
    """Solicita criterios de búsqueda, muestra resultados y ofrece ver disponibilidad"""
    print("\n  -- Buscar Médicos --")
    print("  (Enter para omitir un criterio)")

    nombre   = leer_texto("  Nombre: ",   obligatorio=False) or None
    apellido = leer_texto("  Apellido: ", obligatorio=False) or None

    ids_esp = _leer_ids_especialidad()
    ids_esp = ids_esp if ids_esp else None

    usar_fecha = input("  ¿Filtrar por fecha disponible? (s/n): ").strip().lower()
    fecha = None
    if usar_fecha == "s":
        fecha = leer_fecha("  Fecha (YYYY-MM-DD): ")

    resultados = serv.buscar_medicos(
        nombre=nombre,
        apellido=apellido,
        ids_especialidad=ids_esp,
        fecha_disponible=fecha
    )

    if not resultados:
        print("\n  No se encontraron médicos con esos criterios.")
        return

    _mostrar_resultados(resultados)
    _ofrecer_horarios(serv, resultados)


def _mostrar_resultados(resultados):
    """Imprime la lista numerada de médicos encontrados"""
    print(f"\n  Se encontraron {len(resultados)} médico(s):\n")
    for i, m in enumerate(resultados, start=1):
        especialidades = ", ".join(m["especialidades"]) if m["especialidades"] else "—"
        print(f"  {i}. {m['nombre_completo']}  [{m['codigo']}]")
        print(f"     Especialidades: {especialidades}")
        print(f"     Tel. clínica:   {m['telefono_clinica']}")
        print(f"     Correo clínica: {m['correo_clinica']}")


def _ofrecer_horarios(serv, resultados):
    """Permite al usuario elegir un médico y ver su disponibilidad"""
    print()
    resp = input("  ¿Desea ver la disponibilidad de algún médico? (s/n): ").strip().lower()
    if resp != "s":
        return

    opcion = leer_entero(
        f"  Seleccione el número del médico (1-{len(resultados)}): ",
        minimo=1, maximo=len(resultados)
    )
    medico = resultados[opcion - 1]

    usar_fecha = input("  ¿Filtrar disponibilidad por fecha? (s/n): ").strip().lower()
    fecha = None
    if usar_fecha == "s":
        fecha = leer_fecha("  Fecha (YYYY-MM-DD): ")

    slots = serv.horarios_disponibles_de(medico["codigo"], fecha)

    if not slots:
        print("  No hay slots disponibles para ese médico" +
              (f" en la fecha {fecha}." if fecha else "."))
        return

    print(f"\n  Disponibilidad de {medico['nombre_completo']}:\n")
    fecha_actual = None
    for slot in sorted(slots, key=lambda h: (h.fecha, h.hora_inicio)):
        if slot.fecha != fecha_actual:
            fecha_actual = slot.fecha
            print(f"  {fecha_actual}")
        print(f"    {slot.hora_inicio} – {slot.hora_fin}  (id: {slot.id_horario})")


def _leer_ids_especialidad():
    """Lee IDs de especialidad separados por coma y retorna lista de enteros"""
    entrada = input("  IDs de especialidad (separados por coma, Enter = cualquiera): ").strip()
    if not entrada:
        return []
    ids = []
    for parte in entrada.split(","):
        parte = parte.strip()
        if parte.isdigit():
            ids.append(int(parte))
    return ids
