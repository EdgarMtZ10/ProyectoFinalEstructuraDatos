"""Punto de entrada del servidor de la API por sockets.

Ejecutar desde la raíz del proyecto:
    python ServidorAPI.py
"""

from API import servidor


if __name__ == "__main__":
    servidor.iniciar()




